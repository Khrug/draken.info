# References {-}

Entries marked ✓ were checked against Crossref on 2026-10-02 (title, venue, volume, pages, DOI). Entries marked † could not be machine-verified and are listed for manual check in the release note. Unmarked entries are standard monographs. Draken posts are cited in the text by link and listed in Appendix E.

Acebrón, J. A., Bonilla, L. L., Pérez Vicente, C. J., Ritort, F. & Spigler, R. (2005). The Kuramoto model: A simple paradigm for synchronization phenomena. *Reviews of Modern Physics* 77(1), 137–185. doi:10.1103/RevModPhys.77.137 ✓

Aharonov, Y. & Bohm, D. (1959). Significance of electromagnetic potentials in the quantum theory. *Physical Review* 115(3), 485–491. doi:10.1103/PhysRev.115.485 ✓

Altafini, C. (2013). Consensus problems on networks with antagonistic interactions. *IEEE Transactions on Automatic Control* 58(4), 935–946. doi:10.1109/TAC.2012.2224251 ✓

Amari, S. (1998). Natural gradient works efficiently in learning. *Neural Computation* 10(2), 251–276.

Anderson, B. D. O. (1982). Reverse-time diffusion equation models. *Stochastic Processes and their Applications* 12(3), 313–326. doi:10.1016/0304-4149(82)90051-5 ✓

Arendt, H. (1951). *The Origins of Totalitarianism*. New York: Harcourt, Brace.

Ashby, W. R. (1956). *An Introduction to Cybernetics*. London: Chapman & Hall.

Bandeira, A. S., Singer, A. & Spielman, D. A. (2013). A Cheeger inequality for the graph connection Laplacian. *SIAM Journal on Matrix Analysis and Applications* 34(4), 1611–1630. doi:10.1137/120875338 ✓

Barbero, F., Bodnar, C., Sáez de Ocáriz Borde, H., Bronstein, M., Veličković, P. & Liò, P. (2022). Sheaf neural networks with connection Laplacians. arXiv:2206.08702.

Barooah, P. & Hespanha, J. P. (2008). Estimation from relative measurements: electrical analogy and large graphs. *IEEE Transactions on Signal Processing* 56(6), 2181–2193. doi:10.1109/TSP.2007.912270 ✓

Barresi, M. J. F. & Gilbert, S. F. (2023). *Developmental Biology*, 13th ed. Oxford: Oxford University Press. doi:10.1093/hesc/9780197574591.001.0001 ✓

Bendsøe, M. P. & Sigmund, O. (2003). *Topology Optimization: Theory, Methods and Applications*. Berlin: Springer.

Berry, M. V. (1984). Quantal phase factors accompanying adiabatic changes. *Proceedings of the Royal Society of London A* 392(1802), 45–57. doi:10.1098/rspa.1984.0023 ✓

Bodnar, C., Di Giovanni, F., Chamberlain, B., Liò, P. & Bronstein, M. (2022). Neural sheaf diffusion: A topological perspective on heterophily and oversmoothing in GNNs. *NeurIPS 2022*. arXiv:2202.04579.

Bonhommeau, S., Dubroca, L., Le Pape, O. et al. (2013). Eating up the world's food web and the human trophic level. *Proceedings of the National Academy of Sciences* 110(51), 20617–20620. doi:10.1073/pnas.1305827110 ✓

Bravyi, S., Poulin, D. & Terhal, B. (2010). Tradeoffs for reliable quantum information storage in 2D systems. *Physical Review Letters* 104(5), 050503. doi:10.1103/PhysRevLett.104.050503 ✓

Bredon, G. E. (1997). *Sheaf Theory*, 2nd ed. Graduate Texts in Mathematics 170. New York: Springer.

Bérut, A., Arakelyan, A., Petrosyan, A., Ciliberto, S., Dillenschneider, R. & Lutz, E. (2012). Experimental verification of Landauer's principle linking information and thermodynamics. *Nature* 483(7388), 187–189. doi:10.1038/nature10872 ✓

Calderbank, A. R. & Shor, P. W. (1996). Good quantum error-correcting codes exist. *Physical Review A* 54(2), 1098–1105. doi:10.1103/PhysRevA.54.1098 ✓

Chen, Y., Huang, M. M.-Y., Liu, Y. & Tang, E.-C. (2026). Cubical sheaf complexes with constant expansion with applications to asymptotically good qLTCs. Preprint, arXiv:2609.28028. †

Curry, J. M. (2014). *Sheaves, Cosheaves and Applications*. PhD thesis, University of Pennsylvania. arXiv:1303.3255.

Dennett, D. C. (1991). Real patterns. *The Journal of Philosophy* 88(1), 27–51.

Dennis, E., Kitaev, A., Landahl, A. & Preskill, J. (2002). Topological quantum memory. *Journal of Mathematical Physics* 43, 4452–4505. arXiv:quant-ph/0110143.

Dick, T. J. M. & Clemente, C. J. (2016). How to build your dragon: scaling of muscle architecture from the world's smallest to the world's largest monitor lizard. *Frontiers in Zoology* 13, 8. doi:10.1186/s12983-016-0141-5 ✓

Doyle, P. G. & Snell, J. L. (1984). *Random Walks and Electric Networks*. Carus Mathematical Monographs 22. Washington, DC: Mathematical Association of America.

Driscoll, L. N., Pettit, N. L., Minderer, M., Chettih, S. N. & Harvey, C. D. (2017). Dynamic reorganization of neuronal activity patterns in parietal cortex. *Cell* 170(5), 986–999.e16. doi:10.1016/j.cell.2017.07.021 ✓

Earley, R. L., Attum, O. & Eason, P. (2002). Varanid combat: perspectives from game theory. *Amphibia-Reptilia* 23(4), 469–485. †

Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614. doi:10.1198/jasa.2011.tm11181 ✓

Eigen, M. (1971). Selforganization of matter and the evolution of biological macromolecules. *Naturwissenschaften* 58, 465–523.

Enquist, M. & Leimar, O. (1983). Evolution of fighting behaviour: decision rules and assessment of relative strength. *Journal of Theoretical Biology* 102(3), 387–410. doi:10.1016/0022-5193(83)90376-4 ✓

Fiedler, M. (1973). Algebraic connectivity of graphs. *Czechoslovak Mathematical Journal* 23(2), 298–305. doi:10.21136/CMJ.1973.101168 ✓

Fletcher, P. C. & Frith, C. D. (2009). Perceiving is believing: a Bayesian approach to explaining the positive symptoms of schizophrenia. *Nature Reviews Neuroscience* 10(1), 48–58. doi:10.1038/nrn2536 ✓

Freris, N. M., Graham, S. R. & Kumar, P. R. (2011). Fundamental limits on synchronizing clocks over networks. *IEEE Transactions on Automatic Control* 56(6), 1352–1364. doi:10.1109/TAC.2010.2089210 ✓

Friston, K. (2010). The free-energy principle: a unified brain theory? *Nature Reviews Neuroscience* 11(2), 127–138. doi:10.1038/nrn2787 ✓

Frýdlová, P., Šimková, O., Janovská, V., Velenský, P. & Frynta, D. (2016, online; 2017, print). Offenders tend to be heavier: experimental encounters in mangrove-dwelling monitor lizards (*Varanus indicus*). *Acta Ethologica* 20(1), 37–45. doi:10.1007/s10211-016-0246-z ✓

Gay, W. & Jeronimo, F. G. (2026). Asymptotically good quantum locally testable codes. Preprint, arXiv:2609.20780. †

Giridhar, A. & Kumar, P. R. (2006). Distributed clock synchronization over wireless networks: algorithms and analysis. *Proceedings of the 45th IEEE Conference on Decision and Control*, 4915–4920. doi:10.1109/CDC.2006.377325 ✓

Grady, L. J. & Polimeni, J. R. (2010). *Discrete Calculus: Applied Analysis on Graphs for Computational Science*. London: Springer. doi:10.1007/978-1-84996-290-2 ✓

Grebogi, C., Ott, E. & Yorke, J. A. (1987). Basin boundary metamorphoses: changes in accessible boundary orbits. *Physica D* 24(1–3), 243–262.

Gromov, M. (2010). Singularities, expanders and topology of maps. Part 2: From combinatorics to topology via algebraic isoperimetry. *Geometric and Functional Analysis* 20, 416–526.

Hansen, J. & Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3(4), 315–358. doi:10.1007/s41468-019-00038-7 ✓

Hansen, J. & Ghrist, R. (2021). Opinion dynamics on discourse sheaves. *SIAM Journal on Applied Mathematics* 81(5), 2033–2060. doi:10.1137/20M1341088 ✓

Harary, F. (1953). On the notion of balance of a signed graph. *Michigan Mathematical Journal* 2(2), 143–146. doi:10.1307/mmj/1028989917 ✓

Harrison, M. (2011). Forging success: Soviet managers and accounting fraud, 1943–1962. *Journal of Comparative Economics* 39(1), 43–64. doi:10.1016/j.jce.2010.12.002 ✓

Hatcher, A. (2002). *Algebraic Topology*. Cambridge: Cambridge University Press.

Hawkins, D. & Simon, H. A. (1949). Note: Some conditions of macroeconomic stability. *Econometrica* 17(3/4), 245–248. doi:10.2307/1905526 ✓

Hegselmann, R. & Krause, U. (2002). Opinion dynamics and bounded confidence: models, analysis and simulation. *Journal of Artificial Societies and Social Simulation* 5(3), 2.

Hinton, G., Vinyals, O. & Dean, J. (2015). Distilling the knowledge in a neural network. arXiv:1503.02531.

Ho, J., Jain, A. & Abbeel, P. (2020). Denoising diffusion probabilistic models. *Advances in Neural Information Processing Systems* 33. arXiv:2006.11239.

Hofbauer, J. & Sigmund, K. (1998). *Evolutionary Games and Population Dynamics*. Cambridge: Cambridge University Press. doi:10.1017/CBO9781139173179 ✓

Horn, H.-G., Gaulke, M. & Böhme, W. (1994). Ritualized combat in monitor lizards (as cited in v4.4: *Mertensiella* 4, 159–174). †

Jackson, J. D. (1998). *Classical Electrodynamics*, 3rd ed. New York: Wiley.

Jiang, X., Lim, L.-H., Yao, Y. & Ye, Y. (2011). Statistical ranking and combinatorial Hodge theory. *Mathematical Programming* 127(1), 203–244. doi:10.1007/s10107-010-0419-x ✓

Kapur, S. (2003). Psychosis as a state of aberrant salience: a framework linking biology, phenomenology, and pharmacology in schizophrenia. *American Journal of Psychiatry* 160(1), 13–23. doi:10.1176/appi.ajp.160.1.13

Kauffman, S. A. (1993). *The Origins of Order*. Oxford: Oxford University Press.

Kitaev, A. Yu. (2003). Fault-tolerant quantum computation by anyons. *Annals of Physics* 303(1), 2–30. doi:10.1016/S0003-4916(02)00018-0 ✓

Kriegeskorte, N., Mur, M. & Bandettini, P. (2008). Representational similarity analysis — connecting the branches of systems neuroscience. *Frontiers in Systems Neuroscience* 2, 4. doi:10.3389/neuro.06.004.2008

Kuramoto, Y. (1984). *Chemical Oscillations, Waves, and Turbulence*. Berlin: Springer.

Lachaux, J.-P., Rodriguez, E., Martinerie, J. & Varela, F. J. (1999). Measuring phase synchrony in brain signals. *Human Brain Mapping* 8(4), 194–208.

Ladyman, J. & Ross, D. (2007). *Every Thing Must Go: Metaphysics Naturalized*. Oxford: Oxford University Press.

Landau, L. D. & Lifshitz, E. M. (1975). *The Classical Theory of Fields*, 4th ed. (Course of Theoretical Physics, Vol. 2). Oxford: Pergamon.

Landauer, R. (1961). Irreversibility and heat generation in the computing process. *IBM Journal of Research and Development* 5(3), 183–191. doi:10.1147/rd.53.0183 ✓

Landis, J. R. & Koch, G. G. (1977). The measurement of observer agreement for categorical data. *Biometrics* 33(1), 159–174. doi:10.2307/2529310 ✓

Lense, J. & Thirring, H. (1918). Über den Einfluß der Eigenrotation der Zentralkörper auf die Bewegung der Planeten und Monde nach der Einsteinschen Gravitationstheorie. *Physikalische Zeitschrift* 19, 156–163.

Lenton, T. M., Held, H., Kriegler, E., Hall, J. W., Lucht, W., Rahmstorf, S. & Schellnhuber, H. J. (2008). Tipping elements in the Earth's climate system. *Proceedings of the National Academy of Sciences* 105(6), 1786–1793.

Leontief, W. (1941). *The Structure of American Economy, 1919–1929*. Cambridge, MA: Harvard University Press.

Leverrier, A. & Zémor, G. (2022). Quantum Tanner codes. *Proceedings of FOCS 2022*. arXiv:2202.13641.

Levin, M. & Martyniuk, C. J. (2018). The bioelectric code: An ancient computational medium for dynamic control of growth and form. *Biosystems* 164, 76–93. doi:10.1016/j.biosystems.2017.08.009 ✓

Levine, S. (1980). Several measures of trophic structure applicable to complex food webs. *Journal of Theoretical Biology* 83(2), 195–207. doi:10.1016/0022-5193(80)90288-X ✓

Lim, L.-H. (2020). Hodge Laplacians on graphs. *SIAM Review* 62(3), 685–715. doi:10.1137/18M1223101 ✓

Lindeman, R. L. (1942). The trophic-dynamic aspect of ecology. *Ecology* 23(4), 399–417. doi:10.2307/1930126 ✓

Linial, N. & Meshulam, R. (2006). Homological connectivity of random 2-complexes. *Combinatorica* 26, 475–487.

Littlewood, J. E. (1986). *Littlewood's Miscellany*, ed. B. Bollobás. Cambridge: Cambridge University Press.

Mac Lane, S. & Moerdijk, I. (1994). *Sheaves in Geometry and Logic*. New York: Springer.

Mac Lane, S. (1971). *Categories for the Working Mathematician*. New York: Springer.

MacNulty, D. R., Cooper, D. J., Procko, M. et al. (2025). Flawed analysis invalidates claim of a strong Yellowstone trophic cascade after wolf reintroduction: a comment on Ripple et al. (2025). Preprint, EcoEvoRxiv. doi:10.32942/x2qq0c ✓

Maxwell, J. C. (1868). On governors. *Proceedings of the Royal Society of London* 16, 270–283. doi:10.1098/rspl.1867.0055

Mazzucato, M. (2018). *The Value of Everything: Making and Taking in the Global Economy*. London: Allen Lane.

Mordvintsev, A., Randazzo, E., Niklasson, E. & Levin, M. (2020). Growing neural cellular automata. *Distill* 5(2). doi:10.23915/distill.00023 ✓

O'Keeffe, K. P., Hong, H. & Strogatz, S. H. (2017). Oscillators that sync and swarm. *Nature Communications* 8, 1504. doi:10.1038/s41467-017-01190-3

Ostrom, E. (1990). *Governing the Commons*. Cambridge: Cambridge University Press.

Panteleev, P. & Kalachev, G. (2022). Asymptotically good quantum and locally testable classical LDPC codes. *Proceedings of the 54th Annual ACM SIGACT Symposium on Theory of Computing (STOC 2022)*, 375–388. doi:10.1145/3519935.3520017 ✓

Panteleev, P. & Kalachev, G. (2024). Maximally extendable sheaf codes. Preprint, arXiv:2403.03651.

Peskin, M. E. & Schroeder, D. V. (1995). *An Introduction to Quantum Field Theory*. Reading, MA: Addison-Wesley.

Post, E. J. (1967). Sagnac effect. *Reviews of Modern Physics* 39(2), 475–493. doi:10.1103/RevModPhys.39.475 ✓

Prigogine, I. & Stengers, I. (1984). *Order Out of Chaos*. New York: Bantam.

Reichenbach, H. (1928). *Philosophie der Raum-Zeit-Lehre*. Berlin: de Gruyter. (Engl. *The Philosophy of Space and Time*, Dover 1958, §19.)

Resta, R. (2000). Manifestations of Berry's phase in molecules and condensed matter. *Journal of Physics: Condensed Matter* 12(9), R107–R143. doi:10.1088/0953-8984/12/9/201 ✓

Ripple, W. J. & Beschta, R. L. (2004). Wolves and the ecology of fear: can predation risk structure ecosystems? *BioScience* 54(8), 755–766.

Ripple, W. J., Beschta, R. L., Wolf, C. et al. (2025). The strength of the Yellowstone trophic cascade after wolf reintroduction. *Global Ecology and Conservation* 58, e03428. doi:10.1016/j.gecco.2025.e03428 ✓

Rissanen, S., Heinonen, M. & Solin, A. (2023). Generative modelling with inverse heat dissipation. *ICLR 2023*. arXiv:2206.13397. †

Robinson, M. (2017). Sheaves are the canonical data structure for sensor integration. *Information Fusion* 36, 208–224. doi:10.1016/j.inffus.2016.12.002 ✓

Roininen, K. (2026). *The Draken 2045 Framework: Topological Coherence Theory for Multi-Scale Systems Analysis*, Version 4.4 (March 2026). Khrug Engineering. Zenodo, doi:10.5281/zenodo.19292500 (version 4.4; all versions: 10.5281/zenodo.19273482). The predecessor of this monograph, cited throughout as "v4.4".

Rue, H. & Held, L. (2005). *Gaussian Markov Random Fields: Theory and Applications*. Boca Raton: Chapman & Hall/CRC.

Rule, M. E. & O'Leary, T. (2022). Self-healing codes: How stable neural populations can track continually reconfiguring neural representations. *Proceedings of the National Academy of Sciences* 119(7), e2106692119. doi:10.1073/pnas.2106692119 ✓

Rule, M. E. et al. (2020). Stable task information from an unstable neural population. *eLife* 9, e51121.

Scheffer, M., Bascompte, J., Brock, W. A., Brovkin, V., Carpenter, S. R., Dakos, V., Held, H., van Nes, E. H., Rietkerk, M. & Sugihara, G. (2009). Early-warning signals for critical transitions. *Nature* 461(7260), 53–59. doi:10.1038/nature08227 ✓

Schoonover, C. E., Ohashi, S. N., Axel, R. & Fink, A. J. P. (2021). Representational drift in primary olfactory cortex. *Nature* 594(7864), 541–546. doi:10.1038/s41586-021-03628-7 ✓

Shuman, D. I., Narang, S. K., Frossard, P., Ortega, A. & Vandergheynst, P. (2013). The emerging field of signal processing on graphs. *IEEE Signal Processing Magazine* 30(3), 83–98. doi:10.1109/MSP.2012.2235192 ✓

Simon, B. (1983). Holonomy, the quantum adiabatic theorem, and Berry's phase. *Physical Review Letters* 51, 2167–2170.

Singer, A. & Wu, H.-T. (2012). Vector diffusion maps and the connection Laplacian. *Communications on Pure and Applied Mathematics* 65(8), 1067–1144. doi:10.1002/cpa.21395 ✓

Song, Y. & Ermon, S. (2019). Generative modeling by estimating gradients of the data distribution. *Advances in Neural Information Processing Systems* 32. arXiv:1907.05600.

Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. & Poole, B. (2021). Score-based generative modeling through stochastic differential equations. *ICLR 2021*. arXiv:2011.13456.

Steane, A. (1996). Multiple-particle interference and quantum error correction. *Proceedings of the Royal Society A* 452, 2551–2577. doi:10.1098/rspa.1996.0136

Stigler, G. J. (1971). The theory of economic regulation. *Bell Journal of Economics and Management Science* 2(1), 3–21. doi:10.2307/3003160

Strogatz, S. H. (2000). From Kuramoto to Crawford: exploring the onset of synchronization in populations of coupled oscillators. *Physica D* 143(1–4), 1–20. doi:10.1016/S0167-2789(00)00094-4 ✓

't Hooft, G. & Veltman, M. (1972). Regularization and renormalization of gauge fields. *Nuclear Physics B* 44(1), 189–213. doi:10.1016/0550-3213(72)90279-9 ✓

Taylor, P. D. & Jonker, L. B. (1978). Evolutionary stable strategies and game dynamics. *Mathematical Biosciences* 40(1–2), 145–156. doi:10.1016/0025-5564(78)90077-9 ✓

Thouless, D. J., Kohmoto, M., Nightingale, M. P. & den Nijs, M. (1982). Quantized Hall conductance in a two-dimensional periodic potential. *Physical Review Letters* 49, 405–408.

Varlet, M. & Grootswagers, T. (2024). Measuring information alignment in hyperscanning research with representational analyses: moving beyond interbrain synchrony. *Frontiers in Human Neuroscience* 18, 1385624.

Verstraete, F. & Cirac, J. I. (2004). Renormalization algorithms for quantum-many body systems in two and higher dimensions. arXiv:cond-mat/0407066.

Vidal, G. (2008). Class of quantum many-body states that can be efficiently simulated. *Physical Review Letters* 101, 110501.

Weibel, C. A. (1994). *An Introduction to Homological Algebra*. Cambridge: Cambridge University Press.

Wilczek, F. & Zee, A. (1984). Appearance of gauge structure in simple dynamical systems. *Physical Review Letters* 52(24), 2111–2114. doi:10.1103/PhysRevLett.52.2111 ✓

Witten, E. (1989). Quantum field theory and the Jones polynomial. *Communications in Mathematical Physics* 121, 351–399.

Zanardi, P. & Rasetti, M. (1999). Holonomic quantum computation. *Physics Letters A* 264, 94–99.
