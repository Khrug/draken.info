## Appendix E — Corpus Disposition

All 86 published posts (`data/drk-index.json`, generated 2026-10-02; next free DRK-197; DRK-134 reserved). Disposition: **55** enter the argument, **4** enter through the glossary only, and **27** are assigned to the companion volume *Draken Essays*. Assignment to the companion volume is a judgement of load-bearing role in a mathematical monograph, not of quality. No post is removed from the corpus (§19.6).

| DRK | Title | Disposition | Where |
|---|---|---|---|
| DRK-101 | [KnowledgeObject Schema v2: The Atomic Unit of Draken Memory](https://draken.info/posts/ko-schema-v2/) | Argument | Ch. 21 |
| DRK-105 | [The Kaiju Manifesto: Building the Anti-Memetic Monster](https://draken.info/posts/kaiju-manifesto/) | Argument | Ch. 5, 6 |
| DRK-108 | [Abstraction Depth: Why Your Boss Doesn't Have to Wrestle You](https://draken.info/posts/abstraction-depth/) | Argument | Ch. 8, 16, 20 |
| DRK-110 | [The Manufactured Void: Narrative Engineering from Nixon to Neural Networks](https://draken.info/posts/manufactured-void/) | Glossary | Glossary (manufactured void) |
| DRK-112 | [The Thermodynamics of Affect: Where Deleuze Meets the Substrate](https://draken.info/posts/thermodynamics-of-affect/) | Companion volume | — |
| DRK-113 | [The Repetition Engine: Deleuze, Sisyphus, and the Architecture of Bad Loops](https://draken.info/posts/repetition-engine/) | Companion volume | — |
| DRK-114 | [The Perceptive Node's Dilemma: Why the Sharpest Diagnosticians Retreat from the Arena They Could Rebuild](https://draken.info/posts/the-perceptive-nodes-dilemma/) | Companion volume | — |
| DRK-115 | [The Curious Machine: Why the Smartest AI Won't Exploit What It Doesn't Understand](https://draken.info/posts/the-curious-machine/) | Companion volume | — |
| DRK-116 | [Reasonance: The Oldest Search and the Deepest Layer](https://draken.info/posts/reasonance/) | Companion volume | — |
| DRK-117 | [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) | Argument | Ch. 2, 18 |
| DRK-118 | [Planning as Inference: Leontief, Friston, and the Generative Model the West Chose to Forget](https://draken.info/posts/countries-as-collective-minds/) | Argument | Ch. 10, 16 |
| DRK-119 | [The Grammar of Coherence Destruction: From Sun Tzu to GPT](https://draken.info/posts/grammar-of-coherence-destruction/) | Argument | Ch. 18 |
| DRK-120 | [The Cavity and the Commune: Marx, Lenin, and the Draken Framework on Religion, the Void, and the Sacred](https://draken.info/posts/the-cavity-and-the-commune/) | Glossary | Glossary (cavity resonator) |
| DRK-121 | [The Coherence Debt: Karma as Thermodynamic Integral](https://draken.info/posts/the-coherence-debt/) | Argument | Ch. 7 |
| DRK-123 | [The Imaginary Dimension: How Evolution Invented the Future 130 Million Years Before Wick](https://draken.info/posts/the-imaginary-dimension/) | Argument | Ch. 14 |
| DRK-124 | [The Boundary of Us](https://draken.info/posts/the-boundary-of-us/) | Companion volume | — |
| DRK-125 | [The Totalitarian Sheaf: Hannah Arendt, the Petrodollar Clinch, and the Algorithm That Grapples Its Own Skeleton](https://draken.info/posts/the-totalitarian-sheaf/) | Argument | Ch. 9, 19 |
| DRK-127 | [Can We Be Friends with Monsters?](https://draken.info/posts/can-we-be-friends-with-monsters/) | Companion volume | — |
| DRK-128 | [The Stick That Is Not a Weapon](https://draken.info/posts/the-stick-that-is-not-a-weapon/) | Companion volume | — |
| DRK-129 | [The Resonant Agenda](https://draken.info/posts/the-resonant-agenda/) | Companion volume | — |
| DRK-130 | [The Substrate and the Game: Why Evolution's Optimization Protocols Do Not Work Through Our Intelligence](https://draken.info/posts/the-substrate-and-the-game/) | Argument | Ch. 7, 16 |
| DRK-131 | [知行合一: When Automation Removes the Only Honest Referee](https://draken.info/posts/zhixing-heyi-honest-referee/) | Argument | Ch. 5, 22 |
| DRK-132 | [The Sheaf Analyzer: A Topological Diagnostic for Arbitrary Text](https://draken.info/posts/sheaf-analyzer-manual/) | Argument | Ch. 21 |
| DRK-133 | [The Protocol and the Predator: On Asymmetric Power Without Extraction](https://draken.info/posts/asymmetric-power/) | Argument | Ch. 6, 18 |
| DRK-135 | [The Decorticated Sheaf: Nasimi, Cellular Automata, and the Skin That Was Already a Voice](https://draken.info/posts/the-decorticated-sheaf/) | Companion volume | — |
| DRK-136 | [The Komodoburger Franchise: Why the Apex Niche Is Force-Protected by Its Own Occupant — and What Dragonclaw Inherits From This](https://draken.info/posts/the-komodoburger-franchise/) | Argument | Ch. 7, 10, 16 |
| DRK-137 | [The Fuse and the Shield: Reply to Scott Andrews on Cult Dynamics, Cognitive Decline, and the Kompromat Failure Mode](https://draken.info/posts/the-fuse-and-the-shield/) | Companion volume | — |
| DRK-138 | [The Survivable Glitch: Lacan's Middle Period, the Simulator, the Haveriutredning, and Why I Named the Framework Draken](https://draken.info/posts/the-survivable-glitch/) | Glossary | Glossary (survivable glitch) |
| DRK-139 | [The Welcomed Section: *Taxamhet*, *Tacksamhet*, and the Mathematics of Letting Another's Coherence In](https://draken.info/posts/the-welcomed-section/) | Argument | Ch. 5, 10 |
| DRK-140 | [The Productile Monad: On *Repmånad*, the Reptile, and the Form That Persists by Iterating Itself](https://draken.info/posts/the-productile-monad/) | Argument | Ch. 10, 16 |
| DRK-141 | [The Finite Sheaf: Draken as Applied Ultrafinitism](https://draken.info/posts/the-finite-sheaf/) | Argument | Ch. 2, 5, 7, 10, 14, 18 |
| DRK-142 | [Wrestling with God: Perlocutionary Force and the Cohomology of the Honest Encounter](https://draken.info/posts/wrestling-with-god/) | Argument | Ch. 2, 5, 10 |
| DRK-143 | [The Braided Substrate: Berry Curvature, Tensor Networks, and Why Topology Builds Draken](https://draken.info/posts/the-braided-substrate/) | Argument | Ch. 10, 11, 22 |
| DRK-144 | [Shape Is Spectrum: Coherence as Basis Distribution](https://draken.info/posts/shape-is-spectrum/) | Argument | Ch. 5 |
| DRK-145 | [The Operational Question in Positive Alignment](https://draken.info/posts/positive-alignment-operational/) | Argument | Ch. 2, 3 |
| DRK-146 | [Representational Drift as Sheaf-Theoretic Coherence](https://draken.info/posts/representational-drift-sheaf/) | Argument | Ch. 20 |
| DRK-147 | [Sheaves of the Mind, Sheaves of Life](https://draken.info/posts/sheaves-of-the-mind/) | Companion volume | — |
| DRK-148 | [Wings, Tools, Weapons](https://draken.info/posts/wings-tools-weapons/) | Companion volume | — |
| DRK-149 | [The Continuous Dimension: Dimensional Regularization, Renormalization Flow, and the Wick Rotation at L01](https://draken.info/posts/the-continuous-dimension/) | Argument | Ch. 10, 14 |
| DRK-150 | [The Generalizard: Keeper-Function, Mandate, and the Imperial Dragon](https://draken.info/posts/the-generalizard/) | Glossary | Glossary (keeper-function) |
| DRK-151 | [The Mandate of Reality: Anerkennung, Truth, and the Glued Self](https://draken.info/posts/the-mandate-of-reality/) | Companion volume | — |
| DRK-152 | [Lizards Doing Calculus: The Substrate, the Clutch, and the Ouroboros](https://draken.info/posts/lizards-doing-calculus/) | Companion volume | — |
| DRK-153 | [No Trace, No Section: A Sheaf-Theoretic Disposal of the Consciousness-Violates-Physics Move](https://draken.info/posts/no-trace-no-section/) | Argument | Ch. 10, 14 |
| DRK-154 | [Drakō ben Adam: Reading the Draken Framework Through the Lurianic Mirror](https://draken.info/posts/lurianic-mirror/) | Companion volume | — |
| DRK-155 | [Inpu Means Input: Anubis, the Forty-Two, and the Restriction Map of the Dead](https://draken.info/posts/inpu-means-input/) | Companion volume | — |
| DRK-156 | [The Magical Substrate: Non-Clifford Gates, Topological Gravity, and the Sorcery That Bends Space](https://draken.info/posts/the-magical-substrate/) | Argument | Ch. 10, 14 |
| DRK-157 | [The Compressible Section: Real Patterns, Rainforest Realism, and the Cohomology of Which Patterns Glue](https://draken.info/posts/the-compressible-section/) | Argument | Ch. 5, 17 |
| DRK-158 | [The Burnt Section](https://draken.info/posts/the-burnt-section/) | Argument | Ch. 19 |
| DRK-159 | [The Tiger and the Y-Stick: A Case File on What Makes a Tiger Fight](https://draken.info/posts/the-tiger-and-the-stick/) | Companion volume | — |
| DRK-160 | [The Undefended Vector](https://draken.info/posts/the-undefended-vector/) | Companion volume | — |
| DRK-161 | [The Compartmentalized Manifold](https://draken.info/posts/the-compartmentalized-manifold/) | Argument | Ch. 10, 19 |
| DRK-162 | [The Bridge and the Burn](https://draken.info/posts/the-bridge-and-the-burn/) | Argument | Ch. 2, 7 |
| DRK-163 | [The Two Optics](https://draken.info/posts/the-two-optics/) | Argument | Ch. 10, 16 |
| DRK-164 | [The Sleepless Section](https://draken.info/posts/the-sleepless-section/) | Argument | Ch. 10, 15 |
| DRK-165 | [The Pendragon Source](https://draken.info/posts/the-pendragon-source/) | Argument | Ch. 18 |
| DRK-166 | [The Sonder Egg: König as Master Regulator and the Genus-0 Boundary of the Self](https://draken.info/posts/the-sonder-egg/) | Argument | Ch. 9, 10, 14 |
| DRK-167 | [The Stalking Cell: Fractal Growth, the Bioelectric Glue, and the Restriction-Map Chain from Gene to Organism](https://draken.info/posts/the-stalking-cell/) | Argument | Ch. 20 |
| DRK-168 | [The One-Way Gauge: Simultaneity as Connection and the H¹ Obstruction Behind OPERA](https://draken.info/posts/the-one-way-gauge/) | Argument | Ch. 1, 10 |
| DRK-169 | [Relevance as Collapse: Relevance Realization as the Endogenous Measurement of a Viable Section](https://draken.info/posts/relevance-as-collapse/) | Argument | Ch. 17 |
| DRK-170 | [The Guessed Section: Abduction as H¹-Combat and the Defect of the Unit](https://draken.info/posts/the-guessed-section/) | Argument | Ch. 5, 17 |
| DRK-171 | [The Dragged Frame: Frame-Dragging as Synchronization Holonomy, and the Horizon as a Convergence Obstruction](https://draken.info/posts/the-dragged-frame/) | Argument | Ch. 1, 4, 10 |
| DRK-172 | [Picking Berries: Archetypes and the Geometric Phase](https://draken.info/posts/picking-berries/) | Argument | Ch. 10, 11 |
| DRK-173 | [The Borrowed Interior: Simulation, the Contested Mirror, and Dissociation](https://draken.info/posts/the-borrowed-interior/) | Companion volume | — |
| DRK-174 | [The Cloven Section: Extraction, the Cut, and the Two Senses of Cleave](https://draken.info/posts/the-cloven-section/) | Argument | Ch. 3, 10 |
| DRK-175 | [The Invariant](https://draken.info/posts/the-invariant/) | Argument | Ch. 1, 3, 9, 10, 11 |
| DRK-176 | [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) | Argument | Ch. 3, 6, 7, 9 |
| DRK-177 | [The Common Base: Dream Logic, Archetype, and the Coincidence That Needs No Channel](https://draken.info/posts/the-common-base/) | Argument | Ch. 6 |
| DRK-178 | [Övervakaren och Undervakaren](https://draken.info/posts/overvakaren-och-undervakaren/) | Companion volume | — |
| DRK-179 | [The Substrate That Does Not Know It Is Running](https://draken.info/posts/the-substrate-that-does-not-know/) | Companion volume | — |
| DRK-180 | [Jacob's Organ](https://draken.info/posts/jacobs-organ/) | Companion volume | — |
| DRK-181 | [The Countable Mouth: One Propagation Operator from Vacuum to Vocabulary](https://draken.info/posts/the-countable-mouth/) | Argument | Ch. 7, 14 |
| DRK-182 | [The Held Mouth: Gleipnir, Ragnarök and the Binding Made of Absences](https://draken.info/posts/the-held-mouth/) | Companion volume | — |
| DRK-183 | [The Keeper at the Crossing](https://draken.info/posts/the-keeper-at-the-crossing/) | Companion volume | — |
| DRK-184 | [The Bite: Collateral, Hostage and the Mouth That Closes](https://draken.info/posts/the-bite/) | Companion volume | — |
| DRK-185 | [The Bootstrap Inception](https://draken.info/posts/bootstrap-inception/) | Argument | Ch. 5, 10, 14 |
| DRK-186 | [Konkurrent: Currere, the Continuity Equation, and the Verb That Runs From Algorithm to Autonomy](https://draken.info/posts/konkurrent/) | Argument | Ch. 10, 16 |
| DRK-187 | [The Bottle Has No Outside](https://draken.info/posts/the-bottle-has-no-outside/) | Argument | Ch. 3 |
| DRK-188 | [The Damper and the Wastegate](https://draken.info/posts/the-damper-and-the-wastegate/) | Argument | Ch. 16 |
| DRK-189 | [The Carrier and the Cargo: Phase Synchrony, Representational Content, and the Cohomology of a Shared Belief](https://draken.info/posts/the-carrier-and-the-cargo/) | Argument | Ch. 1, 4, 5, 10, 13, 14, 20 |
| DRK-190 | [The Warded Class: Quantum Codes as Sheaves, and What H¹ Protects](https://draken.info/posts/the-warded-class/) | Argument | Ch. 1, 7, 9, 10, 12 |
| DRK-191 | [The Compressed Will: Sigils, Grimoires, Egregores and Curses as Operations on Symbolic Maps](https://draken.info/posts/the-compressed-will/) | Argument | Ch. 6 |
| DRK-192 | [The Stal King: Stalking, the Eye on the Stalk, and the Germ at the Point](https://draken.info/posts/the-stal-king/) | Argument | Ch. 2 |
| DRK-193 | [The Earth Engine: A Sun-Fired Cascade, Minds as Charge, and the Failure Modes of a Planet](https://draken.info/posts/the-earth-engine/) | Argument | Ch. 7, 15, 16 |
| DRK-194 | [The Conviction Gate: How a Pattern Becomes a Belief That Acts](https://draken.info/posts/the-conviction-gate/) | Argument | Ch. 17 |
| DRK-195 | [The Weaponised Conviction: Recruitment, Amplification, and the Self Turned Inward](https://draken.info/posts/the-weaponised-conviction/) | Argument | Ch. 17, 18 |
| DRK-196 | [Zero Range: Claws, Cramps, and the Animal That Kills From Afar](https://draken.info/posts/zero-range/) | Companion volume | — |
