# Part IV — Dynamics and Inference

## 15 Diffusion, Relaxation and Early Warning

### 15.1 Sheaf diffusion

The simplest dynamics consistent with the Hodge spine is gradient descent on disagreement energy. It is the heat equation on the sheaf:
$$\dot x=-\kappa L_{\mathcal F}x,\qquad \kappa>0 .$$
Hansen & Ghrist (2021) analyse it as opinion dynamics on discourse sheaves **[E]**.

v4.4 also derived the same equation from active inference. Each node descends its local variational free energy under Gaussian generative models with precision Π, which yields $\dot x=-\Pi Lx$ in the isotropic case (Friston 2010). That derivation is retained with status **[S]**.

**Theorem 15.1 (Convergence).** Let $P$ project onto $H^0$ and $x(t)=e^{-\kappa Lt}x_0$. Then:

(i) $Px(t)=Px_0$ for all $t$. Diffusion never changes the global section.

(ii) $\|(I-P)x(t)\|\le e^{-\kappa\lambda_1^+t}\,\|(I-P)x_0\|$.

(iii) If $Px_0\neq0$, then $1-\Gamma_0(x(t))\le e^{-2\kappa\lambda_1^+t}\,\|(I-P)x_0\|^2/\|Px_0\|^2$.

*Proof.* Expand $x_0$ in the eigenbasis of $L$. Kernel components are constant and every other component decays at rate at least $\kappa\lambda_1^+$. For (iii), $1-\Gamma_0=\|(I-P)x\|^2/(\|Px\|^2+\|(I-P)x\|^2)\le\|(I-P)x\|^2/\|Px_0\|^2$. ∎ **[E]**

The relaxation time is $1/(\kappa\lambda_1^+)$. For the institutional sheaf (Example 4.1) with κ = 1 it is 1.93 reporting cycles. **Diffusion resolves disagreement toward the projection of the initial state, and never toward truth.** Combined with Proposition 5.8: consensus dynamics converge to whatever global section the initial data contained, including a false one **[E/D]**.

**Proposition 15.2 (Forced diffusion).** For $\dot x=-\kappa Lx+f(t)$ with $\sup_t\|(I-P)f\|\le F$:
$$Px(t)=Px_0+\int_0^tPf\,ds,\qquad \limsup_{t\to\infty}\|(I-P)x(t)\|\le\frac{F}{\kappa\lambda_1^+}.$$

*Proof.* Variation of constants applied separately on $H^0$ and on its complement. ∎ **[E]**

Two consequences follow. Forcing along global sections accumulates without restoring force: a whole system can drift together with no internal alarm. Forcing against global sections is held to an amplitude inversely proportional to the spectral gap **[E/D]**.

### 15.2 Relaxation of relational data

**Theorem 15.3 (Irreducible residual).** The gradient flow of $\tfrac12\|\delta^0x-\omega\|^2$,
$$\dot x=-\kappa\,\delta^{0*}(\delta^0x-\omega),$$
converges to $x_\infty=x^\star+Px_0$. The residual converges to
$$\delta^0x(t)-\omega\ \longrightarrow\ -(h+\delta^{1*}y),$$
the harmonic and curl parts of ω. The residual energy decreases monotonically to $E_{\text{obs}}(\omega)$, exponentially at rate at least $2\kappa\lambda_1^+$.

*Proof.* Write $x=x^\star+Px_0+u$ with $u\perp H^0$. Since $\delta^{0*}\omega=\delta^{0*}\delta^0x^\star$ (the harmonic and curl parts lie in $\ker\delta^{0*}$), we get $\dot u=-\kappa Lu$. Apply Theorem 15.1 to $u$ and Proposition 3.2 to the residual. ∎ **[E]**

Theorem 15.3 is the dynamical content of the Hodge spine. Local relaxation is as effective as it can be, and it stops exactly at the obstruction. What remains is invariant under every local effort (Proposition 3.3). It is what a system must either *hold* (as ϰ), *repair by changing its base or transports*, or *deny*, which accrues debt by Hypothesis H7.1 **[E/D]**.

### 15.3 Time-varying restriction maps

When the maps change with time, $\dot x=-\kappa L(t)x+f$ is non-autonomous. If they change slowly compared with the relaxation rate, the state tracks the instantaneous kernel (adiabatic regime). If they change faster, coherence never establishes **[H]**.

The precise adiabatic condition depends on the gap $\lambda_1^+(t)$ and the rate $\|\dot L\|$. A rule of thumb is $\|\dot L\|\ll(\kappa\lambda_1^+)^2$. This is stated as a working hypothesis, not a proved bound **[H]**.

### 15.4 Critical slowing down

**Proposition 15.4.** For the stochastic diffusion $dx=-\kappa Lx\,dt+\sigma\,dW$, each nonzero eigenmode $k$ is an Ornstein–Uhlenbeck process with:

- stationary variance $\sigma^2/(2\kappa\lambda_k)$;
- lag-Δ autocorrelation $e^{-\kappa\lambda_k\Delta}$.

As $\lambda_1^+\to0$, the variance and autocorrelation of the slowest mode diverge.

*Proof.* The modes decouple; each is an OU process with mean-reversion rate $\kappa\lambda_k$. ∎ **[E]**

The proposition gives *one* mechanism for the early-warning signals of Scheffer et al. (2009). In that literature, critical slowing down is the signature of a nonlinear system approaching a bifurcation. In the linear sheaf model, the same statistical signature, rising variance and autocorrelation, arises when the spectral gap closes, i.e. when the system approaches *fragmentation* ($b_0$ about to increase) **[E]**. The link is structural, not a derivation of the bifurcation result **[D]**.

[The Earth Engine](https://draken.info/posts/the-earth-engine/) (DRK-193) predicts the same signature before stage failures. Proposition 15.4 gives the prediction a mechanism and an observable: the projection of the data onto the eigenvector of $\lambda_1^+$ (Prediction P9) **[D]**.

### 15.5 Nonlinear coupling

Kuramoto coupling (Section 13.1) and bounded confidence (Section 13.2) are the two nonlinear dynamics used in v5.0. Both reduce to Theorem 15.1 near consensus. Both can create or destroy edges or phase locks far from it, which changes the complex itself. Coherence measured across such a transition must report the change of base (Axiom A3) **[E/D]**.

### 15.6 Structured noising and generative reversal

Denoising diffusion models generate data by learning to reverse a noising process. In the standard forward process,
$$q(x_t\mid x_{t-1})=\mathcal N\big(\sqrt{1-\beta_t}\,x_{t-1},\ \beta_tI\big),$$
and the reverse step uses a learned *score*, $\nabla\log p_t$. This is the setting of Ho, Jain & Abbeel (2020) and Song & Ermon (2019). The continuous-time reversal is Anderson's reverse-time SDE (Anderson 1982), as used by Song et al. (2021) **[E]**.

[The Sleepless Section](https://draken.info/posts/the-sleepless-section/) (DRK-164) reads hallucination as this reverse process running without sensory anchoring. The mathematical content carried into v5.0 is that the stochastic sheaf diffusion of Proposition 15.4 is a *sheaf-structured forward process* **[D]**.

**Proposition 15.5.** For $dx=-\kappa Lx\,dt+\sigma\,dW$ started at $x_0$:

(i) Given $x_0$, $x_t$ is Gaussian with mean $e^{-\kappa Lt}x_0$. In eigenmode $k$ with $\lambda_k>0$, its variance is
$$\frac{\sigma^2}{2\kappa\lambda_k}\big(1-e^{-2\kappa\lambda_kt}\big).$$
On $H^0$ the variance is $\sigma^2t$.

(ii) On the non-global modes, the stationary law is $p_\infty(x)\propto\exp\!\big(-\tfrac{\kappa}{\sigma^2}\langle x,Lx\rangle\big)$. This is the GMRF of Proposition 5.12 with $\tau=2\kappa/\sigma^2$. Its score is $-\tfrac{2\kappa}{\sigma^2}Lx$, so the score is the negative disagreement gradient.

(iii) High-λ modes (local disagreement) are randomised first, at rate $\kappa\lambda_k$. The global section is randomised last, and only diffusively.

*Proof.* The modes decouple into independent Ornstein–Uhlenbeck processes, plus one Brownian motion on $H^0$. Apply the standard OU formulas. ∎ **[E]**

The reverse process therefore generates in the opposite order: global structure first, local detail last. This is the spectral reading of generation as inverse heat dissipation (Rissanen, Heinonen & Solin 2023) **[S]**.

Reading: a generative system whose score is learned from a sheaf-structured prior produces coherent global sections before it fills in local detail. If its anchoring to observations is removed, it still produces globally coherent output, because coherence is built into the score. By Proposition 5.8, globally coherent output can be unsound. [DRK-164](https://draken.info/posts/the-sleepless-section/)'s thesis that hallucination is coherent generation without anchoring is the conjunction of Propositions 15.5 and 5.8 **[E/D]**.

## 16 Flows, Stocks and Economies

### 16.1 The discrete continuity equation

Stocks live on vertices, $\varrho\in C^0$, and fluxes on edges, $j\in C^1$, with $j_e>0$ meaning flow along the orientation of $e$. Conservation with sources $S$ is
$$\dot\varrho=\delta^{0\top}j+S,\qquad(\delta^{0\top}j)_v=\sum_{e\to v}j_e-\sum_{v\to e}j_e,$$
the discrete form of $\partial_t\varrho+\nabla\!\cdot\mathbf j=S$ (Jackson 1998, §6.1; Grady & Polimeni 2010) **[E]**. [Konkurrent](https://draken.info/posts/konkurrent/) (DRK-186) takes this equation as the master object of running, competing and executing **[D]**.

**Proposition 16.1 (Circulation moves without accumulating).** Decompose $j=\delta^0\phi+h+\delta^{1*}y$. Then
$$\dot\varrho=\delta^{0\top}\delta^0\phi+S=L\phi+S .$$
The harmonic and curl parts of a flux change no stock.

*Proof.* $h\in\ker\delta^{0*}$, and $\delta^{0*}\delta^{1*}=(\delta^1\delta^0)^*=0$. ∎ **[E]**

Every flow is therefore a sum of three things:

- **potential-driven transfer**, which alone changes stocks;
- **circulation around holes**: throughput with no net accumulation anywhere, such as money circulating around a trade loop that includes no measured producer;
- **local vortices**: churn inside measured loops.

A system whose flows are mostly circulation is busy without transfer. Separating transfer from circulation in measured flow data is the HodgeRank decomposition (Jiang et al. 2011) applied to flows **[E/D]**.

**The Clinch.** [DRK-186](https://draken.info/posts/konkurrent/) formalises the Clinch as two bodies whose boundary fluxes cancel on contact, $\mathbf j_1=-\mathbf j_2$ on $\partial M_1\cap\partial M_2$. In the discrete picture this is a pair of vertices joined by an edge whose flux is pure exchange: it changes each stock and creates no net source. The approved KO *Clinch* names the varanid wrestling phase (Horn, Gaulke & Böhme 1994, as defined in [Abstraction Depth](https://draken.info/posts/abstraction-depth/), [DRK-108](https://draken.info/posts/abstraction-depth/)) **[D]**.

### 16.2 Stocks, gates and debts

[The Earth Engine](https://draken.info/posts/the-earth-engine/) (DRK-193) indexes stages $k$ (planet, ecosystem, organism, mind, culture). Each stage has:

- a stock $S_k$ with $\dot S_k=R_k-C_k$;
- a gate $g_k\in[0,1]$, the fraction of potential ignition its controls allow;
- a deficit $D_k=\mathcal D[C_k-R_k,1]$ (Section 7.1).

The approved KO *earth engine* names the reading of the Earth system as a sun-fired cascade of such stages **[D]**.

The engine faults that [DRK-193](https://draken.info/posts/the-earth-engine/) catalogues are, formally, gate failures:

| Fault | Gate failure |
|---|---|
| Detonation | Gate stuck open |
| Stall | Gate stuck shut |
| Regulatory capture | Gate coupled to the throttle |

They are mapped onto stage-specific literatures (Scheffer et al. 2009; Lenton et al. 2008; Ostrom 1990; Stigler 1971) with the grades given in [DRK-193](https://draken.info/posts/the-earth-engine/). In v5.0 the gate is the threshold of Section 17.2 at the scale of a stage **[D]**.

[The Damper and the Wastegate](https://draken.info/posts/the-damper-and-the-wastegate/) (DRK-188) models governed waste shedding as a constrained control problem,
$$u(t)=\arg\min_u\|p(t)-p^\ast\|^2+\lambda\,\dot Q_{\text{shed}}(u),$$
in the tradition of Maxwell's governors (Maxwell 1868). The engineering reading is retained as illustration **[M]**.

### 16.3 Replicator dynamics and the bluff kernel

The replicator equation $\dot x_i=x_i\,[f_i(\mathbf x)-\bar\phi(\mathbf x)]$ governs frequency change under differential fitness (Taylor & Jonker 1978; Hofbauer & Sigmund 1998) **[E]**.

[The Substrate and the Game](https://draken.info/posts/the-substrate-and-the-game/) (DRK-130) supplies a worked restriction map. A display state $(F,E,\Delta m,B)\in\mathbb R^4$ (force, energy, mass difference, bluff) restricts to the clinch state $(F_{\max},E_{\text{ratio}},\Delta m)\in\mathbb R^3$ by a projection that discards $B$ **[D]**.

Bluff therefore lies in the kernel of the restriction to the clinch. By Proposition 5.8, the clinch is an *anchor* that makes signals in that kernel worthless. A ritualised contest is a grounding device: it keeps the undetectable subspace of a status display from growing. This is the formal content of the Dragon Scales series, and the subject of the varanid pilot (Prediction P8) **[D]**.

### 16.4 Planning, inference and the Leontief analogy

The Leontief system $x=Ax+d$ has the unique non-negative solution $x^\ast=(I-A)^{-1}d$ when the spectral radius of $A$ is less than 1 (Leontief 1941; Hawkins & Simon 1949) **[E]**.

Minimising $\|x-Ax-d\|^2$, the negative log-likelihood of a Gaussian planning model with flat prior, gives the same solution whenever $I-A$ is invertible. Planning is inference in this narrow sense **[E]**.

[Planning as Inference](https://draken.info/posts/countries-as-collective-minds/) (DRK-118) proposes that this is a global-section problem on a production sheaf. The identification of sectors with vertices and of input coefficients with restriction maps is not functorial as stated, so its grade remains **analogy** **[H]**.

The two failure modes v4.4 described are now formal:

- *Pripiski*, fabricated production reports (Harrison 2011), falsify the anchors. By Proposition 5.8 the planner then converges to a coherent false section.
- Defining ecological costs as externalities deletes restriction maps. By Proposition 5.6 this raises measured coherence by excision (Chapter 19) **[D]**.

### 16.5 Trophic structure: Lindeman, Leontief and the trophic level

Lindeman's trophic-dynamic law states that energy available at level $n$ falls geometrically with transfer efficiency $\mathsf e$:
$$E_n=E_0\prod_{i<n}\mathsf e_i\approx E_0\,\mathsf e^{\,n-1},\qquad\mathsf e\approx0.1 .$$
Persistent contaminants concentrate geometrically in the opposite direction, $C_n=C_p\,\mathsf b^{\,n-1}$ with $\mathsf b>1$ (Lindeman 1942). The geometric law is exact as stated; the value $\mathsf e\approx0.1$ is an empirical regularity with wide variation across ecosystems **[S]**. [The Komodoburger Franchise](https://draken.info/posts/the-komodoburger-franchise/) (DRK-136) builds its equation stack on these two laws **[D]**.

**Proposition 16.3 (Lindeman sheaf).** On the path of trophic levels $1\to2\to\dots\to N$, use stalks $\mathbb R$. On each edge, the tail's restriction map is $\mathsf e$ and the head's is 1. Then $H^0$ is one-dimensional, spanned by the Lindeman profile $(1,\mathsf e,\mathsf e^2,\dots)$. The biomagnification law is the global-section condition of a second sheaf, with map $\mathsf b$, on the *same* base.

*Proof.* Gluing on edge $(n\to n+1)$ requires $x_{n+1}=\mathsf e\,x_n$. Propagate from level 1. ∎ **[E]**

Energy and contaminant are two sheaves over one food web, flowing in opposite geometric directions. This mirrors carrier and cargo (§13.1): one base, two stalks, independent coherences **[D]**.

*Computed.* Measured level energies $(1000,95,11,0.9)$ give observed efficiencies $(0.095,0.116,0.082)$. Rescaling each stalk by $\mathsf e^{-(n-1)}$, a declared change of stalk geometry under Axiom A2, maps the Lindeman sheaf isomorphically onto the constant sheaf, with normalised data $(1000,950,1100,900)$. Measured against the producer reference, the deviations score $\Gamma_{\tau^\ast}=0.37$ **[E]**.

**Proposition 16.4 (Trophic level as a Leontief solution).** Let $\mathsf D$ be the diet matrix, with $\mathsf D_{ij}$ the fraction of consumer $i$'s diet drawn from species $j$ and zero rows for producers. The trophic levels are defined by $\mathrm{TL}=\mathbf 1+\mathsf D\,\mathrm{TL}$ (Levine 1980). They exist uniquely, and are given by
$$\mathrm{TL}=(I-\mathsf D)^{-1}\mathbf 1,$$
if and only if the spectral radius of $\mathsf D$ is below 1. That holds whenever every consumer's diet reaches a producer.

*Proof.* The equation is the Leontief system of §16.4 with $A=\mathsf D$ and final demand $\mathbf 1$. The rows of $\mathsf D$ sum to at most 1, and some mass leaks to producers along every path, so the substochastic matrix has spectral radius below 1 and the Neumann series converges (Hawkins & Simon 1949). ∎ **[E]**

The human trophic level $\mathrm{HTL}=1+\sum_iQ_i\,\mathrm{TL}_i$ is the same equation for one consumer (Bonhommeau et al. 2013) **[E]**.

*Computed* (two producers, a grazer, a fish and a predator): $\mathrm{TL}=(1,1,2,2.5,3.3)$. The food web is acyclic, so $\mathsf D$ is nilpotent **[E]**.

Reading: planning (§16.4) and trophic position are one linear-algebraic object. A sector's input–output position and a species' trophic position are both Leontief solutions of a dependency matrix. The dietary debt $K_{\text{diet}}$ (§7.1) is the ratchet of HTL above its viable value **[E/D]**.

### 16.6 Iteration and closure: the productile monad

[The Productile Monad](https://draken.info/posts/the-productile-monad/) (DRK-140) reads a self-iterating protocol as a monad. A monad is an endofunctor $\mathbb T$ with unit $\eta_{\mathbb T}$ and multiplication $\mu_{\mathbb T}:\mathbb T\mathbb T\to\mathbb T$, satisfying
$$\mu\circ\mathbb T\mu=\mu\circ\mu\mathbb T,\qquad \mu\circ\mathbb T\eta=\mu\circ\eta\mathbb T=1_{\mathbb T}$$
(Mac Lane 1971). When μ is an isomorphism the monad is *idempotent*: applying it twice is the same as applying it once. Sheafification, which turns a presheaf into its best sheaf approximation, is the standard idempotent monad of sheaf theory (Mac Lane & Moerdijk 1994) **[E]**.

**Proposition 16.5 (Repair converges to the idempotent).** Let $R_\tau=(I+\tau L)^{-1}$ and let $P$ be the orthogonal projection onto $H^0$. Then:

(i) $P^2=P=P^\ast$;

(ii) $PR_\tau=R_\tau P=P$;

(iii) $R_\tau^k\to P$ as $k\to\infty$, and $e^{-\kappa Lt}\to P$ as $t\to\infty$;

(iv) $R_\tau$ is idempotent only if $L=0$.

*Proof.* Diagonalise. $R_\tau$ multiplies mode $k$ by $(1+\tau\lambda_k)^{-1}$, which equals 1 on $H^0$ and lies strictly in $(0,1)$ otherwise. Powers of such a factor tend to 0, and $R_\tau^2=R_\tau$ forces every factor to be 0 or 1. ∎ **[E]**

Reading: one repair is not a closure, but iterated repair converges to one. The projection $P^2=P$ of [The Two Optics](https://draken.info/posts/the-two-optics/) (DRK-163) is the idempotent at the end of diffusion (Theorem 15.1) and of iterated Tikhonov repair. A protocol that is "the same protocol, applied again, not a meta-protocol" ([DRK-140](https://draken.info/posts/the-productile-monad/)) is, in the linear model, a protocol that has already converged to $P$ **[E/D]**.

### 16.7 Distillation and divergence energies

Knowledge distillation trains a student network to match a teacher's softened output distribution. The loss is
$$\mathcal L=(1-\lambda)\,\mathrm{CE}\big(y,\sigma(z_s)\big)+\lambda\,T^2\,\mathrm{KL}\big(\sigma(z_t/T)\,\big\|\,\sigma(z_s/T)\big)$$
(Hinton, Vinyals & Dean 2015). [The Two Optics](https://draken.info/posts/the-two-optics/) (DRK-163) reads this as concentration through a lens **[E/D]**.

In sheaf terms, the teacher and student are two vertices, and the student's map is a learned restriction map with an edge discrepancy given by KL rather than by squared distance. This generalises the disagreement energy to divergence-valued edges,
$$E_D(x)=\sum_{e=(u\to v)}D\big(\rho_{ue}x_u\ \big\|\ \rho_{ve}x_v\big).$$
To second order around agreement, KL is half the squared distance in the Fisher metric. Hence $E_D\approx\tfrac12\sum_e\|\delta_e\|^2_{\mathcal I}$: a sheaf Laplacian whose edge inner products are Fisher information (Amari 1998). Under Axiom A2, a divergence-valued Draken model is therefore a declared choice of Fisher geometry on the edge stalks, and every result of Chapters 3–5 applies locally **[E/D]**.

Whatever the student's map discards is its kernel, as for the bluff kernel of §16.3. Distillation can make a student coherent with its teacher while both are unanchored (Proposition 5.8) **[D]**.

## 17 Inference, Belief and Action

### 17.1 Abduction is a lift

Let $O:C^0\to Y$ be the observation operator: the restriction of the full state to what is observed. Given an observation $y$, the hypotheses consistent with it form the affine space $x_0+\ker O$ **[E]**.

- Deduction pushes forward along $O$.
- Abduction chooses a lift: a point of the fibre $O^{-1}(y)$.
- Bayesian abduction chooses the lift that maximises the posterior.

([The Guessed Section](https://draken.info/posts/the-guessed-section/), [DRK-170](https://draken.info/posts/the-guessed-section/)) **[E/D]**.

The fibre is not resolved by the data. Two lifts that differ by an element of $\ker O\cap H^0$ are equally coherent and equally consistent with every observation; this is the undetectable subspace $\mathcal U$ of Proposition 5.8 with $A=O$. **Abduction is the home of the coherent-but-unsound** because its output space is a fibre whose kernel is invisible by construction **[E/D]**.

The more an inference engine fills that fibre with fluent, globally coherent lifts, the more weight falls on anchors that the engine cannot itself supply. This includes current language models, read in [DRK-170](https://draken.info/posts/the-guessed-section/), §7, as mechanised abduction **[H]**.

### 17.2 The conviction gate

Bayesian updating in odds form multiplies prior odds by the likelihood ratio. In predictive-processing accounts, how far a belief moves depends on the relative precision assigned to prediction errors and to priors (Fletcher & Frith 2009; Kapur 2003) **[S]**.

The approved KO *conviction gate* ([The Conviction Gate](https://draken.info/posts/the-conviction-gate/), [DRK-194](https://draken.info/posts/the-conviction-gate/)) is the inequality
$$c\cdot V>\theta,$$
where:

- $c=P(H^\ast\mid D)$ is subjective certainty;
- $V$ is the value attached to acting if $H^\ast$ is true;
- θ is a threshold set by costs, norms and other people.

The gate is where a belief is allowed to command action **[D]**.

Three failure modes follow, one per factor:

- $c$ locked near 1 regardless of evidence;
- $V$ inflated by mission;
- θ lowered by isolation or reward.

*Gate capture* (approved KO, [The Weaponised Conviction](https://draken.info/posts/the-weaponised-conviction/), [DRK-195](https://draken.info/posts/the-weaponised-conviction/)) is the condition in which another agent sets $c$, $V$ or θ **[D]**.

In v5.0 terms, a gate opened by a certainty whose support is self-referential is action driven by a high-$\bar\psi$ belief. The gate's input has no anchor, so the action itself becomes the first contact with reality **[D]**.

### 17.3 Selection and real patterns

[Relevance as Collapse](https://draken.info/posts/relevance-as-collapse/) (DRK-169) reads relevance realisation as selection of one admissible section, $s^\ast=\arg\min_{s\in\mathcal A}S_{\text{sys}}(s)$ subject to $dH/dt\ge0$. It is the optimisation axiom applied to attention. The grade is **[D]**, with no claim that brains solve this program.

[The Compressible Section](https://draken.info/posts/the-compressible-section/) (DRK-157) adopts Dennett's criterion: a pattern is real if its description compresses the data it describes (Dennett 1991; Ladyman & Ross 2007). It adds a gluing question: do locally real patterns assemble into a global one? In v5.0, compressible local descriptions are stalk data. Gluing is an $H^0$ question for the data and an $H^1$ question only for relational descriptions. $\Gamma_{\text{top}}$ is its data-free structural index **[D]**.
