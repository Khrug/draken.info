## 7 The Debt Calculus

### 7.1 One functional, four debts

The corpus contains several integrals called "debt". They share one form.

**Definition 7.1 (Ratchet functional).** For a locally integrable rate $f:[0,T]\to\mathbb R$ and a bounded weight $w\ge0$,
$$\mathcal D[f,w](t):=\int_0^t\big[f(s)\big]^+\,w(s)\,ds,\qquad [a]^+=\max(a,0).$$

**Proposition 7.2.** $\mathcal D$ has the following properties:

(i) $\mathcal D(0)=0$, and $\mathcal D$ is non-decreasing and absolutely continuous.

(ii) It is additive over consecutive intervals.

(iii) $\mathcal D[f,w](t)=0$ if and only if $f\le0$ almost everywhere on $\{w>0\}\cap[0,t]$.

(iv) It is monotone in $f$ and positively homogeneous.

(v) It is subadditive: $\mathcal D[f+g,w]\le\mathcal D[f,w]+\mathcal D[g,w]$.

*Proof.* (i)–(iv) are properties of the Lebesgue integral of a non-negative integrand. (v) follows from $[a+b]^+\le[a]^++[b]^+$. ∎ **[E]**

Subadditivity has a reading. Splitting one excess into two cannot increase the debt, and two excesses that partly cancel accrue less debt together than apart. Debt penalises *net* excess at each instant, not gross activity **[E/D]**.

**The canonical instances.**

| Debt | Rate $f$ | Weight $w$ | Defined in | KO |
|---|---|---|---|---|
| **Coherence debt** $K(t)$ | $\Psi(t)-\Psi_{\text{viable}}$ | irreversibility $w(t)$ | v4.4 eq. (7.1); [The Coherence Debt](https://draken.info/posts/the-coherence-debt/) (DRK-121) | K(t) |
| **Trophic debt** $\Theta(t)$ | $-\dot{\mathcal V}_{\text{exo}}(t)$ | 1 | [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176) | Θ |
| **Stage deficit** $D_k(t)$ | $C_k(t)-R_k(t)$ | 1 | [The Earth Engine](https://draken.info/posts/the-earth-engine/) (DRK-193) | (earth engine) |
| **Dietary debt** $K_{\text{diet}}(t)$ | $\mathrm{HTL}(t)-\mathrm{HTL}_{\text{viable}}$ | $w(t)$ | [The Komodoburger Franchise](https://draken.info/posts/the-komodoburger-franchise/) (DRK-136) | — |

All four are ratchets in the sense of Definition 7.1, so Proposition 7.2 applies to each without further proof **[E]**. Whether they measure the same underlying quantity is a separate, empirical question (Hypothesis H7.3) **[H]**.

### 7.2 Gross debt and outstanding balance

v4.4 said both that K "accumulates monotonically" and that it "can only be reduced through structural intervention". As written, K is monotone by construction and cannot be reduced at all. v5.0 resolves this by separating two quantities **[D]**:

- $K(t)$ is the **gross accrued debt**, monotone.
- The **outstanding balance** is
$$B_K(t):=K(t)-P_K(t),$$
where $P_K$ is the non-decreasing cumulative discharge recorded at correction events: reforms, reintroductions, repairs, or (in the code picture of Section 12.3) decoder corrections.

Two diagnostics follow. A system with high $K$ and low $B_K$ has paid its bills. A system with high $B_K$ is running a deficit that, on the Draken reading, is discharged eventually. The discharge is either deliberate or forced by a correction event, which [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176) models as a basin-boundary metamorphosis (Grebogi, Ott & Yorke 1987) **[D]**.

### 7.3 Quantities renamed out of the debt family

Three corpus integrals are not ratchets and are renamed so that "debt" has one meaning **[D]**:

| Old usage | New name | Formula | Why it is not a debt |
|---|---|---|---|
| "K" in [The Substrate and the Game](https://draken.info/posts/the-substrate-and-the-game/) (DRK-130) | accumulated incoherence $I(t)$ | $\int_0^t\|\delta^0x(s)\|\,ds$ | Not thresholded; any nonzero disagreement accrues |
| "K" in [The Finite Sheaf](https://draken.info/posts/the-finite-sheaf/) (DRK-141) | claim–measurement gap $G(t)$ | $\int_0^t(\Gamma_{\text{claimed}}-\Gamma_{\text{measured}})\,ds$ | Signed; can decrease |
| "K" in [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176) | curvature load $C(t)$ | $\int_0^t\|\delta^1\omega(s)\|\,ds$ | A load from curvature (Prop. 3.4), not an excess over a threshold |

The positive part of the claim–measurement gap, $K_\Gamma:=\mathcal D[\Gamma_{\text{claimed}}-\Gamma_{\text{measured}},1]$, *is* a ratchet. It is the most directly measurable instance of the K-family, because it needs no NLP pipeline for Ψ, only a reported coherence and a measured one **[D]**.

### 7.4 Debt and obstruction

**Hypothesis H7.1 (Masked obstruction).** Coherence debt accrues fastest when a system reports an obstruction as resolved. That is, $\dot K$ is bounded below by a positive multiple of $E_{\text{obs}}$ whenever $\Gamma_{\text{claimed}}>\Gamma_{\text{measured}}$. Irreducible disagreement that is acknowledged costs maintenance. Irreducible disagreement that is denied accrues debt **[H]**.

The toric code gives the most literal model of silent accrual. An error string of length ℓ produces a syndrome of weight 2 regardless of ℓ. Damage therefore grows below the reporting surface until it crosses $d/2$ and is "settled" all at once by a wrong correction ([The Warded Class](https://draken.info/posts/the-warded-class/), [DRK-190](https://draken.info/posts/the-warded-class/), §7) **[E/D]**. In debt terms, the balance $B_K$ grows invisibly whenever the system's checks have low soundness (Section 9.3) **[D]**.

**Hypothesis H7.2 (Co-divergence).** As $\bar\psi\to1$, $\dot K$ and $\dot\Theta$ diverge together. Coherence debt is the epistemic bill and trophic debt the metabolic bill of the same closed loop ([Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/), [DRK-176](https://draken.info/posts/the-ouroboros-debt/)) **[H]**.

**Hypothesis H7.3 (Unity of debts).** The stage deficit $D_k$ is an instance of Θ, i.e. over-consumption of a stage destroys exogenous variety. [The Earth Engine](https://draken.info/posts/the-earth-engine/) (DRK-193) leaves this open; so does v5.0 **[H]**.

**Hypothesis H7.4 (Subsidised pathology).** Let $S$ be the trophic surplus (intake minus maintenance). The maximum sustainable self-reference increases with accumulated surplus: $\bar\psi^{\text{sust}}_{\max}=g\big(\int_0^tS\,ds\big)$ with $g'>0$. An energy-rich system can carry a deeper self-model further from reality before correction ([Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/), [DRK-176](https://draken.info/posts/the-ouroboros-debt/)) **[H]**.

### 7.5 Care and variety

The care operator (Norm N2) needs a variable.

Let $\mathcal V$ be *variety*: the logarithm of the number of distinguishable states of a system (Ashby 1956), estimated operationally as the Shannon entropy of its observed state distribution. Following [The Countable Mouth](https://draken.info/posts/the-countable-mouth/) (DRK-181), split its rate of change as
$$\dot{\mathcal V}=\dot{\mathcal V}_{\text{endo}}+\dot{\mathcal V}_{\text{exo}}:$$ **[D]**

- $\dot{\mathcal V}_{\text{endo}}$ is variety generated within the system (mutation, invention);
- $\dot{\mathcal V}_{\text{exo}}$ is the change the agent causes in the variety of what it is coupled to **[D]**.

The approved KO states care as $\dot{\mathcal V}_{\text{exo}}=0$ ([The Bridge and the Burn](https://draken.info/posts/the-bridge-and-the-burn/), [DRK-162](https://draken.info/posts/the-bridge-and-the-burn/)). [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176) writes the care condition as $\dot{\mathcal V}_{\text{exo}}\ge0$. v5.0 reconciles the two as follows **[D]**:

- **Care is the zero-contribution constraint.** The agent neither destroys nor homogenises what it is bound to; this covers imposing its own form on others, which raises its share of their state while lowering their variety.
- **Accounting is asymmetric.** Only the destructive side accrues trophic debt, $\Theta=\mathcal D[-\dot{\mathcal V}_{\text{exo}},1]$.

The optimisation axiom N1 constrains the system's own diversity ($dH/dt\ge0$). N2 constrains its effect on others' variety. Together they forbid both self-simplification and export of simplification **[D]**.

---

## 8 Abstraction Depth α

**Definition 8.1 (Path abstraction depth).** For a path $\gamma=v_0\to v_1\to\dots\to v_k$ in the support or command complex,
$$\alpha(\gamma)=\sum_{i=0}^{k-1}\Big(1-\cos\angle\big(\rho_{v_ie_i}x_{v_i},\ \rho_{v_{i+1}e_i}x_{v_{i+1}}\big)\Big),$$
with the convention $\cos\angle(\cdot,0)=0$. This is the v4.4 formula. Each term lies in $[0,2]$ and measures how much meaning is lost or turned across one representational hop **[D]**.

v4.4 noted that α is path-dependent. v5.0 removes the dependence.

**Definition 8.2.** $\alpha^\ast(u,v):=\min_{\gamma:u\to v}\alpha(\gamma)$.

**Proposition 8.3.** $\alpha^\ast$ is well defined on a finite connected complex, computable by Dijkstra's algorithm, symmetric when the edge terms are symmetric, and satisfies the triangle inequality $\alpha^\ast(u,w)\le\alpha^\ast(u,v)+\alpha^\ast(v,w)$.

*Proof.* The edge weights are non-negative and the graph is finite. A concatenation of paths is a path. ∎ **[E]**

The individual edge weights $1-\cos$ do not satisfy a triangle inequality. Only the minimal-path form is a pseudometric, and only it should be compared across systems **[E/D]**.

**Approved KO.** Abstraction depth is "the number of representational layers between a claim to power and the capacity that underlies it" ([Abstraction Depth](https://draken.info/posts/abstraction-depth/), [DRK-108](https://draken.info/posts/abstraction-depth/)). $\alpha^\ast$ from the claim vertex to the capacity vertex is its weighted, path-independent measurement **[D]**.

**Prediction (P3, retained).** Across institutions with comparable complexes, $\alpha^\ast$ from claim to capacity correlates positively with time-to-correction after a falsifying event **[H]**.

The v4.4 historical table, which assigned α from 0 for varanid combat to 7–10 for the attention economy, is retained in the companion volume as an illustrative ordering, not a measurement **[H]**.

---

## 9 The Invariant and the Warded Triple

### 9.1 Metrics versus invariant

[The Invariant](https://draken.info/posts/the-invariant/) (DRK-175) distinguishes two species of quantity:

- *metrics* (Γ, Ψ, K): continuous, frame-dependent energy functionals;
- *the invariant* ϰ: discrete, preserved under deformation that does not change the base.

The Hodge spine makes the distinction exact. Metrics are norms of projections. ϰ is a cohomology class, invariant under gauge (Proposition 3.3) and changed only by changing the complex (Proposition 3.7) **[E/D]**.

The **coherence genus** is $b_1=\dim H^1$, the number of independent irreducible ways local relations fail to integrate. For the constant sheaf $\mathbb R^d$ on a graph,
$$b_1=d\,(|E|-|V|+c),$$
where $c$ is the number of components **[E]**.

On the justification offered in [DRK-175](https://draken.info/posts/the-invariant/) for calling ϰ *the* invariant:

- The linking number of two curves is an $H^1$ pairing: the class of one curve in $H_1$ of the other's complement, by Alexander duality (Hatcher 2002) **[E]**.
- The Jones polynomial and Chern–Simons invariants (Witten 1989) are not degree-1 cohomology classes, and Chern numbers live in $H^2$ (Thouless et al. 1982).

The analogy to knot theory therefore holds for linking but not beyond it. The v5.0 claim is limited accordingly **[E/D]**.

### 9.2 The warded triple

The approved KO ([The Warded Class](https://draken.info/posts/the-warded-class/), [DRK-190](https://draken.info/posts/the-warded-class/)) proposes
$$\mathfrak W(\mathcal F):=(b_1,\ d,\ \rho_s):$$

- the rank $b_1$;
- the (co)systole $d$: the least weight of a cocycle that is not a coboundary, i.e. how much local damage flips a class;
- the soundness $\rho_s$: whether local checks register damage in proportion to its size.

The KO writes soundness as ρ. v5.0 writes $\rho_s$ to keep ρ for restriction maps (Appendix A) **[D]**.

[DRK-190](https://draken.info/posts/the-warded-class/), §9, identifies a gap: $d$ and $\rho_s$ need a weight on real cochains before they can be measured on Draken sheaves. v5.0 closes the gap for soundness **[D]**.

**Proposition 9.1 (Spectral soundness).** For every $f\in C^1(X;\mathcal F)$ over $\mathbb R$,
$$\|\delta^1f\|\ \ge\ s_1\cdot\operatorname{dist}(f,Z^1),\qquad s_1:=\sqrt{\lambda^+_{\min}(\Delta^2)},$$
where $Z^1=\ker\delta^1$ and $\lambda^+_{\min}$ is the smallest nonzero eigenvalue. The constant is sharp.

*Proof.*

1. By Theorem 3.1, $f-\Pi_{Z^1}f=\Pi_{\text{curl}}f\in\operatorname{im}\delta^{1*}=(\ker\delta^1)^\perp$.
2. On that subspace, $\|\delta^1v\|\ge s_1\|v\|$, where $s_1$ is the smallest nonzero singular value of $\delta^1$.
3. Equality holds for the corresponding singular vector. ∎ **[E]**

$s_1$ is the ℓ²-analogue of the coboundary-expansion constant of Linial & Meshulam (2006) and Gromov (2010), as reported in [DRK-190](https://draken.info/posts/the-warded-class/) **[E/D]**:

- a sheaf with $s_1$ bounded below raises alarm in proportion to damage;
- $s_1\to0$ is silent drift.

The systole $d$ remains defined only over $\mathbb F_2$ (codes), or over a declared integer lattice of periods. A real-valued instrument for $d$ is an open problem **[D]**.

### 9.3 Regimes

The regime table of [DRK-190](https://draken.info/posts/the-warded-class/), §8, restated with the spectral instrument **[D]**:

| Regime | Signature | Reading |
|---|---|---|
| Totalised | $b_1=0$ | Nothing held. The unknot of [DRK-175](https://draken.info/posts/the-invariant/); [The Totalitarian Sheaf](https://draken.info/posts/the-totalitarian-sheaf/) (DRK-125) |
| Fragile plurality | $b_1$ large, $d$ small | Many differences, each cheap to overwrite |
| Silent drift | $d$ adequate, $s_1\approx0$ | Differences guarded, but damage accumulates unseen and settles at once |
| Warded | $b_1>0$ bounded, $d$ large, $s_1$ bounded below | The difference is held, guarded and watched |

### 9.4 The target is not zero

**Normative corollary 9.2.** Interventions should keep $b_1>0$ and bounded, raise $d$, and keep $s_1$ bounded below. This means preserving the system's capacity to hold irreducible difference, protecting each difference against cheap erasure, and keeping the watchers proportionate. The corollary follows N1 and N2, applied to the invariant ([The Invariant](https://draken.info/posts/the-invariant/), [DRK-175](https://draken.info/posts/the-invariant/), §5) **[D]**.

There are exactly two ways to drive $b_1$ to zero:

- *by gluing*: adding faces or anchors that resolve the holes with measured data;
- *by excision*: deleting the cells that carried the holes.

The first is coherence; the second is totalisation. Chapter 19 makes the distinction a theorem **[D]**.

**Hypothesis H9.3 (Basin metamorphosis as an $H^1$ jump).** When a self-referential loop tips from cycle to singularity, the separatrix structure changes discontinuously. If the dynamics are encoded as a sheaf over a cover of the state space, the change appears as a jump in $b_1$ ([Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/), [DRK-176](https://draken.info/posts/the-ouroboros-debt/), §3; Grebogi, Ott & Yorke 1987) **[H]**.

### 9.5 Creating held difference

Excision lowers $b_1$ (Theorem 19.2(iv)). The inverse operation, attaching cells, can raise it. The cleanest example is a change of surface genus. For the constant sheaf $\mathbb R$:
$$H^1(S^2;\mathbb R)=0,\qquad H^1(T^2;\mathbb R)\cong\mathbb R^2 .$$
A sphere holds no irreducible circulation. A torus surface holds two independent ones, which are exactly the two logical qubits of the toric code (Example 4.5). A *solid* torus (a ball with one tunnel) holds one: $H^1(D^2\times S^1;\mathbb R)\cong\mathbb R$ **[E]**.

[The Sonder Egg](https://draken.info/posts/the-sonder-egg/) (DRK-166) reads gastrulation as such a change. That a through-gut is a tunnel through the body is anatomy (Barresi & Gilbert 2023) **[S]**. The topology needs care: the solid body with a gut tube is a solid torus, with $b_1=1$, while its boundary surface, skin continuous with gut lining, is a torus with $b_1=2$. Which of these is the right base for any Draken reading of development is not established **[H]**. The Draken reading is that development *creates* $b_1$: it opens a channel through which difference can be held, where excision closes one **[D]**.

[DRK-166](https://draken.info/posts/the-sonder-egg/)'s quantitative scaling claim, $\mathrm{AC}(1)\gtrsim2.78\,\mathrm{AC}(0)$, remains excluded (§14.2) **[D]**.

