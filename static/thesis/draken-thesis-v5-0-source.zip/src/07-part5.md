# Part V — Adversaries and Anti-Totalisation

## 18 The Operator Calculus, Revised

v4.4 formalised information operations as operators on a sheaf ([The Grammar of Coherence Destruction](https://draken.info/posts/grammar-of-coherence-destruction/), [DRK-119](https://draken.info/posts/grammar-of-coherence-destruction/)). v5.0 keeps the operators and replaces their detection signatures with ones derived from Chapters 3 and 5. Two v4.4 signatures were wrong and are corrected **[D]**.

### 18.1 Edge noise

**Operator O1.** Independent noise is added to reports, $\tilde x=x+\eta$, or to relational measurements, $\tilde\omega=\omega+\varepsilon$.

**Proposition 18.1 (Noise floors).** For isotropic noise $\varepsilon\sim\mathcal N(0,\sigma^2I)$ on $C^1$:
$$\mathbb E\,E_{\text{grad}}(\varepsilon)=\sigma^2\operatorname{rank}\delta^0,\qquad \mathbb E\,E_{\text{harm}}(\varepsilon)=\sigma^2\,b_1,\qquad \mathbb E\,E_{\text{curl}}(\varepsilon)=\sigma^2\operatorname{rank}\delta^1 .$$
Each normalised energy $E_\bullet(\varepsilon)/\sigma^2$ is $\chi^2$-distributed with that many degrees of freedom.

*Proof.* Orthogonal projection of an isotropic Gaussian onto a subspace of dimension $m$ gives a squared norm distributed as $\sigma^2\chi^2_m$. The subspace dimensions follow from Theorem 3.1. ∎ **[E]**

Proposition 18.1 gives a **significance test for ϰ**: reject "no structural obstruction" when $E_{\text{harm}}(\tilde\omega)$ exceeds the $\chi^2_{b_1}$ quantile scaled by $\sigma^2$. v4.4 identified the signature of noise as high-frequency spectral energy. That is correct for vertex reports, where noise energy in mode $k$ is $\sigma^2\lambda_k$. For relational data the signature is the dimension-proportional split above **[E]**.

### 18.2 False overlap

**Operator O2.** Fabricated edges are added, with restriction maps chosen so that the current data agree on them.

*Correction.* v4.4 claimed that false overlap is detectable as "new zero eigenvalues appearing in the Laplacian". This is impossible. Adding an edge adds a positive semidefinite term, so $\dim\ker L$ cannot increase. By Proposition 5.6, fabricated edges also cannot raise $\Gamma_\tau$ at fixed τ **[E]**.

What false overlap *does* inflate is any measure that counts agreeing overlaps. The *taxamhet* fraction $T$ of [The Finite Sheaf](https://draken.info/posts/the-finite-sheaf/) (DRK-141) is one: it rises by $1/|E|$ per fabricated agreeing edge. False overlap also inflates $\Gamma_{\tau^\ast}$ if the default stiffness is recomputed on the enlarged complex, because $\operatorname{tr}L$ grows and $\tau^\ast$ falls. Axiom A2, which fixes τ, closes that route **[E/D]**.

The signature is edges whose energy is zero and that carry no anchor. Agreement-count measures are therefore not admissible as headline coherence **[D]**.

### 18.3 Boundary censorship

**Operator O3.** Edges, faces or stalks are deleted.

By Theorem 19.2, censorship raises measured coherence without changing any datum. This is the operator the anti-totalisation theorem is built to catch.

The KO *inversion filter* (V.7, [Drakens Ordlista](https://draken.info/posts/drakens-ordlista/), [DRK-117](https://draken.info/posts/drakens-ordlista/)) states the diagnostic in words: "if a structure claims global coherence but requires information suppression at its boundaries, it is a manufactured void". Corollary 19.5 states it as a computation **[D]**.

### 18.4 Substitution at the stalk

**Operator O4.** The report at a vertex is replaced by a value constructed to agree with its neighbours. The least-energy choice is the local harmonic extension:
$$x_v\leftarrow\Big(\sum_{e\ni v}\rho_{ve}^\top\rho_{ve}\Big)^{-1}\sum_{e=(u,v)}\rho_{ve}^\top\rho_{ue}x_u .$$
The approved KO *source laundering* names this ([The Pendragon Source](https://draken.info/posts/the-pendragon-source/), [DRK-165](https://draken.info/posts/the-pendragon-source/)): "a substitution at the stalk … forcing every downstream section to glue to the forgery" **[D]**.

**Proposition 18.2 (Too good to be true).** Let a vertex's report carry honest independent noise of covariance $\sigma^2I$ while its neighbours are held fixed. Then its local energy $E_v=\sum_{e\ni v}\|(\delta^0x)_e\|^2$ satisfies
$$\mathbb E\,E_v\ \ge\ \sigma^2\operatorname{tr}\Big(\sum_{e\ni v}\rho_{ve}^\top\rho_{ve}\Big).$$

*Proof.* Apply Proposition 5.10 to the local energy with only $x_v$ perturbed. The cross term vanishes in expectation, and the noise-free term is non-negative. ∎ **[E]**

A local energy persistently far *below* this floor is evidence that the report was constructed from the neighbours rather than measured. In honest noisy data, perfect agreement is anomalous. The test is a sheaf analogue of forensic tests for fabricated data **[E/D]**.

v4.4 claimed that substitution produces "coherence anomalies two or more hops away". That is not true in general; on a tree no such anomaly can arise. Distant anomalies appear only when the substituted vertex lies on a cycle whose holonomy the substitution changes, or on a path to an anchor **[E]**.

### 18.5 Capture and kayfabe

**Operator O5 (gate capture).** Another agent sets the certainty, value or threshold of a conviction gate (Section 17.2). This is the approved KO of [DRK-195](https://draken.info/posts/the-weaponised-conviction/) **[D]**.

**Operator O6 (kayfabe).** A configuration maintains high Γ, high $\bar\psi$ and collapsing anchors at once: "locally coherent at the cost of severing its accountability to the larger system". This is the approved KO of [The Protocol and the Predator](https://draken.info/posts/asymmetric-power/) (DRK-133). Its signature is the upper-right quadrant of Section 6.3 **[D]**.

### 18.6 Governance versus predation, restated

v4.4 separated legitimate governance from coherence attack by the sign of the change in Γ. Proposition 5.6 shows that this criterion is gameable, since excision raises Γ. The v5.0 criterion is **[D]**:

- **Legitimate governance** raises $\Gamma_\tau$ *on a fixed base*, keeps $b_1>0$, does not reduce soundness $s_1$, does not enlarge the undetectable subspace $\mathcal U$, and does not raise compliance under declared loads (Corollary 19.7).
- **Coherence attack** does any of the following: lowers $\Gamma_\tau$ on a fixed base; raises it only by base reduction; drives $b_1$ to zero by excision; enlarges $\mathcal U$ by removing anchors.

## 19 The Anti-Totalisation Theorem

### 19.1 Base reduction

**Definition 19.1 (Base reduction).** A base reduction replaces $(X,\mathcal F)$ by $(X',\mathcal F')$ through any of the following:

(a) deleting edges, together with the faces that contain them;

(b) deleting faces;

(c) zeroing edge stalks ($\mathcal F(e)\mapsto0$);

(d) deleting vertices, together with their incident cells.

Operations (a) and (c) are *relation excision*. Operation (d) is *stalk excision* ([The Burnt Section](https://draken.info/posts/the-burnt-section/), [DRK-158](https://draken.info/posts/the-burnt-section/)) **[D]**.

### 19.2 The theorem

**Theorem 19.2 (Anti-totalisation).** Fix τ and the vertex data $x$. Then:

(i) Relation excision weakly increases $\Gamma_\tau(x)$ and $\Gamma_0(x)$, and weakly decreases $E(x)$. Deleting every edge gives $\Gamma_\tau\equiv1$ for all $x$.

(ii) Stalk excision weakly decreases the energy of the remaining data.

(iii) Face deletion leaves $E_{\text{grad}}$ and $E_{\text{obs}}$ of any relational datum unchanged. It moves obstruction energy from curl to harmonic, i.e. from attributable to unattributable.

(iv) On a 1-complex, $b_0-b_1=\sum_v\dim\mathcal F(v)-\sum_e\dim\mathcal F(e)$. Hence deleting an edge $e$ either lowers $b_1$, raises $b_0$, or both, by a total of $\dim\mathcal F(e)$.

*Proof.*

(i) Excision removes positive semidefinite terms from $L$, so $L'\preceq L$. Apply Proposition 5.6 to Γ_τ. For Γ_0, $\ker L\subseteq\ker L'$, and projection onto a larger subspace has a larger norm. With no edges, $L=0$.

(ii) Removing a vertex removes its incident edge terms and leaves the other terms unchanged.

(iii) This is Proposition 3.7 read in reverse.

(iv) Rank–nullity applied to $\delta^0$ gives $b_0-b_1=\dim C^0-\dim C^1$. Deleting $e$ lowers $\dim C^1$ by $\dim\mathcal F(e)$. ∎ **[E]**

![The anti-totalisation theorem on the running example. Relations are deleted one at a time with every datum fixed. Unanchored coherence Γ_τ (red, left axis) rises monotonically to 1. The annotations show the cost: the first deletion destroys all held difference (b₁: 2 → 0), and every later one splits the system (b₀ rises). Compliance under a unit load between H and C (blue, right axis) rises at once and becomes infinite when the load is disconnected.](figures/fig6_excision.png){width=90%}

*Computed* (institutional sheaf, $\tau=0.5$ fixed). Edges were deleted in the order X–H, F–H, X–F, X–E, E–C.

| Edges deleted | $\Gamma_{\tau}$ | $b_0$ | $b_1$ | Compliance, load H→C |
|---|---|---|---|---|
| 0 | 0.886 | 2 | 2 | 2.667 |
| 1 (X–H) | 0.915 | 2 | 0 | 4.000 |
| 2 (F–H) | 0.949 | 4 | 0 | ∞ |
| 3 (X–F) | 0.966 | 6 | 0 | ∞ |
| 4 (X–E) | 0.992 | 8 | 0 | ∞ |
| 5 (E–C) | 1.000 | 10 | 0 | ∞ |

The first deletion (X–H) lowered $b_1$ from 2 to 0. Every later deletion raised $b_0$. Measured coherence rose monotonically to 1 with no datum changed **[E]**.

### 19.3 Readings

The theorem has four readings.

1. **Coherence by excision is always available.** Any system can reach $\Gamma=1$ by deleting its relations. This is the formal reason the optimisation axiom N1 is a *norm*: measurement alone cannot forbid the efficient route to coherence. N1 forbids it because excision reduces structural diversity **[D]**.
2. **Atomisation is perfect coherence.** With every relation deleted, every individual is trivially consistent with itself and $b_0$ is maximal. This is the sheaf form of the atomised mass in Arendt's account of totalitarian rule (Arendt 1951), read in [The Totalitarian Sheaf](https://draken.info/posts/the-totalitarian-sheaf/) (DRK-125) **[D]**.
3. **Excision kills the invariant.** By (iv), every deleted relation removes held difference ($b_1$ falls) or splits the system ($b_0$ rises). [The Burnt Section](https://draken.info/posts/the-burnt-section/) (DRK-158) distinguishes "$H^1\to0$ via gluing" from "$H^1\to0$ via excision of stalks". Theorem 19.2 makes the distinction computable **[D]**.
4. **Deleting measurement converts fault into fate.** By (iii), ceasing to measure the interior of a loop turns a local, attributable circulation into a systemic, unattributable class. Diffusion of responsibility has this exact form: the loss is unchanged, but no face can be held for it **[D]**.

### 19.4 The admissibility rule

**Definition 19.3 (Excision report).** Every reported coherence change between $(X,\mathcal F)$ and $(X',\mathcal F')$ carries the excision vector
$$\chi_{\text{exc}}=\big(\Delta\dim C^0,\ \Delta\dim C^1,\ \Delta\dim C^2;\ \Delta E;\ \Delta b_0,\ \Delta b_1\big),$$
together with the coherence recomputed on the common base **[D]**.

**Corollary 19.5 (Inversion filter, computable).** A coherence gain is classified by recomputing it on the original base:

- if it vanishes on the original base, it was produced by excision and is classified as a manufactured void (KO V.7);
- if it persists, it was produced by gluing.

*Proof.* By Theorem 19.2(i), the remaining gain on a fixed base is attributable to changes of data or maps, not to the base. ∎ **[E/D]**

### 19.5 The anchored dual: compliance and Rayleigh monotonicity

Theorem 19.2 shows that an *unanchored* coherence measure rewards excision. Its dual shows that an *anchored* measure punishes it.

**Proposition 19.6 (Rayleigh monotonicity; compliance).** Let $f\in C^0$ be a declared load, and let $\varepsilon>0$. Define the compliance
$$c_\varepsilon(f):=\big\langle f,(L+\varepsilon I)^{-1}f\big\rangle .$$
Then $c_\varepsilon(f)$ is non-decreasing under relation excision and non-increasing under adding relations.

As $\varepsilon\to0$ with $f\perp H^0$, $c_\varepsilon(f)\to\langle f,L^+f\rangle$. For the constant scalar sheaf and $f=\mathbf e_u-\mathbf e_v$, this limit is the effective resistance between $u$ and $v$. If excision disconnects the support of $f$, the compliance diverges **[E]**.

*Proof.* Excision gives $L'\preceq L$, hence $L'+\varepsilon I\preceq L+\varepsilon I$. Inversion reverses the order. The effective-resistance identity is standard (Doyle & Snell 1984). ∎ **[E]**

For the constant scalar sheaf this is Rayleigh's monotonicity law: cutting wires never lowers resistance (Doyle & Snell 1984) **[E]**.

Compliance has a second meaning that ties it to measurement. When node values are estimated from noisy relative measurements, the variance of the estimated difference between $u$ and $v$ is proportional to the effective resistance between them (Barooah & Hespanha 2008). Excision therefore raises not only the cost of carrying a load but also the uncertainty with which the remaining system can know its own differences. Unanchored coherence goes up while the ability to verify it goes down **[E/D]**.

*Computed* (institutional sheaf, unit load between H and C). The compliance is 2.667 on the full complex, 4.000 after deleting X–H, and infinite once F–H is also deleted and H is disconnected. Over the same deletions, the unanchored $\Gamma_\tau$ rose from 0.886 toward 1 (§19.2) **[E]**.

**Topology optimisation.** Structural topology optimisation removes material deliberately. It minimises compliance $f^\top K(\varrho)^{-1}f$ subject to $K(\varrho)u=f$ and a volume bound $\int\varrho\le V^\ast$ (Bendsøe & Sigmund 2003). [The Compartmentalized Manifold](https://draken.info/posts/the-compartmentalized-manifold/) (DRK-161) applies this formulation to institutional design **[E/D]**.

Engineering has long had the answer to totalisation:

- **Excision is permitted only under a load.** The load $f$ is an anchor, and removing a member that carries load is penalised by the objective itself.
- **Without a load,** the optimum is to remove everything, which is Theorem 19.2(i).

**Corollary 19.7 (Anchored admissibility).** A coherence intervention is admissible only if two conditions hold:

- it passes Corollary 19.5 (the gain persists on the original base);
- it does not raise the compliance $c_\varepsilon(f)$ for the declared loads $f$, i.e. for the demands the system exists to carry.

The first condition forbids hidden excision. The second forbids visible excision that sheds load-bearing relations **[D]**.

*Proof of consistency.* By Proposition 19.6, any relation excision weakly raises compliance, and it raises it strictly when the deleted relation carries part of the load. ∎ **[E]**

### 19.6 The rule applies to Draken

The corpus's structural score, Watertightness $W$, is computed over the fixed set of published posts (Chapter 23). Raising $W$ by unpublishing poorly referenced posts would be excision under Definition 19.1 **[D]**.

v5.0 therefore lists the disposition of every DRK post (Appendix E). Posts excluded from the monograph are excluded from its argument, not from the corpus. The anti-totalisation principle applies to Draken itself **[D]**.
