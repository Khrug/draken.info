# Part II — Measures

## 5 Coherence Γ

The approved KO defines Γ as tracking "how well local sections glue into a globally consistent picture" ([The Kaiju Manifesto](https://draken.info/posts/kaiju-manifesto/), [DRK-105](https://draken.info/posts/kaiju-manifesto/)). The corpus contains four inequivalent formulas for it:

- v4.4: $1-R$;
- [Bootstrap Inception](https://draken.info/posts/bootstrap-inception/) (DRK-185): $1-\|\delta s\|/\|s\|$;
- [The Compressible Section](https://draken.info/posts/the-compressible-section/) (DRK-157): a dimension ratio;
- [The Carrier and the Cargo](https://draken.info/posts/the-carrier-and-the-cargo/) (DRK-189): the order parameter.

This chapter fixes one canonical measure and derives the others as limits, bounds or special cases **[D]**.

### 5.1 Definition

**Definition 5.1 (Resolvent coherence).** For vertex data $x\neq0$ and stiffness $\tau>0$,
$$\Gamma_\tau(x)\;:=\;\frac{\big\langle x,\ (I+\tau L_{\mathcal F})^{-1}x\big\rangle}{\langle x,x\rangle}.$$
The default stiffness is $\tau^\ast:=\dim C^0/\operatorname{tr}L_{\mathcal F}$, the reciprocal mean eigenvalue. It is computed once on the reference base and then held fixed for every comparison (Axiom A2) **[D]**.

Γ in v5.0 means $\Gamma_{\tau^\ast}$ unless another τ is declared **[D]**.

**Proposition 5.2 (Repair-cost form).**
$$\Gamma_\tau(x)=1-\frac{\mathcal C_\tau(x)}{\|x\|^2},\qquad \mathcal C_\tau(x):=\min_{y\in C^0}\Big\{\|y-x\|^2+\tau\,\langle y,L_{\mathcal F}y\rangle\Big\}.$$
The minimiser is $y^\ast=(I+\tau L)^{-1}x$.

*Proof.* Write $M=I+\tau L$, which is positive definite. Then
$$\|y-x\|^2+\tau\langle y,Ly\rangle=\langle y,My\rangle-2\langle x,y\rangle+\|x\|^2 .$$
This is minimised at $y^\ast=M^{-1}x$, with minimum value $\|x\|^2-\langle x,M^{-1}x\rangle$. ∎ **[E]**

Reading: Γ is one minus the normalised cost of the cheapest *coherent repair*. The repair may change the data (cost $\|y-x\|^2$) or leave disagreement in place (cost $\tau E(y)$). The stiffness τ is the exchange rate between the two: the price of a unit of disagreement in units of a unit of data change. This is the resolvent (Tikhonov) smoother of graph signal processing (Shuman et al. 2013) applied to sheaves **[E/D]**.

### 5.2 Spectral form, range and limits

Let $L=\sum_k\lambda_kP_k$ be the spectral decomposition, with $P_0$ the projector onto $\ker L=H^0$. Let $w_k=\|P_kx\|^2/\|x\|^2$, so that $\sum_kw_k=1$.

**Proposition 5.3.**

(i) $\displaystyle \Gamma_\tau(x)=\sum_k\frac{w_k}{1+\tau\lambda_k}$.

(ii) $0<\Gamma_\tau(x)\le1$, with equality if and only if $x\in H^0$.

(iii) $\Gamma_\tau$ is non-increasing in τ, and
$$\lim_{\tau\to\infty}\Gamma_\tau(x)=\Gamma_0(x):=\frac{\|P_0x\|^2}{\|x\|^2},\qquad \Gamma_\tau(x)=1-\tau R(x)+O(\tau^2)\ \ (\tau\to0),$$
where $R(x)=E(x)/\|x\|^2$.

*Proof.* (i) Diagonalise $M^{-1}$. (ii) Every term is positive; $\Gamma_\tau=1$ if and only if $w_k=0$ whenever $\lambda_k>0$. (iii) Each term $1/(1+\tau\lambda_k)$ is non-increasing in τ, tends to $\mathbf 1[\lambda_k=0]$, and has derivative $-\lambda_k$ at τ = 0. ∎ **[E]**

Γ_τ is therefore a *spectral shape* of the data: a low-pass filter whose cutoff is set by τ. [Shape Is Spectrum](https://draken.info/posts/shape-is-spectrum/) (DRK-144) reads coherence as a distribution over a basis; in v5.0 the basis is the Laplacian eigenbasis and the reading is Proposition 5.3(i) **[E/D]**.

The dial has three settings:

- Small τ measures only gross local disagreement.
- Large τ measures only global agreement ($\Gamma_0$).
- τ* sits at the system's own mean scale.

The Kuramoto ring of Section 4.6 shows why the dial is necessary: high local agreement with no global synchrony gives $\Gamma_{\tau^\ast}=0.60$ and $\Gamma_0=0.02$ **[E]**.

### 5.3 Bounds connecting the corpus's formulas

**Proposition 5.4.** Let $\lambda_1^+$ and $\lambda_{\max}$ be the smallest nonzero and the largest eigenvalue. Then
$$\max\Big\{\Gamma_0,\ \frac1{1+\tau R}\Big\}\ \le\ \Gamma_\tau\ \le\ \Gamma_0+\frac{1-\Gamma_0}{1+\tau\lambda_1^+},$$
$$1-\frac{R}{\lambda_1^+}\ \le\ \Gamma_0\ \le\ 1-\frac{R}{\lambda_{\max}}=:\Gamma_R .$$

*Proof.*

1. $\Gamma_\tau\ge\Gamma_0$ because every term is non-negative and the $\lambda=0$ terms contribute $\Gamma_0$.
2. $\Gamma_\tau\ge1/(1+\tau R)$ by Jensen's inequality for the convex map $\lambda\mapsto(1+\tau\lambda)^{-1}$ under the weights $w_k$.
3. The upper bound for $\Gamma_\tau$ replaces every nonzero eigenvalue by $\lambda_1^+$.
4. For the second line, $R=\sum_{\lambda_k>0}w_k\lambda_k$ lies between $\lambda_1^+(1-\Gamma_0)$ and $\lambda_{\max}(1-\Gamma_0)$. ∎ **[E]**

How the corpus's formulas relate to the canonical Γ:

- The spectral form $\Gamma_R$ ([DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/)'s "normalised" formula) is an upper bound on $\Gamma_0$.
- The unnormalised v4.4 form $1-R$ is not a coherence measure at all, since it is negative whenever $R>1$.
- [DRK-185](https://draken.info/posts/bootstrap-inception/)'s $1-\|\delta s\|/\|s\|=1-\sqrt{R}$ is a monotone transform of $R$ with the same defect.

All three are retired as headline measures; $\Gamma_R$ is retained as a computable bound **[D]**.

### 5.4 Invariances and the reporting duty

**Proposition 5.5.**

(i) $\Gamma_\tau(cx)=\Gamma_\tau(x)$ for every $c\neq0$.

(ii) $\Gamma_{\tau/a}(x;aL)=\Gamma_\tau(x;L)$ for every $a>0$. Hence $\Gamma_{\tau^\ast}$ is invariant under rescaling every restriction map by the same factor.

(iii) If $Q$ is a block-orthogonal change of stalk bases, with restriction maps transformed accordingly, then $\Gamma_\tau(Qx;QLQ^\top)=\Gamma_\tau(x;L)$.

*Proof.* (i) and (ii) are immediate from Definition 5.1, and $\tau^\ast$ scales as $1/a$. For (iii), $(I+\tau QLQ^\top)^{-1}=Q(I+\tau L)^{-1}Q^\top$. ∎ **[E]**

Part (iii) is the precise form of "coherence does not depend on how each node labels its own coordinates". It underlies the drift prediction of Chapter 20 **[E/D]**.

**Proposition 5.6 (Monotonicity in the relations).** Fix τ. If $L\preceq L'$ in the Loewner order, then $\Gamma_\tau(x;L')\le\Gamma_\tau(x;L)$ for every $x$. In particular:

- adding an edge, with any restriction maps, never raises Γ_τ;
- deleting an edge never lowers it;
- deleting every edge gives $\Gamma_\tau\equiv1$.

*Proof.* $L\preceq L'$ implies $I+\tau L\preceq I+\tau L'$, and matrix inversion is order-reversing on positive-definite matrices. Adding an edge adds the positive semidefinite term $\delta_e^\top\delta_e$. ∎ **[E]**

Proposition 5.6 is the engine of the anti-totalisation theorem (Chapter 19). It also corrects v4.4's "false overlap" signature (Chapter 18) **[D]**.

**Proposition 5.7 (Global-section inflation).** For $s\in H^0$, $s\ne0$:
$$E(x+cs)=E(x)\ \ \text{for all }c,\qquad\text{and}\qquad \Gamma_\tau(x+cs)\to1\ \ (c\to\infty).$$

*Proof.* $\delta^0s=0$, and the $H^0$ weight $w_0\to1$. ∎ **[E]**

**Reporting standard 5.7a.** Γ must always be reported with:

1. the energy $E$;
2. the declared reference $x_{\text{ref}}$ against which data are measured;
3. the stiffness τ;
4. the complex, stalks and restriction maps.

Example 4.1 shows a single dataset scoring 0.886 or 0.453 depending on the reference. A Γ reported alone is not admissible evidence **[D]**.

### 5.5 Coherence is not soundness

**Proposition 5.8 (Blindness to coherent error).** Let $x=x_{\text{true}}+s$ with $s\in H^0$. Then $\delta^0x=\delta^0x_{\text{true}}$, so every function of the disagreements takes the same value on the true state and on the falsified one.

Now let anchors be added: cells $a$ carrying fixed reference data $r_a$, linked to vertices by restriction maps that together form an operator $A$. Then the falsification $s$ is detectable if and only if $As\neq0$. The *undetectable subspace*
$$\mathcal U:=H^0\cap\ker A$$
can only shrink as anchors are added **[E]**.

*Proof.* The first statement is Lemma 2.5 applied to $\delta^0s=0$. With anchors, the anchor residual $Ax-r$ changes by $As$. Adding anchors adds rows to $A$, which shrinks $\ker A$. ∎ **[E]**

This is the formal core of three corpus results:

- "the synchronised lie" ([The Carrier and the Cargo](https://draken.info/posts/the-carrier-and-the-cargo/), [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/), §7);
- the honest referee of [知行合一: When Automation Removes the Only Honest Referee](https://draken.info/posts/zhixing-heyi-honest-referee/) (DRK-131);
- abduction's "coherent-but-unsound" section ([The Guessed Section](https://draken.info/posts/the-guessed-section/), [DRK-170](https://draken.info/posts/the-guessed-section/)).

A system can be perfectly coherent and entirely wrong. Only restriction maps to something outside the system's own sections, the anchors, can tell **[E/D]**.

### 5.6 Estimation

**Proposition 5.9 (Gradient and error propagation).** With $M=I+\tau L$,
$$\nabla_x\Gamma_\tau=\frac{2}{\|x\|^2}\big(M^{-1}x-\Gamma_\tau(x)\,x\big).$$
For measurement error with covariance $\Sigma_x$, the delta method gives $\sigma^2_\Gamma\approx\nabla\Gamma^\top\Sigma_x\nabla\Gamma$. The node-wise norms of $\nabla\Gamma$ rank nodes by their leverage over the score, which is also the order in which a manipulator would attack them **[E]**.

*Proof.* Apply the quotient rule to $\langle x,M^{-1}x\rangle/\langle x,x\rangle$, using the symmetry of $M^{-1}$. ∎

**Proposition 5.10 (Noise bias and its correction).** Let $\tilde x=x+\eta$ with $\mathbb E\eta=0$ and $\operatorname{Cov}\eta=\Sigma$. Then for every symmetric $B$,
$$\mathbb E\big[\langle\tilde x,B\tilde x\rangle\big]=\langle x,Bx\rangle+\operatorname{tr}(B\Sigma).$$
In particular:

- the measured energy is inflated by $\operatorname{tr}(L\Sigma)$;
- the naive $\Gamma_\tau$ is biased toward lower coherence;
- the ratio estimator
$$\widehat\Gamma_\tau=\frac{\langle\tilde x,M^{-1}\tilde x\rangle-\operatorname{tr}(M^{-1}\Sigma)}{\|\tilde x\|^2-\operatorname{tr}\Sigma}$$
is a ratio of unbiased estimators of the numerator and denominator, and is consistent as $\Sigma\to0$ or under averaging of repeated measurements.

*Proof.* $\mathbb E\langle\eta,B\eta\rangle=\operatorname{tr}(B\Sigma)$, and the cross terms vanish because $\mathbb E\eta=0$. ∎ **[E]**

*Computed* (institutional data, isotropic noise, 20,000 replicates):

| σ | mean $E$ (predicted) | naive $\Gamma_{\tau^\ast}$ | debiased | true |
|---|---|---|---|---|
| 0 | 1.840 (1.840) | 0.886 | 0.886 | 0.886 |
| 0.05 | 1.889 (1.890) | 0.883 | 0.886 | 0.886 |
| 0.10 | 2.043 (2.040) | 0.877 | 0.886 | 0.886 |
| 0.20 | 2.646 (2.640) | 0.852 | 0.886 | 0.886 |

Noisy institutions look less coherent than they are. A coherence decline that is not larger than the noise inflation predicted by Proposition 5.10 is not evidence of decline **[E/D]**.

![Measurement noise biases the naive coherence estimate downward; the correction of Proposition 5.10 removes the bias.](figures/fig5_noise.png){width=75%}

### 5.7 The other coherence quantities

| Symbol | Definition | Status |
|---|---|---|
| $\Gamma_{\tau}$ | Definition 5.1 | **Canonical** vertex coherence |
| $\Gamma_0$ | $\|P_{H^0}x\|^2/\|x\|^2=\lim_{\tau\to\infty}\Gamma_\tau$ | Global agreement share. Discontinuous in the restriction maps: generic perturbations give $H^0=0$, so it is reported only for exactly specified sheaves |
| $\Gamma_R$ | $1-R/\lambda_{\max}$ | Spectral upper bound on $\Gamma_0$ (Prop. 5.4) |
| $\Gamma^1$ | $E_{\text{grad}}/\|\omega\|^2$ | Integrability share of relational data (Def. 3.2a) |
| $\Gamma_{\text{top}}$ | $b_0/(b_0+b_1)$ | Structural index of the sheaf alone ([The Compressible Section](https://draken.info/posts/the-compressible-section/), [DRK-157](https://draken.info/posts/the-compressible-section/)); data-free |
| $r^2$ | Kuramoto | Equal to $\Gamma_0$ for unit phasors on a connected graph (Prop. 4.3) |
| $\sigma$, $T$ | Fraction of agreeing edges or overlaps ([DRK-142](https://draken.info/posts/wrestling-with-god/), [DRK-139](https://draken.info/posts/the-welcomed-section/)) | $\ell^0$ coherence: well-posedness check, syndrome complement; not headline (Prop. 5.11) |

v4.4's estimator programme (sampling protocol, uncertainty propagation, adversarial robustness) is now carried by the reporting standard 5.7a and Propositions 5.9–5.10 **[D]**.

**Agreement counts.** The corpus contains two counting measures:

- the *cocycle density* $\sigma(\mathcal F)=\frac1{|E|}\sum_e\chi(e)$, where $\chi(e)=1$ if edge $e$ glues cleanly ([Wrestling with God](https://draken.info/posts/wrestling-with-god/), [DRK-142](https://draken.info/posts/wrestling-with-god/));
- *taxamhet* $T(\mathcal F)$, the fraction of overlaps on which two local classifications agree on the type of object, proposed as the "zeroth-order diagnostic, prior to Γ" ([The Welcomed Section](https://draken.info/posts/the-welcomed-section/), [DRK-139](https://draken.info/posts/the-welcomed-section/); [The Finite Sheaf](https://draken.info/posts/the-finite-sheaf/), [DRK-141](https://draken.info/posts/the-finite-sheaf/)).

Both are $\ell^0$ coherences. They count edges and ignore the size of the disagreement.

- $T$ is σ for sheaves whose stalks are finite sets of types.
- $1-\sigma$ is the normalised weight of the syndrome, the "fraction of violated checks" in the soundness inequality of Section 9.2.

The two families are linked as follows **[E/D]**.

**Proposition 5.11 (Counting versus energy).** For a tolerance $\varepsilon>0$, let $\sigma_\varepsilon$ be the fraction of edges with $\|(\delta^0x)_e\|\le\varepsilon$. Then
$$\sigma_\varepsilon\ \ge\ 1-\frac{E(x)}{|E|\,\varepsilon^2}.$$
Exact agreement ($\varepsilon=0$) is not controlled by $E$ at all. It is discontinuous in the data, and it can be inflated by fabricated agreeing edges (§18.2).

*Proof.* At most $E/\varepsilon^2$ edges can carry squared disagreement greater than $\varepsilon^2$, by Markov's inequality applied to the edge energies. ∎ **[E]**

*Computed* (institutional sheaf, $\varepsilon=0.8$): $\sigma_{0.8}=0.80$, against a guaranteed lower bound of 0.425 **[E]**.

Reading: T and σ answer a different question from Γ. Γ asks how much repair coherence costs. T and σ ask whether the stalks share a type space at all; if they do not, restriction maps are undefined and no Γ can be computed. They are retained as the *well-posedness check* that precedes Γ, and as the discrete side of soundness. They are not admissible as headline coherence **[D]**.

### 5.8 The repair is a posterior mean

The resolvent of Definition 5.1 has an exact probabilistic reading. That reading connects Γ to Gaussian Markov random fields and to the denoisers of diffusion models (§15.6) **[E]**.

**Proposition 5.12 (Bayesian and score form).** Give the signal $y\in C^0$ the intrinsic Gaussian Markov random field prior with precision $\tau L_{\mathcal F}$:
$$p(y)\propto\exp\!\big(-\tfrac\tau2\langle y,Ly\rangle\big),$$
flat on $H^0$ (Rue & Held 2005). Observe $x=y+\xi$ with $\xi\sim\mathcal N(0,I)$. Then:

(i) $\mathbb E[y\mid x]=(I+\tau L)^{-1}x$, the repair $y^\ast$ of Proposition 5.2. Hence
$$\Gamma_\tau(x)=\frac{\langle x,\ \mathbb E[y\mid x]\rangle}{\|x\|^2},$$
and the repair cost $\mathcal C_\tau(x)$ is twice the minimum of the negative log-posterior, up to an additive constant.

(ii) Tweedie's formula holds in the form $\mathbb E[y\mid x]=x+\nabla_x\log p(x)$, with $p$ the marginal density of the observation on the non-global modes (Efron 2011).

(iii) The disagreement energy is a log-density: $E(x)=-\tfrac2\tau\log p(x)+\text{const}$ under the prior.

*Proof.*

(i) The posterior precision is $I+\tau L$ and the posterior mean is $(I+\tau L)^{-1}x$. On $H^0$ the prior precision is zero, so the mean equals the data there.

(ii) In each eigenmode with $\lambda_k>0$, the marginal variance is $1+(\tau\lambda_k)^{-1}$. Then
$$x_k-\frac{x_k}{1+(\tau\lambda_k)^{-1}}=\frac{x_k}{1+\tau\lambda_k},$$
which is the resolvent.

(iii) Take the logarithm of the prior. ∎

The script confirms (i)–(ii) to $3\times10^{-16}$ **[E]**.

Three consequences connect this to the rest of the monograph:

- **Γ is a model-based quantity.** It measures how much of the data survives the best estimate under the prior that disagreement is improbable. τ is the prior's precision, which is why Axiom A2 fixes it.
- **The noise correction of Proposition 5.10 and the noise floor of Proposition 18.1 are Gaussian-model statements of the same kind,** and they apply under the same assumptions.
- **The repair step and the denoising step of a score-based generative model are one operation** when the prior is sheaf-structured (§15.6).

**[E/D]**


---

## 6 Narrative Self-Reference Ψ and Grounding

### 6.1 Definition

The approved KO defines Ψ as "the ratio of narrative self-reference to reality-contact" ([The Kaiju Manifesto](https://draken.info/posts/kaiju-manifesto/), [DRK-105](https://draken.info/posts/kaiju-manifesto/)). Its "psychosis metric" label is retired; the measure is structural, not clinical **[D]**.

The operational form follows v4.4.

- $N_S$ is the finite set of **claims** a system asserts in a declared corpus. A claim is an element of $N_S$; nothing outside $N_S$ is scored.
- $O_S$ is a set of external observations, disjoint from $N_S$.
- Each claim $c\in N_S$ has an evidential support $\operatorname{supp}(c)\subseteq N_S\cup O_S$, assigned by the protocol of §6.5.

Define
$$n_{\text{self}}=|\{c\in N_S:\operatorname{supp}(c)\subseteq N_S\}|,\qquad n_{\text{contact}}=|\{c\in N_S:\operatorname{supp}(c)\cap O_S\ne\emptyset\}|,\qquad \Psi=\frac{n_{\text{self}}}{n_{\text{contact}}}.$$
Unsupported claims, with empty support, count as self-referential **[D]**.

**Lemma 6.1.** Under these definitions $n_{\text{self}}+n_{\text{contact}}=|N_S|$. Hence Ψ is the **odds** of self-support,
$$\Psi=\frac{\bar\psi}{1-\bar\psi}\in[0,\infty],\qquad \bar\psi:=\frac{n_{\text{self}}}{|N_S|}=\frac{\Psi}{1+\Psi}\in[0,1].$$

*Proof.* Each $c\in N_S$ falls in exactly one class. Either $\operatorname{supp}(c)\subseteq N_S$, or it contains an element outside $N_S$. Since supports lie in $N_S\cup O_S$, that element is in $O_S$. The two cases are exclusive because $N_S\cap O_S=\emptyset$. ∎ **[E]**

The bounded companion $\bar\psi$ reconciles the corpus's usage:

- "Ψ → 1" in [The Protocol and the Predator](https://draken.info/posts/asymmetric-power/) (DRK-133, KO *kayfabe*) and in [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176) is read as $\bar\psi\to1$: almost every claim is supported only by other claims.
- Ψ itself is unbounded and diverges in the same limit. Thresholds $\Psi_{\text{viable}}$ are stated in odds **[D]**.

### 6.2 The grounding sheaf

Build a *support complex*:

- vertices: claims;
- edges: support relations between claims, carrying restriction maps that encode what one claim implies about another;
- anchors: observations in $O_S$, attached to the claims they support.

Self-supported claims are those with no path to an anchor. By Proposition 5.8, the falsifications of the narrative that are invisible to every check, internal or external, form $\mathcal U=H^0\cap\ker A$. Adding anchors shrinks $\mathcal U$ **[E/D]**.

**Hypothesis H6.1.** In observed narratives, the undetectable share $\dim\mathcal U/\dim H^0$ increases with $\bar\psi$. Ψ is then an inexpensive observable proxy for the dimension of the space of coherent lies a system could hold without internal or external alarm **[H]**.

### 6.3 Ψ and Γ are independent coordinates

v4.4 conjectured that Ψ and Γ are inversely monotone (its §4.1.2). Proposition 5.8 refutes the conjecture as a law. A system can raise Γ toward 1 by adding a coherent narrative, a global section, while $\bar\psi$ rises, because nothing in Γ consults the anchors. *Functional* independence, meaning that neither measure determines the other, is therefore proved **[E]**. Whether the two are *statistically* correlated in real systems is a separate, empirical question **[H]**. The conjecture is withdrawn as a law **[D]**.

What replaces it is a two-coordinate diagnostic:

| | low $\bar\psi$ (grounded) | high $\bar\psi$ (self-referential) |
|---|---|---|
| **high Γ** | Coherent and accountable | **Kayfabe / synchronised lie / egregore**: locally glued, globally unanchored |
| **low Γ** | Honest disagreement; repairable | Fragmenting self-narratives |

The dangerous quadrant is the upper right:

- *Kayfabe* (KO, [DRK-133](https://draken.info/posts/asymmetric-power/)) names it in the working vocabulary.
- An *egregore* (KO, [The Compressed Will](https://draken.info/posts/the-compressed-will/), [DRK-191](https://draken.info/posts/the-compressed-will/)) is "a well-glued section whose stability no longer depends on any single stalk" (a global section maintained by the gluing itself rather than by anchors) **[D]**.

Whether the empirical joint distribution of (Γ, $\bar\psi$) concentrates off the anti-diagonal is an open question (Prediction P1′, Chapter 22) **[H]**.

### 6.4 Observer-level self-reference

The KO *synchronicity density* σ(t) ([The Common Base](https://draken.info/posts/the-common-base/), [DRK-177](https://draken.info/posts/the-common-base/)) is "the fraction of salient events at time t that the observer reads as addressed to the self". It is the observer-level analogue of $\bar\psi$: interpretation supported only by self-reference **[D]**.

Its methodological companion is base-rate hygiene. With $N\approx10^6$ salient events in 35 days and coincidence probability $p\approx10^{-6}$, the expected number of "unreasonable" coincidences is $Np\approx1$ per month (computed in [DRK-177](https://draken.info/posts/the-common-base/); the one-event-per-month heuristic is the conventional gloss on Littlewood's *Miscellany* (Littlewood 1986), not a theorem in it). A σ(t) excess must be computed against such a base rate before it is read **[E/D]**.

The [The Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176) basin share $\beta_{\text{self}}=\mu(B(A_{\text{self}}))/\mu(X)$ is renamed from Ψ to $\beta_{\text{self}}$. It is the dynamical analogue: the share of state space that flows into the self-model's attractor. A monotone relation between $\beta_{\text{self}}$ and $\bar\psi$ is hypothesised, not derived **[H]**.

### 6.5 Coding protocol for Ψ

Ψ is measurable only under a protocol a second person can apply. v5.0 specifies the following minimum **[D]**.

1. **Corpus.** Declare the documents, the period and the issuing system $S$ in advance.
2. **Claim unit.** A claim is a declarative clause asserting a proposition about $S$ or its situation that could in principle be false. Questions, commands, hedged speculation and pure evaluation without a factual component are excluded. Each claim is entered once; repetitions are de-duplicated by meaning.
3. **Support assignment.** $\operatorname{supp}(c)$ is everything the text itself offers as evidence for $c$: explicit citations, references, data, quotations and inferential markers ("because", "as shown by") within the same paragraph or a referenced appendix.
   - Each item is coded **internal** if it is another claim, statement or document of $S$ itself.
   - Each item is coded **external** if it is an independently produced observation: third-party data, measurements, audited records or independent reports.
   - Mixed items are split. Nothing outside the text is used.
4. **Reliability.** Two coders code a random 20% sample independently. Ψ is reported only if Cohen's κ ≥ 0.70 on the internal/external decision (Landis & Koch 1977). Otherwise the codebook is revised and the sample recoded.
5. **Uncertainty.** Report $\bar\psi$ with a bootstrap interval over claims, and Ψ derived from it.

Automated coding (NLP extraction of claims and support) is admissible only after it reaches κ ≥ 0.70 against the human coders on the same sample. Until a corpus has been coded this way, the computable debt in this monograph is $K_\Gamma$ (§7.3), not $K$ **[D]**.

