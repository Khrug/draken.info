# Appendices

## Appendix A — Notation Registry

Each symbol below has exactly one meaning in v5.0. The right-hand column records corpus usages that were renamed to remove collisions.

| Symbol | Meaning | Defined | Collisions resolved |
|---|---|---|---|
| $X$; $V,E,F$ | Regular 2-complex; vertices, edges, faces | Def. 2.1 | |
| $\mathcal F$, $\mathcal F(\sigma)$ | Cellular sheaf; stalk on cell σ | Def. 2.2 | |
| $\rho_{\sigma\tau}=\mathcal F_{\sigma\trianglelefteq\tau}$ | Restriction map (KO ρ) | Def. 2.2 | Density → $\varrho$; density matrix → $\hat\rho$; soundness → $\rho_s$; spectral radius → $\operatorname{sr}$; productile rank ([DRK-141](https://draken.info/posts/the-finite-sheaf/)) → $P_r$ |
| $C^k$, $\delta^k$ | Cochains, coboundary | Def. 2.4 | |
| $H^k$, $b_k$ | Cohomology, Betti numbers | Def. 2.6 | |
| $L_{\mathcal F}=\Delta^0$ | Sheaf Laplacian (KO) | Def. 3.0 | |
| $\Delta^1,\Delta^2$ | Hodge Laplacians | Def. 3.0 | |
| $\Pi_{\text{grad}},\Pi_{\text{harm}},\Pi_{\text{curl}}$ | Hodge projectors on $C^1$ | §3.2 | |
| $E(x)$ | Disagreement energy $\|\delta^0x\|^2$ | §3.1 | |
| $E_{\text{grad}},E_{\text{harm}},E_{\text{curl}},E_{\text{obs}}$ | Component and obstruction energies | Prop. 3.2, Def. 3.2a | |
| $\mathcal R=\delta^1\omega$ | Curvature of relational data | Prop. 3.4 | |
| $\varkappa(\omega)$ | Draken invariant $[\Pi_{\text{harm}}\omega]$ (KO) | Def. 3.5 | |
| $\Phi_\gamma$ | Holonomy (period) on cycle γ | Prop. 3.6, 4.1 | [DRK-171](https://draken.info/posts/the-dragged-frame/) "Θ" → $\Phi_\gamma$ |
| $\Gamma_\tau$, $\tau^\ast$ | Resolvent coherence (KO Γ); default stiffness | Def. 5.1 | v4.4 $1-R$, [DRK-185](https://draken.info/posts/bootstrap-inception/) $1-\sqrt R$ retired |
| $\Gamma_0,\Gamma_R,\Gamma^1,\Gamma_{\text{top}}$ | Global share; spectral bound; integrability share; structural index | §5.7 | |
| $R(x)$ | Rayleigh quotient $E/\|x\|^2$ | Prop. 5.3 | |
| $\lambda_1^+$, $\lambda_{\max}$ | Spectral gap; top eigenvalue of $L$ | Prop. 5.4 | |
| $\mathcal U$ | Undetectable subspace $H^0\cap\ker A$ | Prop. 5.8 | |
| $\Psi$, $\bar\psi$ | Narrative self-reference (odds, KO); bounded share | §6.1 | [DRK-176](https://draken.info/posts/the-ouroboros-debt/) basin "Ψ" → $\beta_{\text{self}}$; quantum Ψ → $\lvert\psi\rangle$ |
| $\sigma(t)$ | Synchronicity density (KO) | §6.4 | |
| $\mathcal D[f,w]$ | Ratchet functional | Def. 7.1 | |
| $K(t)$, $B_K$, $P_K$, $K_\Gamma$ | Coherence debt (KO); balance; discharge; measurable instance | §7.1–7.3 | [DRK-130](https://draken.info/posts/the-substrate-and-the-game/), [DRK-141](https://draken.info/posts/the-finite-sheaf/), [DRK-176](https://draken.info/posts/the-ouroboros-debt/) "K" → $I(t)$, $G(t)$, $C(t)$ |
| $\Theta(t)$ | Trophic debt (KO) | §7.1 | |
| $D_k$ | Stage deficit (earth engine) | §7.1 | |
| $\mathcal V$, $\dot{\mathcal V}_{\text{exo}}$ | Variety; exogenous variety change (care, KO) | §7.5 | |
| $\alpha$, $\alpha^\ast$ | Abstraction depth (KO); path-minimal form | Def. 8.1–8.2 | |
| $\mathfrak W=(b_1,d,\rho_s)$, $s_1$ | Warded triple (KO); spectral soundness | §9.2 | |
| $S_{\text{sys}}$, $H$ | Disorder; structural diversity (Norm N1) | §2.1 | |
| $c,V,\theta$ | Certainty, value, threshold (conviction gate, KO) | §17.2 | |
| $\chi_{\text{exc}}$ | Excision report | Def. 19.3 | |
| $\mathcal K\to\mathcal E\to\mathcal Q$ | Short exact sequence of sheaves | Def. 3.9 | Calligraphic; distinct from debt $K(t)$ |
| $\partial$, $\omega_q$ | Connecting map; lifting datum | Thm. 3.10, Prop. 3.11 | |
| $\sigma$; $\sigma(t)$; $\sigma(\mathcal F)$, $\sigma_\varepsilon$ | Noise standard deviation; synchronicity density (KO); agreement fractions | Props. 5.10, 15.4; §6.4; Prop. 5.11 | Distinguished by argument; the v4.4 symbol $\sigma_{\text{self}}$ is replaced by $\bar\psi$ and the count $n_{\text{self}}$ |
| $R_\tau$, $P$ | Repair (resolvent); projection onto $H^0$ | Prop. 5.12, 16.5 | |
| $\mathsf e$, $\mathsf b$ | Trophic transfer efficiency; biomagnification factor | Prop. 16.3 | Not the noise ε or the monad unit |
| $\mathsf D$, TL | Diet matrix; trophic levels | Prop. 16.4 | |
| $(\mathbb T,\eta_{\mathbb T},\mu_{\mathbb T})$ | Monad | §16.6 | Subscripted to avoid the noise symbol |
| $c_\varepsilon(f)$ | Compliance under load $f$ | Prop. 19.6 | |

## Appendix C — Decision Record: Forks Settled for v5.0

| # | Fork | Corpus variants | v5.0 decision | Rationale |
|---|---|---|---|---|
| F1 | Formula for Γ | v4.4 $1-R$; [DRK-185](https://draken.info/posts/bootstrap-inception/) $1-\lVert\delta s\rVert/\lVert s\rVert$; [DRK-157](https://draken.info/posts/the-compressible-section/) $b_0/(b_0+b_1)$; [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/) normalised Rayleigh / $r$ | Canonical $\Gamma_\tau$ (Def. 5.1); $\Gamma_0$ as limit; $\Gamma_R$ as bound; $\Gamma_{\text{top}}$ as structural index; $r^2=\Gamma_0$ as theorem | Only $\Gamma_\tau$ is bounded, continuous in the maps, monotone under excision, scale-free with τ*, and well conditioned |
| F2 | Formula for K | v4.4/121/177/181 thresholded Ψ integral; [DRK-130](https://draken.info/posts/the-substrate-and-the-game/) residual integral; [DRK-141](https://draken.info/posts/the-finite-sheaf/) signed gap; [DRK-176](https://draken.info/posts/the-ouroboros-debt/) $\int\lVert d\omega\rVert$ | Canonical KO form as a ratchet (Def. 7.1); others renamed $I$, $G$ (with ratchet part $K_\Gamma$), $C$ | One word, one quantity; the KO definition is the thresholded Ψ integral |
| F3 | Meaning of Ψ | Odds ratio (v4.4); "Ψ → 1" usage ([DRK-133](https://draken.info/posts/asymmetric-power/), [DRK-176](https://draken.info/posts/the-ouroboros-debt/)); basin share ([DRK-176](https://draken.info/posts/the-ouroboros-debt/)); quantum Ψ ([DRK-143](https://draken.info/posts/the-braided-substrate/), [DRK-169](https://draken.info/posts/relevance-as-collapse/)) | Ψ = odds (Lemma 6.1); $\bar\psi$ = bounded share; basin → $\beta_{\text{self}}$; quantum → $\lvert\psi\rangle$ | Lemma 6.1 shows the v4.4 ratio is an odds; "→ 1" usages read as $\bar\psi$ |
| F4 | Symbol Θ | Trophic debt (KO, [DRK-176](https://draken.info/posts/the-ouroboros-debt/)); holonomy flux ([DRK-171](https://draken.info/posts/the-dragged-frame/)) | Θ = trophic debt; holonomy = $\Phi_\gamma$ | Registry precedence |
| F5 | Symbol ρ | Restriction (KO); density; density matrix; soundness; productile rank; spectral radius | ρ = restriction only | Registry precedence |
| F6 | ϰ needs closed ω, debt uses ‖dω‖ | [DRK-175](https://draken.info/posts/the-invariant/) vs [DRK-176](https://draken.info/posts/the-ouroboros-debt/) | $\varkappa=[\Pi_{\text{harm}}\omega]$ (Def. 3.5); curvature load $C(t)$ | The Hodge splitting makes both well defined for one ω |
| F7 | What carries $H^1$ | "Disagreement is $H^1$" (v4.4 §2.2.1; [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/), among others) | Principle 2.7: only relational data carry $H^1$; vertex disagreement is $H^0$ | Lemma 2.5 |
| F8 | Sign of the care condition | $=0$ (KO, [DRK-162](https://draken.info/posts/the-bridge-and-the-burn/), [DRK-186](https://draken.info/posts/konkurrent/)); $\ge0$ ([DRK-176](https://draken.info/posts/the-ouroboros-debt/)) | Constraint $=0$ on own contribution; asymmetric accounting in Θ | Keeps the KO and [DRK-176](https://draken.info/posts/the-ouroboros-debt/)'s debt |
| F9 | K monotone yet reducible | v4.4 §4.3 | Gross $K$ (monotone) and balance $B_K=K-P_K$ | Removes the contradiction |
| F10 | Ψ–Γ inverse monotonicity | v4.4 conjecture | Withdrawn; replaced by the two-coordinate diagnostic | Proposition 5.8 refutes it as a law |
| F11 | Version of W | v1 (working brief); v2 (site, 2026-10-01) | v2 reported | `docs/W-VERSIONS.md` is the record |
| F12 | Counting coherences | σ(F) ([DRK-142](https://draken.info/posts/wrestling-with-god/)); T(F) ([DRK-139](https://draken.info/posts/the-welcomed-section/), [DRK-141](https://draken.info/posts/the-finite-sheaf/)) | $\ell^0$ coherence and well-posedness check, bounded by energy (Prop. 5.11); not headline | Discontinuous; inflatable by false overlap (§18.2) |
| F13 | Lindeman and divergence geometries | Multiplicative transfer ([DRK-136](https://draken.info/posts/the-komodoburger-franchise/)); KL edges ([DRK-163](https://draken.info/posts/the-two-optics/)) | Declared stalk and edge geometry under A2: rescaling (Prop. 16.3), Fisher metric (§16.7) | Keeps one linear-algebraic spine |

## Appendix D — Errata to v4.4

| # | v4.4 location | Error | Correction |
|---|---|---|---|
| 1 | §2.2.3 institutional example | $\|x\|^2$ printed 3.07 | 3.16; v4.4-style value 0.418, not 0.401 (Ex. 4.1) |
| 2 | §2.2.4 trophic example | $\|x\|^2$ printed 3.83 and 1.30; $\Gamma_{\text{post}}=-0.192$ | 4.32 and 1.00; $1-R=-0.550$ (Ex. 4.2) |
| 3 | §2.2.4, §4.2 | Negative Γ read as "anti-coherence" | Normalisation artefact; v5.0 measures lie in $(0,1]$ (Prop. 5.3) |
| 4 | §6.3.2 | λ₁ ≈ 0.12, relaxation time 8.3, asserted | λ₁⁺ = 0.519, relaxation time 1.93, computed (Ex. 4.1) |
| 5 | §5.2.2, Operator 2 | False overlap "creates new zero eigenvalues" | Impossible; adding edges cannot enlarge $\ker L$ (Prop. 5.6; §18.2) |
| 6 | §5.2.2, Operator 4 | Substitution yields anomalies two or more hops away | Not in general (false on trees) (§18.4) |
| 7 | §4.3 | K "accumulates monotonically" and "can only be reduced by intervention" | Gross debt vs balance (§7.2) |
| 8 | §4.1.2 | Ψ–Γ inverse monotonicity conjectured as central | Refuted as a law (Prop. 5.8; §6.3) |
| 9 | §6.3.3 | Matrix–vector cost $O(n\lvert E\rvert)$ | $O(\operatorname{nnz}(L))=O(\lvert E\rvert d_{\max}^2)$ (§21.2) |
| 10 | Title page, §9.13 | "16 technical reports DRK-101–122"; citations of DRK-109 and DRK-122, which do not exist | 14 posts existed in that range; references removed |
| 11 | Bibliography | Hansen & Ghrist (2021) pages 2064–2091 | 2033–2060 (Crossref, doi:10.1137/20M1341088) |
| 12 | Bibliography | Frýdlová et al. (2016) pages 79–86; Harrison (2011) 39(4), 603–618; MacNulty et al. (2025) title and venue | 37–45; 39(1), 43–64; EcoEvoRxiv preprint (Crossref) |
| 13 | §2.2.1 | "Nontrivial $H^1$ means local sections cannot be assembled… despite almost agreeing" | For vector-space sheaves, failure of vertex data to glue is an $H^0$ statement; $H^1$ obstructs integration of relational data (Principle 2.7) |

## Appendix F — Reproducibility

**Script.** `draken_v5_examples.py` (Python 3; NumPy, SciPy, Matplotlib; deterministic seeds). It is distributed with this monograph and intended for the repository at `docs/thesis/v5/`.

Running `python3 draken_v5_examples.py figures` writes Figures 1–6 and prints a JSON record of every number in the following places:

| Source of the numbers | JSON keys |
|---|---|
| Examples 4.1–4.8 | `ex41_*` … `ex48_*` |
| §16.5, Props. 5.11, 5.12, 19.6 | `ex16_trophic_structure`, `prop_agreement`, `prop_tweedie`, `prop_compliance` |
| Proposition 5.10 | `prop_noise_bias` |
| Theorem 19.2 | `prop_excision` |

**Checks performed by the script.**

| Check | Result |
|---|---|
| $\delta^1\delta^0=0$ | Asserted on every complex |
| $\partial_1\partial_2=0$ over $\mathbb F_2$ | Asserted (toric code) |
| Curl energy, projection vs curvature formula (Prop. 3.4) | Agree to $10^{-6}$ |
| U(1)-ring spectrum vs closed form (Prop. 4.2) | Agree to $10^{-6}$ |
| $r^2-\Gamma_0$ (Prop. 4.3) | Below $10^{-15}$ |
| Monte-Carlo noise inflation vs $\operatorname{tr}(L\Sigma)$ (Prop. 5.10) | Within sampling error |
| Best lift residual vs $E_{\text{harm}}(\omega_q)=\Phi^2/N$ (Prop. 3.11, Ex. 4.8) | Agree (0.0150) |
| Tweedie denoiser vs resolvent (Prop. 5.12) | Agree to $3\times10^{-16}$ |
| Agreement fraction vs Markov bound (Prop. 5.11) | 0.80 ≥ 0.425 |
| Compliance under excision (Prop. 19.6) | Non-decreasing: 2.667, 4.000, ∞ |
| Trophic levels by Leontief solve (Prop. 16.4) | (1, 1, 2, 2.5, 3.3) |

**Origin classification.** `gen_results.py` extracts every numbered result and writes Appendix G from a declared classification.

**Audit.** `audit_v5.py` counts the following in the monograph source:

- numbered results;
- claim paragraphs, and the share ending in an epistemic tag;
- DRK links, all resolved against `data/drk-index.json`;
- KO coverage, against `data/ko.json`.

Its output is reproduced in Chapter 23.
