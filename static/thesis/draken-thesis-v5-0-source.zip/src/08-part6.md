# Part VI — Programme, Computation, Falsification

## 20 The Empirical Programme

Each item below names a domain, the declared sheaf, the Draken quantity, and the outcome that would count against it. Items are ordered by readiness **[D]**.

### 20.1 Varanid ritualised combat (ready; existing data)

**Domain.** Monitor lizards resolve contests through a ritualised sequence: display, encompassing, clinch, catch and a final dominance phase, labelled *subpressive* in the approved KO definition of the *Clinch* ([DRK-108](https://draken.info/posts/abstraction-depth/)). In this sequence, physical grappling tests the claims made by display (Horn, Gaulke & Böhme 1994; Earley, Attum & Eason 2002) **[S]**. *Source check pending:* [DRK-108](https://draken.info/posts/abstraction-depth/) attributes the five-phase description to "Horn, Gauldie, and King (1994)", while v4.4 cites Horn, Gaulke & Böhme (1994). Neither could be machine-verified, and the phase labels must be checked against the primary source before P8 is run **[D]**.

**Sheaf.** Vertices are phases, and stalks are the measured state per phase. The restriction maps are parameterised by body mass (Frýdlová et al. 2016) and musculoskeletal scaling (Dick & Clemente 2016). The clinch is the anchor that zeroes the bluff kernel (Section 16.3) **[D]**.

**Test (P8).** Compute $\Gamma_{\tau}$ at fixed base for the sheaf induced by each competing contest model:

- sequential assessment;
- energetic war of attrition;
- cumulative assessment (Enquist & Leimar 1983).

The model with the highest coherence should best predict transition probabilities and outcomes across species. *Falsifier:* coherence ranks models no better than a random-map null **[H]**.

### 20.2 Representational drift (ready; public data)

**Domain.** Neural codes for stable tasks change over days to weeks while behaviour remains stable (Driscoll et al. 2017; Schoonover et al. 2021). Proposed explanations include self-healing codes and drift confined to null coding spaces (Rule & O'Leary 2022; Rule et al. 2020) **[S]**.

**Hypothesis H20.1 (Drift as gauge).** Behaviourally silent drift is a stalk-wise orthogonal transformation with co-transforming readout maps. By Proposition 5.5(iii) such a transformation leaves every coherence measure invariant ([Representational Drift as Sheaf-Theoretic Coherence](https://draken.info/posts/representational-drift-sheaf/), [DRK-146](https://draken.info/posts/representational-drift-sheaf/)) **[H]**.

**Test (P11).** Decompose day-to-day changes of population vectors into a gauge part (the best orthogonal alignment, by Procrustes) and a residual. *Prediction:* behavioural decoding loss is explained by the residual, not by total drift. *Falsifier:* loss tracks total drift equally well **[H]**.

### 20.3 Morphogenesis and regeneration (protocol published)

**Domain.** Bioelectric patterns act as an instructive layer between gene regulation and anatomy (Levin & Martyniuk 2018). Neural cellular automata learn to grow and regenerate target patterns (Mordvintsev et al. 2020) **[S]**.

**Sheaf.** [The Stalking Cell](https://draken.info/posts/the-stalking-cell/) (DRK-167) proposes the restriction-map chain
$$\text{DNA}\xrightarrow{\rho_1}\text{regulatory pathway}\xrightarrow{\rho_2}\text{bioelectric field}\xrightarrow{\rho_3}\text{tissue}\xrightarrow{\rho_4}\text{form}.$$
The Khrug Engineering protocol KE-NCA-001 specifies a sheaf over the cell lattice of a neural cellular automaton, with cell states as stalks **[D]**.

**Test (P12).** After damage, the cell-state sheaf's $\Gamma_{\tau}$ and spectral gap $\lambda_1^+$ recover *before* morphological error does. *Falsifier:* coherence recovery lags or merely tracks morphological recovery **[H]**.

### 20.4 Inter-brain carrier and cargo (requires new data)

**Test (P10).** In hyperscanning, measure two quantities ([The Carrier and the Cargo](https://draken.info/posts/the-carrier-and-the-cargo/), [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/), §8):

- carrier coherence, as phase-locking value or $r^2$;
- cargo coherence, as $\Gamma_\tau$ of a belief sheaf estimated by representational similarity analysis (Kriegeskorte et al. 2008).

*Prediction:* the two dissociate across conditions (H13.1). *Falsifier:* they are interchangeable across all conditions **[H]**.

### 20.5 Early warning of fragmentation (ready; network panel data)

**Test (P9).** In longitudinal interaction networks (organisations, online communities, alliances), track the projection of the data onto the slowest nonzero Laplacian mode.

*Prediction:* the variance and lag-1 autocorrelation of that projection rise before $b_0$ increases (Proposition 15.4; Scheffer et al. 2009). *Falsifier:* no rise relative to matched non-fragmenting periods **[H]**.

### 20.6 Institutional and ecological diagnostics (v4.4 programme, sharpened)

Predictions P1–P7 of v4.4 are retained with v5.0 instruments **[H]**:

- the bounded companion $\bar\psi$ for Ψ;
- the outstanding balance $B_K$ and the measurable $K_\Gamma$ for debt;
- $\alpha^\ast$ for abstraction depth;
- $\Gamma_\tau$ at fixed base, with declared reference, noise correction and excision report, for coherence.

For ecological networks (P5), the null model is degree-preserving rewiring of the trophic complex. Γ must beat the null to count **[D]**.

## 21 Computation

### 21.1 Pipeline

1. **Declare** the complex $X$ (cells and orientations), stalks with inner products, restriction maps (estimated, with residuals), the reference $x_{\text{ref}}$, the stiffness τ (fixed on the reference base), and the coefficient field (Axioms A2, A4).
2. **Assemble** $\delta^0,\delta^1$ as sparse block matrices.
3. **Vertex coherence.** Solve $(I+\tau L)y=x$ by conjugate gradients. Then $\Gamma_\tau=\langle x,y\rangle/\|x\|^2$. No eigendecomposition is needed.
4. **Relational decomposition.**
   - Solve $Lx^\star=\delta^{0\top}\omega$ (minimum-norm least squares) for the gradient part.
   - Solve $\Delta^2y=\delta^1\omega$ for the curl part.
   - The harmonic part is the remainder.
   - Report $E_{\text{grad}},E_{\text{harm}},E_{\text{curl}}$, and test $E_{\text{harm}}$ against the $\chi^2_{b_1}$ floor (Proposition 18.1).
5. **Invariants.** Compute $b_0$, $b_1$ by rank (exact rational or $\mathbb F_2$ elimination for small or code-like complexes). Compute $\lambda_1^+$ and $s_1$ by Lanczos with shift-invert.
6. **Estimation.** Apply the noise correction (Proposition 5.10) and sensitivity analysis (Proposition 5.9).
7. **Time series.** Compute ratchet integrals by quadrature, the outstanding balance against recorded discharges, and early-warning statistics (Proposition 15.4).
8. **Comparisons.** Recompute on the common base and attach the excision report (Definition 19.3).

**[E/D]**

### 21.2 Complexity

Write $n=\dim C^0$ and $\operatorname{nnz}(L)=O(|E|\,d_{\max}^2)$.

| Step | Cost | Note |
|---|---|---|
| Assemble $L$ | $O(\lvert E\rvert\,d_{\max}^3)$ | Block products $\rho^\top\rho$ |
| Matrix–vector product | $O(\operatorname{nnz}(L))$ | Corrects v4.4's $O(n\lvert E\rvert)$ |
| $\Gamma_\tau$ by CG | $O\big(\operatorname{nnz}(L)\sqrt{1+\tau\lambda_{\max}}\,\log(1/\epsilon)\big)$ | Well conditioned; independent of the spectral gap |
| $\Gamma_0$, $x^\star$ | Governed by $\lambda_1^+$ (ill-conditioned near fragmentation) | Prefer $\Gamma_\tau$ |
| $\lambda_1^+$, $\lambda_{\max}$, $s_1$ | $O(k\cdot\operatorname{nnz})$ per Lanczos sweep | |
| $b_1$ exact | Sparse rank; $O(n^3)$ dense worst case | $\mathbb F_2$ elimination for codes |

The conditioning of the resolvent system is bounded by $1+\tau\lambda_{\max}$ regardless of how small the spectral gap becomes. This is a practical reason, beyond Proposition 5.6, to prefer $\Gamma_\tau$ as the canonical measure **[E]**.

### 21.3 Instruments

- **The Sheaf Analyzer** ([The Sheaf Analyzer](https://draken.info/posts/sheaf-analyzer-manual/), [DRK-132](https://draken.info/posts/sheaf-analyzer-manual/)) already computes coboundaries of text-derived sheaves. v5.0 specifies the additions:
  - $\Gamma_\tau$ with declared τ and reference;
  - the three-part decomposition for relational extractions;
  - $b_1$ and $s_1$;
  - the noise floor of Proposition 18.1.
- **The KnowledgeObject schema** ([KnowledgeObject Schema v2](https://draken.info/posts/ko-schema-v2/), [DRK-101](https://draken.info/posts/ko-schema-v2/)) is the corpus's typed memory, and the KO registry (Appendix B) is its current state.
- **The reproducibility script** of Appendix F implements steps 2–6 for the worked examples.

**[D]**

## 22 Falsification

### 22.1 What can and cannot be falsified

The monograph contains three kinds of statement, and they fail in different ways **[D]**:

1. **Theorems and propositions** (Chapters 2–5, 9, 12, 15, 18, 19). These are checked, not tested. They fail only by an error in the proof, and each one numbered in a worked example is also checked numerically by the script. A reader who finds an error falsifies the proposition and every reading built on it.
2. **Bridges** (Chapter 10 ledger). An exact bridge fails if the identification is shown not to hold. An analogy cannot fail as evidence because it is never used as evidence.
3. **Empirical hypotheses and predictions**, listed below.

The protocol is the [DRK-131](https://draken.info/posts/zhixing-heyi-honest-referee/) falsification protocol (approved KO, defined in [The Braided Substrate](https://draken.info/posts/the-braided-substrate/), [DRK-143](https://draken.info/posts/the-braided-substrate/), §7). It requires no fabricated citations, verified paraphrase, an explicit falsification subsection and a three-question review **[D]**.

### 22.2 Predictions

| # | Prediction | Instrument | Falsifier | Status |
|---|---|---|---|---|
| P1 | Higher $\bar\psi$ precedes strategic failure | Ψ pipeline (Ch. 6) | No association in longitudinal panel | Untested (v4.4) |
| P1′ | (Γ, $\bar\psi$) is not inversely related; the kayfabe quadrant is populated | Γ_τ, $\bar\psi$ | Joint distribution concentrated on the anti-diagonal | New; untested |
| P2 | Larger outstanding debt $B_K$ precedes larger corrections | $K$, $P_K$, $K_\Gamma$ | Correction size independent of $B_K$ | Partially tested retrospectively (v4.4) |
| P3 | Larger $\alpha^\ast$ precedes slower correction | $\alpha^\ast$ (Ch. 8) | No association | Untested |
| P4 | Restriction-map repair raises $\Gamma_\tau$ on a fixed base | Γ_τ + excision report | No rise, or rise only by excision | Untested |
| P5 | Trophic $\Gamma_\tau$ tracks ecosystem health | Γ_τ vs rewired null | No better than null | Testable now |
| P6 | Removal of enforcing institutions raises $\bar\psi$ | $\bar\psi$ | No change | Retrospectively testable |
| P7 | Attention-economy $\alpha^\ast$ predicts population-level $\bar\psi$ | $\alpha^\ast$, survey Ψ | No association | Testable now |
| P8 | Contest-model coherence predicts varanid outcomes | Section 20.1 | No better than random-map null | Testable now |
| P9 | Rising variance and autocorrelation of the slow mode precede fragmentation | Prop. 15.4 | No rise vs matched controls | New; testable now |
| P10 | Carrier and cargo coherence dissociate | Section 20.4 | Interchangeable across conditions | New; requires data |
| P11 | Behavioural loss tracks the non-gauge part of drift | Section 20.2 | Equal fit for total drift | New; testable now |
| P12 | Coherence recovers before form in regeneration | Section 20.3 | Lag or mere tracking | New; protocol published |
| P13 | Claimed-minus-measured coherence ($K_\Gamma$) predicts correction size beyond $E_{\text{obs}}$ | H7.1 | No incremental prediction | New |
| P14 | Coherence gains that vanish on the original base (Cor. 19.5) precede larger corrections than gains that persist | Excision report | No difference | New |
| P15 | Interventions that raise Γ while raising load compliance (Cor. 19.7) precede service failures under those loads | $\Gamma_\tau$, $c_\varepsilon(f)$ | No association | New |
| P16 | In food webs, deviation of measured transfer profiles from the Lindeman section predicts instability indices | Prop. 16.3 | No association beyond biomass alone | New; testable now |

### 22.3 Framework-level falsifiers

The framework as a diagnostic programme fails in any of the following cases **[D]**:

- **F-A.** Across at least three domains, $\Gamma_\tau$ at fixed base predicts its target (P4, P5, P8) no better than its matched null.
- **F-B.** In domains where a Draken reading claims a structural obstruction, $E_{\text{harm}}$ does not exceed its noise floor (Proposition 18.1).
- **F-C.** The debt measures (P2, P13, P14) add nothing to prediction beyond contemporaneous coherence.

*Scope limit.* The proofs establish that the measures are well defined, computable and correctly invariant. They do not establish that the measures matter for any particular system. That is what F-A to F-C test **[D]**.

## 23 Governance and Self-Audit

### 23.1 Guarding the framework against its own use

v4.4 translated the V-axioms into system requirements, and they are retained **[D]**:

| Axiom | Requirement |
|---|---|
| V.1 | Log every restriction-map modification with author and time |
| V.2 | Compute the system's own Ψ on its outputs |
| V.4 | Alert on rising Ψ in its own analyses |
| V.7 | Apply the framework's criteria to its own claims before publication |

v5.0 adds two requirements **[D]**:

- Every coherence claim carries the reporting standard 5.7a and, for comparisons, the excision report (Definition 19.3).
- No reported number is hand-kept. Every statistic is computed from data at build or by script.

### 23.2 Watertightness is not coherence

The corpus's structural score is **Watertightness W v2** (released 2026-10-01; `docs/W-VERSIONS.md` in the site repository):
$$W=\big(c_7^{3}\,c_1\,c_2\,c_3\,c_4\,c_6\big)^{1/8},\qquad W_{\text{post}}=\big(c_7^{3}\,c_1\,c_6\big)^{1/5}.$$
The components are:

- $c_1$, reference integrity;
- $c_2$, definition coverage;
- $c_3$, KO closure;
- $c_4$, KO reuse;
- $c_6$, citation connectivity;
- $c_7$, claim paragraphs carrying a reference (weight 3).

Component $c_5$ (falsification block) was removed in v2 and is not reused **[E]**.

On 2026-10-02 the corpus scored W = 0.745. Its components were $c_1$ = 0.986, $c_2$ = 0.938, $c_3$ = 1, $c_4$ = 0.906, $c_6$ = 1 and $c_7$ = 0.483 (668 of 1,382 claim paragraphs referenced). $c_7$ is binding **[E]**.

W measures the structure of the record (references, definitions and their reuse, connectivity), not the truth of its claims. It is never labelled Γ. Changing its patterns or weights after seeing results requires a new version **[D]**.

### 23.3 Self-audit: v4.4 against v5.0

| Measure | v4.4 | v5.0 |
|---|---|---|
| Corpus covered | DRK-101–121 (14 posts that exist; 16 claimed) | All 86 posts dispositioned; 55 used in the argument (Appendix E) |
| Citations of nonexistent DRK numbers | 2 (DRK-109, DRK-122) | 0 |
| Errors found (arithmetic, logical, bibliographic) | 13 (Appendix D) | 0 known; every example recomputed by script |
| Numbered results with proof | 0 (one "derivation" sketch) | 45, each with proof or standard citation: 23 standard, 13 elementary, 9 original (Appendix G) |
| Worked examples computed by code | 0 | 8 examples + 7 propositions verified numerically |
| Figures generated from code | 0 | 6 of 6 |
| Inconsistent definitions in corpus | Not addressed | 13 forks settled (Appendix C) |
| Coherence measure range | Unbounded below ("Γ < 0") | $(0,1]$, with bounds, invariances, monotonicity, estimator |
| Knowledge Objects integrated | 14 of today's 32 terms present | 32 of 32 in the glossary; 27 used in the argument (Appendix B) |
| Bridge claims graded | No | 28 graded; 7 corpus claims excluded with reasons |
| Epistemic markers | Three-level | Five-tag ledger of the post standard |
| Claim paragraphs tagged | Section-level markers only | 220 of 220 claim paragraphs; 37 result statements tagged at their proofs (audit script, Appendix F) |

The v5.0 column is generated from the source by the audit step of the build script, apart from the counts of forks and bridges, which are enumerated in Appendix C and Chapter 10 **[E]**.

## 24 Conclusion

**What is proved.** Model a multi-scale system as a cellular sheaf on a finite 2-complex. Then:

- its relational data split uniquely into a part that local re-gauging removes, a topological part (ϰ) and a curvature part;
- local relaxation removes exactly the first and stops exactly at the other two;
- coherence of local states is measured by a resolvent quantity with a repair-cost meaning, sharp spectral bounds, the correct invariances, and a monotonicity under adding and deleting relations;
- that monotonicity makes totalisation, coherence bought by deleting relations, always available. A norm, not a measurement, must forbid it.
- the same excision raises compliance under any declared load (Rayleigh monotonicity), so anchored measures detect what unanchored ones reward;
- obstructions reached by lifting across a cut and by integrating relational data are the same class (Proposition 3.11);
- the repair behind Γ is Bayesian denoising, which ties coherence to Gaussian Markov random fields and to score-based generation (Propositions 5.12, 15.5);
- trophic structure, input–output planning and iterated repair close onto the same linear algebra (Propositions 16.3–16.5).

**[E/D]**

**What is computed.** Every worked example, including corrected versions of v4.4's two, is reproducible from a published script. Clock rings, U(1) rings, exchange complexes, toric codes, Kuramoto populations and signed triangles all instantiate the same three-part structure **[E]**.

**What is hypothesised.** The same structure, applied to measured data from minds, groups, institutions and ecosystems, separates repairable from irreducible disagreement. Debt accrued by denying the irreducible part predicts the size of later corrections **[H]**.

**What must be tested.** Predictions P1–P16 and framework falsifiers F-A to F-C. The most immediately executable are P5, P8, P9 and P11, on existing data **[D]**.

Draken adds layers of explanation. It does not decide which global section is true, because no coherence measure can (Proposition 5.8). That decision belongs to the anchors: to contact with what lies outside the system's own sections. The Clinch awaits **[D]**.
