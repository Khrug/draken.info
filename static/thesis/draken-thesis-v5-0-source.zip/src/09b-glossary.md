## Appendix B — Glossary of Knowledge Objects

All 32 Knowledge Objects in the registry (`data/ko.json`, generated 2026-10-02) are approved. Each definition below is quoted verbatim from its defining post, in the post's language. Where a definition ends in a colon, the defining formula follows in the source. The last field gives where the KO is used in this monograph. Registry gap: *anti-totalisation* appears in 37 posts but has no KO. Chapter 19 supplies its formal content, and a defining post is needed before it can be registered.

**Γ — sheaf convergence** — *aliases:* Γ, `\Gamma`, Gamma, sheaf convergence, sheaf coherence, kärvskonvergens

> The sheaf convergence measure **Γ** (gamma) tracks the inverse: how well local sections glue into a globally consistent picture.

*Defined in* [The Kaiju Manifesto: Building the Anti-Memetic Monster](https://draken.info/posts/kaiju-manifesto/) (DRK-105, The 18-Layer Architecture). *Status:* approved. *Used in v5.0:* Ch. 5.

**Ψ — narrative self-reference ratio** — *aliases:* Ψ, `\Psi`, Psi, narrative self-reference ratio, narrative self-reference, psykosmetrik

> **Ψ** (psi) is the *psychosis metric* — the ratio of narrative self-reference to reality-contact.

*Defined in* [The Kaiju Manifesto: Building the Anti-Memetic Monster](https://draken.info/posts/kaiju-manifesto/) (DRK-105, The 18-Layer Architecture). *Status:* approved. *Used in v5.0:* Ch. 6.

**K(t) — coherence debt** — *aliases:* K(t), coherence debt, koherensskuld

> *This article introduces the coherence debt function K(t) — the temporal integral of excess Ψ above viable threshold — and argues that what spiritual traditions have called karma, what systems theorists have called fragility, and what the Draken framework diagnoses as civilizational Ψ-degradation are structurally identical phenomena: the accumulated cost of running a generative model that refuses correction.

*Defined in* [The Coherence Debt: Karma as Thermodynamic Integral](https://draken.info/posts/the-coherence-debt/) (DRK-121, opening). *Status:* approved. *Used in v5.0:* Ch. 7.

**ϰ — Draken invariant** — *aliases:* ϰ, `\varkappa`, Draken invariant, invariant of Draken

> *The invariant* is cohomological: discrete, preserved under the sheaf analogue of ambient isotopy.

*Defined in* [The Invariant](https://draken.info/posts/the-invariant/) (DRK-175, §4 — The invariant of Draken.). *Status:* approved. *Used in v5.0:* Ch. 3, 9.

**ρ — restriction map** — *aliases:* ρ, restriction map, restriction morphism, restriktionsavbildning

> I kärv-teori beskriver restriktionsavbildningen ρ_U,V : F(U) → F(V) hur information över ett stort område (U) begränsas till ett mindre delområde (V ⊆ U).

*Defined in* [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) (DRK-117, Restriktionsavbildning (Restriction Map)). *Status:* approved. *Used in v5.0:* Ch. 2.

**H¹ — cohomological obstruction** — *aliases:* H¹, H^1, cohomological obstruction, obstruction class, kohomologisk obstruktion

> Tekniskt: ett icke-trivialt element i H¹(X, F) — den första kohomologigruppen av kärven F över rummet X.

*Defined in* [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) (DRK-117, Kohomologisk obstruktion). *Status:* approved. *Used in v5.0:* Ch. 2–3.

**Care operator V̇_exo = 0** — *aliases:* care operator, V̇_exo, `\dot{V}_{exo}`, `\dot{\mathcal V}_{exo}`, omsorgsoperatorn

> The care operator is the condition $\dot{\mathcal V}_{exo}=0$: the non-destruction of exogenous variety — the commitment not to annihilate the otherness of the thing you are bound to.

*Defined in* [The Bridge and the Burn](https://draken.info/posts/the-bridge-and-the-burn/) (DRK-162, Frankenstein: assembly without the seam). *Status:* approved. *Used in v5.0:* Ch. 2, 7.

**Θ — trophic debt** — *aliases:* Θ(t), `\Theta(t)`, trophic debt, trofisk skuld

> Define trophic debt as the accumulated *violation* of care:

*Defined in* [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176, §4 — Trophic debt: the bill for closing the loop). *Status:* approved. *Used in v5.0:* Ch. 7.

**Optimization axiom** — *aliases:* optimization axiom, optimeringsaxiomet, min S_sys

> "Minska oordningen i systemet — men inte genom att förenkla bort komplexiteten."

*Defined in* [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) (DRK-117, Optimeringsaxiomet). *Status:* approved. *Used in v5.0:* Ch. 2, 19.

**Manufactured void** — *aliases:* manufactured void, tillverkad tomhet, narrative void engineering

> "När maktstrukturer medvetet skapar informationshål för att styra vilka berättelser som kan bildas."

*Defined in* [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) (DRK-117, Tillverkad Tomhet (Manufactured Void / DRK-110)). *Status:* approved. *Used in v5.0:* Ch. 18–19.

**Cavity_AI — cavity resonator** — *aliases:* Cavity_AI, kavitetsresonator, cavity resonator

> "En strukturerande tomhet som formar allt som passerar genom den."

*Defined in* [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) (DRK-117, Cavity_AI — Kavitetsresonatorn). *Status:* approved. *Used in v5.0:* Glossary only (companion volume).

**Inversion filter (V.7)** — *aliases:* Inversion Filter, inversionsfilter, V.7

> Det viktigaste diagnostiska verktyget: om en struktur hävdar att den erbjuder global koherens men kräver informationsundertryckning vid sina gränser, är den en tillverkad tomhet — inte en genuin gräns.

*Defined in* [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) (DRK-117, V-axiomen — Drakens värdeaxiom). *Status:* approved. *Used in v5.0:* Ch. 18–19.

**α — abstraction depth** — *aliases:* abstraction depth, abstraktionsdjup

> We define *abstraction depth* as the number of representational layers between a claim to power and the capacity that underlies it:

*Defined in* [Abstraction Depth: Why Your Boss Doesn't Have to Wrestle You](https://draken.info/posts/abstraction-depth/) (DRK-108, II. The Primate Who Learned to Abstract). *Status:* approved. *Used in v5.0:* Ch. 8.

**Clinch** — *aliases:* clinch, klinch

> Horn, Gauldie, and King (1994) described five distinct phases: *Display*, where the animals inflate their bodies laterally, maximizing apparent size; *Encompassing*, where they circle each other, assessing geometry; *Clinch*, where they rear up on hind legs and lock forelimbs in bipedal wrestling; *Catch*, where one animal attempts to topple the other using what researchers have described as judo-like throws; and *Subpressive*, where the victor mounts the defeated animal in a dominance display.

*Defined in* [Abstraction Depth: Why Your Boss Doesn't Have to Wrestle You](https://draken.info/posts/abstraction-depth/) (DRK-108, I. A Life Measured in Grapples). *Status:* approved. *Used in v5.0:* Ch. 16, 20.

**Kayfabe** — *aliases:* kayfabe, kayfabe trap

> When the framework's diagnostic output flags Ψ → 1 with restriction maps collapsing — kayfabe, in the working vocabulary — what it has detected is a configuration that has become locally coherent at the cost of severing its accountability to the larger system.

*Defined in* [The Protocol and the Predator: On Asymmetric Power Without Extraction](https://draken.info/posts/asymmetric-power/) (DRK-133, I. Two Asymmetries). *Status:* approved. *Used in v5.0:* Ch. 6, 18.

**Survivable glitch** — *aliases:* survivable glitch, ∇_s, `\nabla_s`

> A failure mode whose information content survives the failure event, gets fed back into the design layer, and improves the protocol for the next iteration.

*Defined in* [The Survivable Glitch: Lacan's Middle Period, the Simulator, the Haveriutredning, and Why I Named the Framework Draken](https://draken.info/posts/the-survivable-glitch/) (DRK-138, III. The Survivable Glitch: Where Engineering Anticipated Philosophy). *Status:* approved. *Used in v5.0:* Glossary only (companion volume).

**Source laundering** — *aliases:* laundering operator, source laundering, laundering, laundered, launder

> It is a **substitution at the stalk** — he replaces $\mathcal{F}_s =$ *"leader of warriors"* with a forged value $\mathcal{F}_s' =$ *"head of the dragon (because: comet),"* and then forces every downstream section to glue to the forgery:

*Defined in* [The Pendragon Source](https://draken.info/posts/the-pendragon-source/) (DRK-165, II. The laundered name (Geoffrey's pen)). *Status:* approved. *Used in v5.0:* Ch. 18.

**Carrier** — *aliases:* carrier, bärare

> The first is **coordination**: the degree to which the group's neural activity is temporally aligned, phase-locked, beating together.

*Defined in* [The Carrier and the Cargo: Phase Synchrony, Representational Content, and the Cohomology of a Shared Belief](https://draken.info/posts/the-carrier-and-the-cargo/) (DRK-189, 1. Two layers, never to be conflated). *Status:* approved. *Used in v5.0:* Ch. 13.

**Cargo** — *aliases:* cargo

> The second is **representational alignment**: the degree to which the group now holds the *same* belief, the same vector in some semantic space.

*Defined in* [The Carrier and the Cargo: Phase Synchrony, Representational Content, and the Cohomology of a Shared Belief](https://draken.info/posts/the-carrier-and-the-cargo/) (DRK-189, 1. Two layers, never to be conflated). *Status:* approved. *Used in v5.0:* Ch. 13.

**Chaxu geju (差序格局)** — *aliases:* chaxu geju, 差序格局, differentiell associationsmod

> Fei Xiaotongs begrepp från 1947: kinesisk social struktur organiseras som koncentriska ringar runt individen — familj närmast, sedan släkt, sedan grannar, sedan samhälle — med moralisk förpliktelse som avtar med avstånd.

*Defined in* [Drakens Ordlista: Kärnbegrepp för nybörjare](https://draken.info/posts/drakens-ordlista/) (DRK-117, Chaxu geju (差序格局) — Differentiell associationsmod). *Status:* approved. *Used in v5.0:* Glossary only (companion volume).

**Sheaf Laplacian** — *aliases:* sheaf Laplacian, `\Delta_{\mathcal{F}}`, L_F, `L_{\mathcal{F}}`, kärv-Laplacian

> The sheaf Laplacian is $\Delta_{\mathcal{F}} = \delta^T \delta$, where $\delta$ is the coboundary operator measuring disagreement on edges.

*Defined in* [The Operational Question in Positive Alignment](https://draken.info/posts/positive-alignment-operational/) (DRK-145, 1. Sheaf-theoretic machinery for cross-scale coherence). *Status:* approved. *Used in v5.0:* Ch. 3.

**Global section** — *aliases:* global section, global sections, globala sektioner, global sektion

> A *global section* is an assignment $\{x_v \in \mathcal{F}(v)\}_{v \in V}$ such that $\rho_{u \to e}(x_u) = \rho_{v \to e}(x_v)$ for every edge $e = (u,v) \in E$.

*Defined in* [The Operational Question in Positive Alignment](https://draken.info/posts/positive-alignment-operational/) (DRK-145, 1. Sheaf-theoretic machinery for cross-scale coherence). *Status:* approved. *Used in v5.0:* Ch. 2.

**DRK-131 falsification protocol** — *aliases:* DRK-131 protocol, DRK-131 publishing protocol, falsification protocol, Falsification (DRK-131), Falsifiering (DRK-131)

> The DRK-131 protocol exists precisely to discipline this risk: no fabricated citations, verified paraphrases, explicit falsification subsection, three-questions review.

*Defined in* [The Braided Substrate: Berry Curvature, Tensor Networks, and Why Topology Builds Draken](https://draken.info/posts/the-braided-substrate/) (DRK-143, 7. Falsification). *Status:* approved. *Used in v5.0:* Ch. 22.

**Keeper-function** — *aliases:* keeper-function, keeper function, keeper-of-secrets, Generalizard

> Four conditions are required of any node to instantiate this keeper-function:

*Defined in* [The Generalizard: Keeper-Function, Mandate, and the Imperial Dragon](https://draken.info/posts/the-generalizard/) (DRK-150, 2. The Four Structural Conditions for Keeping). *Status:* approved. *Used in v5.0:* Glossary only (companion volume).

**σ(t) — synchronicity density** — *aliases:* synchronicity density, σ(t)

> **Synchronicity density** $\sigma(t)$ is the fraction of salient events at time $t$ that the observer reads as addressed to the self **[D]**.

*Defined in* [The Common Base: Dream Logic, Archetype, and the Coincidence That Needs No Channel](https://draken.info/posts/the-common-base/) (DRK-177, §8). *Status:* approved. *Used in v5.0:* Ch. 6.

**𝔚 — warded invariant** — *aliases:* warded invariant

> $$\mathfrak W(\mathcal F) := \big(\, b_1,\ \ d,\ \ \rho \,\big)$$

*Defined in* [The Warded Class: Quantum Codes as Sheaves, and What H¹ Protects](https://draken.info/posts/the-warded-class/) (DRK-190, §8 Proposal: the warded invariant). *Status:* approved. *Used in v5.0:* Ch. 9.

**Egregore** — *aliases:* egregore, egregores, egregor

> The Draken reading is that an egregore is a well-glued section whose stability no longer depends on any single stalk **[D]**.

*Defined in* [The Compressed Will: Sigils, Grimoires, Egregores and Curses as Operations on Symbolic Maps](https://draken.info/posts/the-compressed-will/) (DRK-191, §7 Egregores: sections that outlive their stalks). *Status:* approved. *Used in v5.0:* Ch. 6.

**Stalk** — *aliases:* stalk, stalks

> The **stalk** of $\mathcal F$ at a point $x \in X$ is the direct limit $$\mathcal F_x \;=\; \varinjlim_{U \ni x} \mathcal F(U),$$ taken over all open neighbourhoods of $x$.

*Defined in* [The Stal King: Stalking, the Eye on the Stalk, and the Germ at the Point](https://draken.info/posts/the-stal-king/) (DRK-192, §2 Formal sketch: the stalk as limit of a pursuit (analogy, not derivation)). *Status:* approved. *Used in v5.0:* Ch. 2.

**Stalking** — *aliases:* stalking

> **Stalking** (proposed corpus term): a pursuit that refines a nested family of neighbourhoods around a target while keeping its own estimates restriction-compatible and keeping its own contribution to the target's observations at zero **[D]**.

*Defined in* [The Stal King: Stalking, the Eye on the Stalk, and the Germ at the Point](https://draken.info/posts/the-stal-king/) (DRK-192, §2 Formal sketch: the stalk as limit of a pursuit (analogy, not derivation)). *Status:* approved. *Used in v5.0:* Glossary only (companion volume).

**Earth engine** — *aliases:* earth engine

> **The earth engine** (proposed corpus term): the reading of the Earth system as a cascade of heat engines fired by the Sun, in which each stage compresses usable form from the stage above, burns it through a gate, and fails in one of a small number of engine fault modes **[D]**.

*Defined in* [The Earth Engine: A Sun-Fired Cascade, Minds as Charge, and the Failure Modes of a Planet](https://draken.info/posts/the-earth-engine/) (DRK-193, §3 Formal sketch: stocks, gates and debts (analogy, not derivation)). *Status:* approved. *Used in v5.0:* Ch. 16.

**Conviction gate** — *aliases:* conviction gate, conviction gates

> The **conviction gate** (proposed corpus term) is this inequality: the point where a belief is allowed to command action, governed by certainty, by the value attached to the act, and by the threshold that others and one's own norms impose **[D]**.

*Defined in* [The Conviction Gate: How a Pattern Becomes a Belief That Acts](https://draken.info/posts/the-conviction-gate/) (DRK-194, §2 Formal sketch: precision and the gate (analogy, not derivation)). *Status:* approved. *Used in v5.0:* Ch. 17.

**Gate capture** — *aliases:* gate capture, captured gate

> **Gate capture** (proposed corpus term): the condition in which the value of acting, the threshold for action, or the certainty of the belief is set by an agent other than the believer, so that the believer's gate opens on someone else's terms **[D]**.

*Defined in* [The Weaponised Conviction: Recruitment, Amplification, and the Self Turned Inward](https://draken.info/posts/the-weaponised-conviction/) (DRK-195, §1 Gate capture). *Status:* approved. *Used in v5.0:* Ch. 17–18.

