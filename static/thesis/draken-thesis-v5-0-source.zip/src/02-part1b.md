## 3 The Hodge Spine

This chapter is the mathematical centre of v5.0. Everything in Parts II–V is a reading of, a measure on, or a dynamics for the decomposition proved here **[D]**.

### 3.1 Adjoints and Hodge Laplacians

With the declared inner products (Axiom A2), each coboundary has an adjoint $\delta^{k*}$. For real stalks with orthonormal bases, $\delta^{k*}=\delta^{k\top}$.

**Definition 3.0.** The Hodge Laplacians of $\mathcal F$ are
$$\Delta^0=\delta^{0*}\delta^0,\qquad \Delta^1=\delta^0\delta^{0*}+\delta^{1*}\delta^1,\qquad \Delta^2=\delta^1\delta^{1*}.$$
$\Delta^0$ is the *sheaf Laplacian* $L_{\mathcal F}$. This is the approved KO from [The Operational Question in Positive Alignment](https://draken.info/posts/positive-alignment-operational/) (DRK-145), there written $\Delta_{\mathcal F}=\delta^\top\delta$ **[E]**.

Its quadratic form is the total disagreement energy (Hansen & Ghrist 2019) **[E]**:
$$E(x):=\langle x,L_{\mathcal F}x\rangle=\|\delta^0x\|^2=\sum_{e=(u\to v)}\big\|\rho_{ve}x_v-\rho_{ue}x_u\big\|^2 .$$

### 3.2 The decomposition

**Theorem 3.1 (Hodge decomposition).** For $k=0,1,2$ there is an orthogonal decomposition
$$C^k=\operatorname{im}\delta^{k-1}\ \oplus\ \ker\Delta^k\ \oplus\ \operatorname{im}\delta^{k*},$$
with $\ker\Delta^k=\ker\delta^k\cap\ker\delta^{k-1*}$ and $\ker\Delta^k\cong H^k$. (Terms with out-of-range indices are zero.)

*Proof.*

1. Kernel of $\Delta^k$. For any $c$,
$$\langle\Delta^kc,c\rangle=\|\delta^kc\|^2+\|\delta^{k-1*}c\|^2,$$
so $\Delta^kc=0$ if and only if $\delta^kc=0$ and $\delta^{k-1*}c=0$.
2. Orthogonality of the outer summands. By Lemma 2.5,
$$\langle\delta^{k-1}a,\ \delta^{k*}b\rangle=\langle\delta^k\delta^{k-1}a,\ b\rangle=0 .$$
3. The complement. In finite dimensions, $(\operatorname{im}\delta^{k-1})^\perp=\ker\delta^{k-1*}$ and $(\operatorname{im}\delta^{k*})^\perp=\ker\delta^k$. The orthogonal complement of $\operatorname{im}\delta^{k-1}\oplus\operatorname{im}\delta^{k*}$ is therefore $\ker\delta^{k-1*}\cap\ker\delta^k=\ker\Delta^k$.
4. The isomorphism. Since $\operatorname{im}\delta^{k-1}\subseteq\ker\delta^k$, we have $\ker\delta^k=\operatorname{im}\delta^{k-1}\oplus\ker\Delta^k$. Hence $H^k=\ker\delta^k/\operatorname{im}\delta^{k-1}\cong\ker\Delta^k$. ∎

This is the finite-dimensional Hodge theorem for cochain complexes. For cellular sheaves it is in Hansen & Ghrist (2019); for graphs and edge flows, in Lim (2020) and Jiang et al. (2011) **[E]**.

For edge data $\omega\in C^1$, write $\Pi_{\text{grad}},\Pi_{\text{harm}},\Pi_{\text{curl}}$ for the three orthogonal projectors. Then
$$\boxed{\ \omega\;=\;\underbrace{\delta^0x^\star}_{\text{gradient}}\;+\;\underbrace{h}_{\text{harmonic}}\;+\;\underbrace{\delta^{1*}y}_{\text{curl}}\ },\qquad x^\star=(\delta^0)^{+}\omega,$$
where $^+$ is the Moore–Penrose pseudoinverse **[E]**.

![The Hodge decomposition of relational data on a 2-complex with one filled face (ABC) and one open loop (ACD). Edge labels are values of each component; Example 4.4.](figures/fig1_hodge.png){width=100%}

### 3.3 Energies and the integration problem

**Proposition 3.2 (Energy identity; least squares).** For $\omega\in C^1$:

(i) $\|\omega\|^2=E_{\text{grad}}+E_{\text{harm}}+E_{\text{curl}}$, with $E_\bullet=\|\Pi_\bullet\omega\|^2$.

(ii) $\displaystyle\min_{x\in C^0}\|\omega-\delta^0x\|^2=E_{\text{harm}}+E_{\text{curl}}$.

(iii) The minimisers are exactly $x^\star+H^0$.

*Proof.* (i) is Pythagoras for orthogonal summands. For (ii), $\delta^0x$ ranges over $\operatorname{im}\delta^0$, so the minimum is the squared distance from ω to that subspace, which is the norm of its orthogonal remainder. For (iii), $\delta^0x=\Pi_{\text{grad}}\omega$ holds if and only if $x-x^\star\in\ker\delta^0=H^0$. ∎ **[E]**

**Definition 3.2a (Obstruction energy).** $E_{\text{obs}}(\omega):=E_{\text{harm}}+E_{\text{curl}}$ is the part of the relational data that **no assignment of local states can reproduce**. The *integrability share* is
$$\Gamma^1(\omega):=E_{\text{grad}}/\|\omega\|^2\in[0,1],$$
and its complement $1-\Gamma^1$ is the *obstruction share* **[D]**.

### 3.4 Gauge invariance

A *gauge transformation* re-expresses every local state by an offset: $x\mapsto x+g$ for $g\in C^0$. Relational data change accordingly, $\omega\mapsto\omega+\delta^0g$. Re-zeroing every clock, re-basing every price, or re-anchoring every local convention are gauge transformations **[E]**.

**Proposition 3.3.** $\Pi_{\text{harm}}$, $\Pi_{\text{curl}}$, the curvature $\delta^1\omega$, $E_{\text{harm}}$ and $E_{\text{curl}}$ are gauge invariant.

*Proof.* $\delta^0g\in\operatorname{im}\delta^0$ is annihilated by $\Pi_{\text{harm}}$ and $\Pi_{\text{curl}}$, and by $\delta^1$ (Lemma 2.5). ∎ **[E]**

Reading: no choice of local conventions can create or destroy the topological or curvature part of a disagreement. Only the gradient part is convention-dependent **[E/D]**.

### 3.5 Curvature

**Proposition 3.4 (Curvature determines the curl).** Let $\mathcal R:=\delta^1\omega\in C^2$ be the curvature of ω. Then
$$\Pi_{\text{curl}}\,\omega=\delta^{1*}\,(\delta^1\delta^{1*})^{+}\,\mathcal R,\qquad E_{\text{curl}}=\big\langle \mathcal R,\ (\Delta^2)^{+}\mathcal R\big\rangle .$$
Moreover, ω is closed ($\mathcal R=0$) if and only if its curl part vanishes.

*Proof.* $\delta^1$ annihilates the gradient part (Lemma 2.5) and the harmonic part (Theorem 3.1), so $\mathcal R=\delta^1\delta^{1*}y$. Choosing $y\in\operatorname{im}\delta^1$ (always possible) gives $y=(\Delta^2)^{+}\mathcal R$. Then
$$E_{\text{curl}}=\langle\delta^{1*}y,\delta^{1*}y\rangle=\langle y,\Delta^2y\rangle=\langle\mathcal R,(\Delta^2)^+\mathcal R\rangle .$$
If $\mathcal R=0$ then $y=0$. Conversely, $\delta^1$ is injective on $\operatorname{im}\delta^{1*}$, so a nonzero curl part has nonzero curvature. ∎ **[E]**

The formula is verified numerically in Example 4.4 ($E_{\text{curl}}$ by projection and by curvature agree to $10^{-6}$) **[E]**.

### 3.6 The invariant ϰ

**Definition 3.5 (Draken invariant).** For $\omega\in C^1$,
$$\varkappa(\omega):=[\,\Pi_{\text{harm}}\,\omega\,]\in H^1(X;\mathcal F),\qquad b_1(\mathcal F)=\dim H^1 .$$

When ω is closed, $\varkappa(\omega)=[\omega]$. This is the approved KO definition $\varkappa:=[\omega]\in H^1(X,\mathcal F)$ of [The Invariant](https://draken.info/posts/the-invariant/) (DRK-175). Definition 3.5 extends it to arbitrary relational data, which in applications are never exactly closed **[E/D]**.

*Proof of the reduction.* A closed ω has no curl part (Proposition 3.4), so $\omega=\delta^0x^\star+h$ and $[\omega]=[h]$. ∎ **[E]**

This extension removes the inconsistency between [The Invariant](https://draken.info/posts/the-invariant/) (DRK-175) and [Ouroboros Debt](https://draken.info/posts/the-ouroboros-debt/) (DRK-176):

- [DRK-175](https://draken.info/posts/the-invariant/) requires $[\omega]$ and therefore $\delta\omega=0$.
- [DRK-176](https://draken.info/posts/the-ouroboros-debt/) accrues debt from $\|d\omega\|\neq 0$.

In v5.0 both hold for the same ω. The harmonic part carries ϰ; the curvature carries the curl energy, whose time integral is the *curvature load* $C(t)$ of Chapter 7 **[D]**.

**Proposition 3.6 (Periods).** Let $\mathcal F$ be a constant sheaf $\mathbb R$ on $X$. The *period* of a 1-cochain on an oriented cycle γ is $\langle\omega,\gamma\rangle=\sum_{e\in\gamma}\pm\omega_e$.

(i) Periods of $h=\Pi_{\text{harm}}\omega$ depend only on the homology class of γ. They determine $\varkappa(\omega)$, since $H^1(X;\mathbb R)\cong\operatorname{Hom}(H_1(X),\mathbb R)$.

(ii) Periods of ω itself satisfy a discrete Stokes formula: if $\gamma-\gamma'=\partial c$ for a 2-chain $c$, then
$$\langle\omega,\gamma\rangle-\langle\omega,\gamma'\rangle=\langle\mathcal R,c\rangle .$$

*Proof.* (i) Harmonic cochains are closed, so their periods vanish on boundaries. The isomorphism is the universal coefficient theorem over a field (Hatcher 2002). (ii) $\langle\omega,\partial c\rangle=\langle\delta^1\omega,c\rangle$ by the definition of $\delta^1$ as the transpose of $\partial$. ∎ **[E]**

Reading: when relational data have curvature, "the discrepancy around a loop" is not well defined, because it depends on which loop represents the hole. ϰ assigns each hole a single period, the least-squares reconciliation of all representatives. In Example 4.4 the two loops around the open hole have periods 0.03 and 0.06; ϰ assigns 0.04 **[E/D]**.

### 3.7 What counts as a hole is a modelling decision

**Proposition 3.7 (Face filling reclassifies obstruction).** Let $X'=X\cup\{\tau\}$, adding one face whose boundary is a cycle in $X$, and let $\mathcal F'$ extend $\mathcal F$. For every $\omega\in C^1$ (unchanged by the filling):

(i) $E'_{\text{grad}}=E_{\text{grad}}$;

(ii) $E'_{\text{curl}}\ge E_{\text{curl}}$ and $E'_{\text{harm}}\le E_{\text{harm}}$, with $E'_{\text{harm}}+E'_{\text{curl}}=E_{\text{harm}}+E_{\text{curl}}$;

(iii) $b_1'=b_1-(\operatorname{rank}\delta'^1-\operatorname{rank}\delta^1)$. For the constant scalar sheaf and a cycle that is not already a boundary, $b_1'=b_1-1$.

*Proof.* $C^0$, $C^1$ and $\delta^0$ are unchanged, so the gradient projection is unchanged. $\operatorname{im}\delta'^{1*}\supseteq\operatorname{im}\delta^{1*}$, and orthogonal projection onto a larger subspace has a larger norm. The sum is fixed by (i) and Proposition 3.2. Part (iii) is rank–nullity. ∎ **[E]**

The proposition says that whether an irreducible disagreement is *topological* (harmonic) or *local circulation* (curl) depends on whether the region it encircles is part of the declared base. An unmeasured interior is a hole. A measured interior is a source of curvature. This is why Axiom A2 requires the faces to be declared, and it resolves an ambiguity in the corpus's physics posts (Chapter 10) **[D]**.

### 3.8 Coefficients and torsion

**Remark 3.8.** Over a field of characteristic zero, torsion in integral homology disappears. The Klein bottle $K$ has $H_1(K;\mathbb Z)\cong\mathbb Z\oplus\mathbb Z/2$, but $H_1(K;\mathbb R)\cong\mathbb R$; the $\mathbb Z/2$ class, which is the failure of orientability, is invisible to real-valued measurement (Hatcher 2002) **[E]**.

[The Bottle Has No Outside](https://draken.info/posts/the-bottle-has-no-outside/) (DRK-187) reads non-orientability as the absence of a view from outside. The precise residue of that reading is Axiom A4: obstructions of sign or orientation type must be measured with $O(1)$-valued restriction maps (signed sheaves, Section 4.7) or over $\mathbb F_2$ (codes, Chapter 12) **[D]**.

### 3.9 Two faces of $H^1$

The same group plays two roles, and it is reached by two roads (integration, here, and lifting, §3.10):

- In an *integration problem* (clocks, prices, comparisons), a nonzero class is what cannot be made consistent. It is an obstruction.
- In a *code* (Chapter 12), a nonzero class is what local errors cannot change without crossing the code distance. It is protected information: the number of logical qubits of a CSS code is $\dim H_1$ (Calderbank & Shor 1996; Kitaev 2003).

Draken's normative stance follows the second face as well as the first. A healthy system keeps a bounded, named, nonzero ϰ: irreducible difference that is held rather than erased ([The Invariant](https://draken.info/posts/the-invariant/), [DRK-175](https://draken.info/posts/the-invariant/), §5) **[E/D]**.

### 3.10 Extensions: the second road to $H^1$

Principle 2.7 reaches $H^1$ through the *integration problem*: can relational data be integrated into local states? The corpus reaches the same group by a second road, the *lifting problem* of [The Cloven Section](https://draken.info/posts/the-cloven-section/) (DRK-174): can a visible quotient be lifted back into the whole it was cut from? This section shows that the two roads meet. Every lifting obstruction is the integration obstruction of a derived relational datum, and the Hodge spine applies to it unchanged **[D]**.

**Definition 3.9 (Short exact sequence of sheaves).** A sequence of cellular sheaves on $X$,
$$0\longrightarrow\mathcal K\xrightarrow{\ i\ }\mathcal E\xrightarrow{\ p\ }\mathcal Q\longrightarrow0,$$
is *short exact* if two conditions hold:

- on every cell σ, $0\to\mathcal K(\sigma)\to\mathcal E(\sigma)\to\mathcal Q(\sigma)\to0$ is exact;
- $i$ and $p$ commute with all restriction maps.

[DRK-174](https://draken.info/posts/the-cloven-section/) uses three readings of the terms:

- $p$ is the cut, *clēofan*;
- $\mathcal K$ is what the cut forgets;
- a *section* $s$ with $p\circ s=\mathrm{id}$ is the re-adhering, *clifian* **[E/D]**.

**Theorem 3.10 (Long exact sequence).** A short exact sequence of cellular sheaves induces the exact sequence
$$0\to H^0(\mathcal K)\to H^0(\mathcal E)\to H^0(\mathcal Q)\xrightarrow{\ \partial\ }H^1(\mathcal K)\to H^1(\mathcal E)\to H^1(\mathcal Q)\to\cdots .$$
The connecting map is computed as follows. Lift $q\in H^0(\mathcal Q)$ stalkwise to some $e\in C^0(\mathcal E)$. Then $\delta_{\mathcal E}e$ lies in $i\,C^1(\mathcal K)$, and $\partial q=[\,i^{-1}\delta_{\mathcal E}e\,]$.

*Proof.* Stalkwise exactness and compatibility with restriction maps give a short exact sequence of cochain complexes. The snake lemma then yields the long exact sequence and the stated formula (Weibel 1994, Thm. 1.3.1). For well-definedness: $p\,\delta_{\mathcal E}e=\delta_{\mathcal Q}q=0$, so $\delta_{\mathcal E}e\in\ker p=\operatorname{im}i$ on every edge. ∎ **[E]**

**Proposition 3.11 (Lifting is integration).** Let $q\in H^0(\mathcal Q)$ and choose any stalkwise lift $e$. Put $\omega_q:=i^{-1}\delta_{\mathcal E}e\in C^1(\mathcal K)$. Then:

(i) $\omega_q$ is closed: $\delta^1_{\mathcal K}\omega_q=0$. Its curl part vanishes.

(ii) The global lifts of $q$ are exactly $e-i\,k$ with $\delta^0_{\mathcal K}k=\omega_q$. Hence $q$ lifts if and only if $\varkappa(\omega_q)=\partial q=0$.

(iii) A different stalkwise lift changes $\omega_q$ by a gradient. So $\varkappa(\omega_q)$ and $E_{\text{harm}}(\omega_q)$ depend on $q$ alone.

(iv) If each $i_\sigma$ is an isometry, the least disagreement achievable by *any* lift is
$$\min_{\tilde e:\ p\tilde e=q}\|\delta_{\mathcal E}\tilde e\|^2=E_{\text{harm}}(\omega_q).$$

*Proof.*

(i) $\delta^1_{\mathcal E}\delta^0_{\mathcal E}e=0$ by Lemma 2.5, and $i$ is injective.

(ii) $p(e-ik)=q$. Moreover $\delta_{\mathcal E}(e-ik)=i(\omega_q-\delta_{\mathcal K}k)$, which vanishes if and only if $\delta_{\mathcal K}k=\omega_q$. Every lift of $q$ has this form, because two lifts differ by an element of $\ker p=\operatorname{im}i$. The class statement follows from Definition 3.5 and Theorem 3.10.

(iii) Two lifts differ by $ik'$, which changes $\omega_q$ by $\delta_{\mathcal K}k'$. Apply Proposition 3.3.

(iv) By (ii) and isometry, $\|\delta_{\mathcal E}(e-ik)\|^2=\|\omega_q-\delta_{\mathcal K}k\|^2$. Minimise over $k$ (Proposition 3.2) and use (i). ∎ **[E]**

The proposition gives the "phantom section" of [DRK-174](https://draken.info/posts/the-cloven-section/) a magnitude. A presented lift that does not commute, i.e. an apparent section of an unsplit cut, carries a disagreement of at least $E_{\text{harm}}(\omega_q)$ somewhere in the whole. A cut that "cleaves in both senses" is one with $\partial q=0$. Extraction, on [DRK-174](https://draken.info/posts/the-cloven-section/)'s reading of making versus taking (Mazzucato 2018), presents $q$ as if $\partial q=0$ when it is not **[D]**.

Two connections tie this section to the rest of the spine:

- Since $\omega_q$ is closed, lifting obstructions are purely topological. They never carry curvature.
- Example 4.8 computes a lifting obstruction on the ring and recovers the residual $\Phi^2/N$ of Proposition 4.1 exactly: the extension's holonomy *is* the clock ring's holonomy **[E]**.

### 3.11 Dictionary

| Component | Removable by | Invariant under gauge | Typical carrier | Draken reading |
|---|---|---|---|---|
| Gradient $\delta^0x^\star$ | Re-gauging local states (Prop. 3.2) | No | Inconsistent conventions, offsets | Local misalignment; repairable |
| Harmonic $h$, class ϰ | Nothing local; only changing the base | Yes | Holonomy around unmeasured holes | Structural difference: obstruction or ward |
| Curl $\delta^{1*}y$ | Nothing local; only removing curvature | Yes | Circulation inside measured loops | Generated incoherence; accrues curvature load |
| Lifting obstruction $\partial q$ | Nothing local; only changing the extension | Yes | Cuts that do not split (§3.10) | Phantom section; extraction |

The table is the spine of every reading in Parts II–V **[D]**.

---

## 4 Worked Examples

All numbers below are produced by `draken_v5_examples.py` (Appendix F). Where an example repeats one from v4.4, the v4.4 arithmetic is corrected and the correction is recorded in Appendix D **[E]**.

### 4.1 The institutional sheaf (v4.4 data, recomputed)

*Setting.* Five units: Finance (F), Engineering (E), HR (H), Executive (X), Customer (C). Each holds an assessment $x_v\in\mathbb R^2$ = (growth outlook, organisational health). Edges are X–F, X–E, X–H, E–C and F–H, with identity restriction maps, as in v4.4. The data are
$$x_F=(0.8,0.3),\ x_E=(0.4,0.7),\ x_H=(0.2,0.2),\ x_X=(0.9,0.8),\ x_C=(0.3,0.4).$$ **[D]**

*Energies.* The edge disagreements are X–F 0.26, X–E 0.26, **X–H 0.85**, E–C 0.10 and F–H 0.37. The total is $E=1.84$ and $\|x\|^2=3.16$. (v4.4 printed 3.07, giving 0.401 for its Γ; the correct v4.4-style value is 0.418.) **[E]**

*Cohomology.* The complex contains the cycle X–F–H, so for stalks $\mathbb R^2$ one gets $b_0=2$ (constant assessments) and $b_1=2$.

*Spectrum.* The eigenvalues of $L_{\mathcal F}$ are
$$\{0,0,\ 0.519,0.519,\ 2.311,2.311,\ 3,3,\ 4.170,4.170\},$$
so the spectral gap is $\lambda_1^+=0.519$ and the relaxation time is $1/\lambda_1^+=1.93$ reporting cycles. (v4.4 asserted $\lambda_1\approx0.12$ and a relaxation time of 8.3 without computation.) **[E]**

*Coherence (Chapter 5).* The default stiffness is $\tau^\ast=\dim C^0/\operatorname{tr}L=0.5$. Then:

- $\Gamma_{\tau^\ast}=0.886$;
- $\Gamma_0=0.792$;
- the spectral form $\Gamma_R=0.860$;
- the bounds of Proposition 5.4: $0.775\le0.886\le0.957$.

*Sensitivity.* The norm of $\nabla\Gamma_{\tau^\ast}$ restricted to each node (Proposition 5.9) is largest at H (0.196), then X (0.109), C (0.092), F (0.077) and E (0.065). A manipulator who wanted to move the score would target HR's report, which is also the end of the highest-energy edge **[E]**.

*Reference dependence.* The same data measured against the declared reference $x_{\text{ref}}=(0.5,0.5)$ (the scale midpoint) give $\Gamma_{\tau^\ast}=0.453$ and $\Gamma_0=0.006$, with $E$ unchanged at 1.84. The high uncentred score was mostly the shared positive mean, a global section (Proposition 5.7). **A Γ value without its declared reference is not interpretable.** This is now part of Axiom A2's reporting duty **[E/D]**.

### 4.2 The trophic chain (v4.4 data, recomputed)

*Setting.* A path Wolves–Elk–Willows–Rivers with stalks $\mathbb R^2$ = (population health, behavioural regime) and identity maps, using the three v4.4 snapshots. Identity maps assert that adjacent trophic levels "should" report equal values. This is a placeholder for estimated maps (Section 2.6), kept for comparability **[D]**.

| Snapshot | $E$ | $\|x\|^2$ | v4.4-style $1-R$ | $\Gamma_R$ | $\Gamma_0$ | $\Gamma_{\tau^\ast}$ |
|---|---|---|---|---|---|---|
| Pre-removal (c. 1920) | 0.20 | 4.32 | 0.954 | 0.986 | 0.975 | 0.987 |
| Post-removal (c. 1990) | 1.55 | 1.00 | **−0.550** | 0.546 | 0.485 | 0.662 |
| Restored (c. 2020) | 0.08 | 2.81 | 0.972 | 0.992 | 0.987 | 0.992 |

Two corrections follow:

- v4.4 printed $\|x\|^2=3.83$ and $1.30$ for the first two snapshots and reported $\Gamma_{\text{post}}=-0.192$. The arithmetic is wrong, and the negative value is not "anti-coherence" in any case. It arises because $R(x)=E/\|x\|^2$ is a Rayleigh quotient that can exceed 1 whenever $\lambda_{\max}>1$. Every v5.0 measure lies in $[0,1]$ by construction (Proposition 5.3).
- The ordering pre < restored is within the range that measurement noise alone would produce for data of this precision (Proposition 5.10). It should not be read **[E]**.

![Resolvent coherence Γ_τ as a function of stiffness for the three trophic snapshots. Solid: Γ_τ; dotted: its limit Γ_0; dashed: the default τ*.](figures/fig2_gamma_tau.png){width=80%}

### 4.3 The clock ring: holonomy and its residue

*Setting.* $N=6$ clocks on a ring. Each link measures the offset between neighbours, $\omega_e$, with stalks $\mathbb R$. The true offsets are a gradient, and a uniform holonomy $\Phi=0.6$ is added: $\omega=\delta^0t+\Phi/N$ **[D]**.

**Proposition 4.1 (Ring residual).** On the scalar ring with $N$ edges and no face, every ω with holonomy $\Phi=\sum_e\omega_e$ satisfies
$$\min_x\|\omega-\delta^0x\|^2=\Phi^2/N .$$
The residual is entirely harmonic.

*Proof.* On a cycle, $\operatorname{im}\delta^0=\{g:\sum_eg_e=0\}$, which has dimension $N-1$. The orthogonal complement is spanned by $\mathbf 1$. The projection of ω onto $\mathbf 1$ is $(\Phi/N)\mathbf 1$, with squared norm $\Phi^2/N$. With no faces there is no curl. ∎ **[E]**

*Computed.* The holonomy is 0.600 and $E_{\text{harm}}=0.0600=\Phi^2/N$. When the ring's interior is declared a face, the same 0.0600 appears entirely as $E_{\text{curl}}$ and $E_{\text{harm}}=0$, as Proposition 3.7 requires. This is the result stated, for a gravitational ring, in [The Dragged Frame](https://draken.info/posts/the-dragged-frame/) (DRK-171) **[E]**.

**Proposition 4.2 (U(1) ring).** Let each edge transport phases by $e^{i\phi/N}$, so that the holonomy is $e^{i\phi}$. The connection Laplacian has eigenvalues
$$\lambda_k=2-2\cos\!\Big(\frac{2\pi k+\phi}{N}\Big),\qquad k=0,\dots,N-1 .$$
In particular $H^0=0$ unless $\phi\in2\pi\mathbb Z$.

*Proof.* The Fourier modes $x_j=e^{2\pi ikj/N}$ diagonalise the circulant connection Laplacian. ∎ **[E]**

For $\phi=1$ the computed spectrum is $\{0.0277,0.7265,1.3012,2.6988,3.2735,3.9723\}$, matching the closed form to $10^{-6}$. No global phase assignment exists ($b_0=0$), and the best attainable spectral coherence is $1-\lambda_{\min}/\lambda_{\max}=0.993$. This is the Aharonov–Bohm ring in sheaf form (Aharonov & Bohm 1959): a flux that is invisible locally on every link and unremovable globally **[E]**.

![(a) The irreducible residual on a scalar ring is Φ²/N. (b) Spectrum of the U(1) ring as the flux varies; the lowest eigenvalue vanishes only at trivial holonomy.](figures/fig3_ring.png){width=100%}

### 4.4 The exchange complex: gradient, harmonic and curl together

*Setting.* Four currencies A, B, C, D. Edge data are log exchange rates on A→B, B→C, C→A, C→D and D→A. The triangle ABC is declared a face, because its triangular cross-rates are quoted and checked; the loop ACD is not. The data are built from log prices $p=(0,0.10,-0.05,0.20)$, plus an arbitrage of 0.03 on A→B and a drift of 0.015 on each of C→D and D→A **[D]**.

*Computed.*

| | A→B | B→C | C→A | C→D | D→A |
|---|---|---|---|---|---|
| ω | 0.130 | −0.150 | 0.050 | 0.265 | −0.185 |
| gradient | 0.115 | −0.165 | 0.050 | 0.250 | −0.200 |
| harmonic | 0.005 | 0.005 | −0.010 | 0.015 | 0.015 |
| curl | 0.010 | 0.010 | 0.010 | 0 | 0 |

- The curvature on ABC is 0.030, which is exactly the triangular arbitrage: the product of quoted rates around the triangle is $e^{0.03}$.
- $E_{\text{curl}}=3.0\times10^{-4}$, by projection and by Proposition 3.4.
- $E_{\text{harm}}=6.0\times10^{-4}$ and $\Gamma^1=0.994$; $b_0=b_1=1$.
- The periods of ω are 0.030 around A→C→D→A and 0.060 around A→B→C→D→A; they differ by the face curvature (Proposition 3.6). The harmonic part assigns the hole a single period, 0.040 **[E]**.

Reading: an arbitrage inside a checked triangle is curvature, local and in principle detectable by anyone who quotes the triangle. A drift around an unchecked loop is a harmonic class, detectable only by someone who traverses the whole loop. The same market inconsistency is a "local scandal" or a "systemic hole" depending on what is jointly measured (Proposition 3.7) **[D]**.

### 4.5 The toric code

*Setting.* The $L\times L$ square lattice on the torus, with qubits on edges. X-checks come from faces ($H_X=\partial_2^\top$) and Z-checks from vertices ($H_Z=\partial_1$), over $\mathbb F_2$ (Kitaev 2003; Dennis et al. 2002) **[E]**.

*Computed.*

- $L=3$: $n=18$, $\operatorname{rank}\partial_1=\operatorname{rank}\partial_2=8$, so $k=n-8-8=2$.
- $L=4$: $n=32$, ranks 15 and 15, so $k=2$.
- In both cases the Euler characteristic is 0, and $k=\dim H_1(T^2;\mathbb F_2)=2$, with distance $d=L$ **[E]**.

The commutation of all checks is $\partial_1\partial_2=0$: Lemma 2.5 over $\mathbb F_2$ **[E]**.

### 4.6 Kuramoto synchrony is resolvent coherence

**Proposition 4.3 (Order parameter).** Let $G$ be any connected graph with the constant sheaf $\mathbb C$, and let $z_j=e^{i\theta_j}$. Then
$$\Gamma_0(z)=r^2,\qquad r=\Big|\frac1N\sum_je^{i\theta_j}\Big| ,$$
where $r$ is the Kuramoto order parameter. On the complete graph,
$$\Gamma_\tau(z)=r^2+\frac{1-r^2}{1+\tau N}.$$

*Proof.*

1. Connectedness gives $H^0=\operatorname{span}(\mathbf 1)$.
2. The projection is $Pz=(\bar z)\mathbf 1$, with $\bar z$ the mean.
3. Hence $\|Pz\|^2=N|\bar z|^2=Nr^2$, while $\|z\|^2=N$, so $\Gamma_0(z)=r^2$.
4. On the complete graph every nonzero eigenvalue equals $N$; substitute into the spectral form of $\Gamma_\tau$ (Proposition 5.3). ∎ **[E]**

*Computed.* For 40 Cauchy-distributed oscillators ($K=1.5$), simulated to $t=30$:

| Graph | max $\lvert r^2-\Gamma_0\rvert$ | final $r$ | final $\Gamma_{\tau^\ast}$ |
|---|---|---|---|
| Complete | $4\times10^{-16}$ | 0.799 | 0.817 |
| Ring, neighbours at distance 1 and 2 | $4\times10^{-17}$ | 0.141 | 0.600 |

On the ring, global synchrony fails while local phase agreement is high. $\Gamma_0$ (global) and $\Gamma_{\tau^\ast}$ (scale-limited) separate the two, which is what the stiffness τ is for (Section 5.2). This makes exact the claim in [The Carrier and the Cargo](https://draken.info/posts/the-carrier-and-the-cargo/) (DRK-189) that $r$ is "the rank-1 shadow of Γ" **[E/D]**.

![Kuramoto simulation: r² and Γ₀ coincide to machine precision on any connected graph (complete and ring shown); Γ_τ* also registers local phase agreement.](figures/fig4_kuramoto.png){width=80%}

### 4.7 Signed relations: structural balance as holonomy

*Setting.* A triangle of three agents. Each edge carries a sign $s_e\in\{\pm1\}$ ("ally/enemy"). The sheaf has stalks $\mathbb R$ and transports $x_v\mapsto s_ex_u$, i.e. an $O(1)$ connection **[D]**.

**Proposition 4.4 (Balance).** On a connected graph with an $O(1)$ sheaf, $H^0\neq0$ if and only if every cycle has sign product $+1$. That is, the signed graph is *balanced* in Harary's sense.

*Proof.* A nonzero global section is determined by its value at one vertex, propagated along a spanning tree. It is consistent on a non-tree edge if and only if the cycle that edge closes has trivial holonomy. ∎ (Harary 1953; Altafini 2013) **[E]**

*Computed.*

| Signs | Eigenvalues | $b_0$ | Reading |
|---|---|---|---|
| $(+,-,-)$, balanced | $\{0,3,3\}$ | 1 | A global section exists: two opposed camps with coherent values |
| $(+,+,-)$, unbalanced | $\{1,1,4\}$ | 0 | Frustration: no consistent assignment |

This corrects a claim in [The Carrier and the Cargo](https://draken.info/posts/the-carrier-and-the-cargo/) (DRK-189, §6 ii) that "polarisation is a nonzero $H^1$ class" **[E/D]**:

- *Polarisation* into two internally coherent, mutually opposed camps is a global section of a balanced signed sheaf, i.e. bipartite consensus (Altafini 2013). It is an $H^0$ state.
- *Fragmentation* is disconnection: $b_0$ grows as edges are cut.
- *Frustration*, alliances that cannot be made consistent, is nontrivial holonomy. That is the genuine obstruction.

### 4.8 A cut that does not split

*Setting.* Take the ring of Example 4.3, $N=6$. Let $\mathcal E$ have stalks $\mathbb R^2$. On edge $k$, the head's restriction map is the shear $\begin{pmatrix}1&a_k\\0&1\end{pmatrix}$ and the tail's is the identity. Put
$$a=(0.10,\,0.05,\,0,\,0.08,\,0.02,\,0.05).$$
The first coordinate is a constant subsheaf $\mathcal K$, and the quotient $\mathcal Q$ is the constant sheaf on the second coordinate. This is a short exact sequence (Definition 3.9) **[D]**.

*Computed.* Take the global section $q\equiv1$ of $\mathcal Q$ and the stalkwise lift $e=(0,1)$ on every vertex. Then:

- $\delta_{\mathcal E}e$ has zero second coordinates, as Theorem 3.10 requires, and first coordinates $\omega_q=a$;
- the holonomy is $\sum_ka_k=0.30$;
- $E_{\text{harm}}(\omega_q)=0.0150=0.30^2/6$ and $E_{\text{curl}}=0$ (Proposition 3.11(i));
- the best lift found by direct least squares over all lifts has residual disagreement 0.0150 (Proposition 3.11(iv));
- $b_0(\mathcal E)=1$: the only global sections come from $\mathcal K$, so $q$ does not lift.

The shear is a "cut" whose re-gluing accumulates a twist of 0.30 around the loop **[E]**.

### 4.9 The running example across the monograph

The institutional sheaf of Example 4.1 is the monograph's running example. Every instrument is applied to the same data, so the measures can be compared on one object **[D]**.

| Quantity | Value | Where |
|---|---|---|
| Disagreement energy $E$; $\lVert x\rVert^2$ | 1.84; 3.16 | Ex. 4.1 |
| Cohomology $b_0$, $b_1$ (cycle X–F–H) | 2, 2 | Ex. 4.1 |
| Spectral gap $\lambda_1^+$; relaxation time | 0.519; 1.93 cycles | Ex. 4.1, Thm. 15.1 |
| $\Gamma_{\tau^\ast}$ against no reference / against midpoint | 0.886 / 0.453 | Ex. 4.1, standard 5.7a |
| $\Gamma_0$; $\Gamma_R$; Jensen and gap bounds | 0.792; 0.860; [0.775, 0.957] | Prop. 5.4 |
| Most leveraged node (sensitivity) | HR (0.196) | Prop. 5.9 |
| Naive vs debiased Γ at noise σ = 0.2 | 0.852 vs 0.886 (true 0.886) | Prop. 5.10 |
| Agreement fraction $\sigma_{0.8}$ vs energy bound | 0.80 ≥ 0.425 | Prop. 5.11 |
| Repair map = Tweedie denoiser | agree to $3\times10^{-16}$ | Prop. 5.12 |
| Γ after deleting all relations | 1.000, with $b_1$ = 0 and $b_0$ = 10 | Thm. 19.2 |
| Compliance H→C, full and after one deletion | 2.667 → 4.000 → ∞ | Prop. 19.6 |

Read together, the rows say what the monograph says. The data have one structural hole (the X–F–H loop) and one dominant local disagreement (X–H). The score depends on the declared reference. Noise would make the institution look worse than it is. And the cheapest way to make it look perfect, deleting its relations, destroys the hole, splits the institution, and makes it unable to carry load **[D]**.
