# Part III — Bridges

A *bridge* identifies a Draken object with an object of an established science. Bridges carry the framework's claim to generality, so each one is graded **[D]**:

- **Exact**: the identification is a mathematical identity. It holds by definition or by a theorem.
- **Structural**: the same mathematics governs both, but with a modelling assumption (linearisation, a declared complex).
- **Analogy**: shared form without shared mechanism. It is never used as evidence.
- **Excluded**: the corpus claim is ill-defined, unsupported or false, and does not enter v5.0.

## 10 Ledger, Synchronisation and Gravity

### 10.1 The bridge ledger

| Bridge | Draken object | Grade | Chapter | Posts |
|---|---|---|---|---|
| Clock synchronisation, Sagnac gap | Holonomy of offset data; ϰ or curl | Exact | 10 | [DRK-168](https://draken.info/posts/the-one-way-gauge/) |
| Frame-dragging | Curvature of the sync form | Structural (weak field) | 10 | [DRK-171](https://draken.info/posts/the-dragged-frame/) |
| Berry and Aharonov–Bohm phase | U(1)-sheaf holonomy | Exact | 11 | [DRK-143](https://draken.info/posts/the-braided-substrate/), [DRK-172](https://draken.info/posts/picking-berries/) |
| Wilczek–Zee holonomy | U(n)-sheaf holonomy | Exact | 11 | [DRK-172](https://draken.info/posts/picking-berries/) |
| Connection Laplacian, frustration | $\lambda_{\min}$, Γ ceiling | Exact | 11 | — |
| CSS and Tanner codes | $H^1$, $H^0$ of sheaves over $\mathbb F_2$ | Exact | 12 | [DRK-190](https://draken.info/posts/the-warded-class/) |
| Kuramoto order parameter | $\Gamma_0$ of the phase sheaf | Exact (Prop. 4.3) | 13 | [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/) |
| Structural balance | $O(1)$ holonomy | Exact (Prop. 4.4) | 4, 13 | [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/) |
| Linking number | $H^1$ pairing | Exact | 9 | [DRK-175](https://draken.info/posts/the-invariant/) |
| Continuity equation | $\dot\varrho=\delta^{0\top}j+S$ | Exact (discrete) | 16 | [DRK-186](https://draken.info/posts/konkurrent/) |
| Lifting obstructions of extensions | Connecting map $\partial$, $\varkappa(\omega_q)$ | Exact (Thm. 3.10, Prop. 3.11) | 3, 4 | [DRK-174](https://draken.info/posts/the-cloven-section/) |
| Gaussian MRF, Tweedie denoising | Repair map $(I+\tau L)^{-1}$ | Exact (Prop. 5.12) | 5 | — |
| Score-based diffusion models | Structured OU forward process | Exact for linear-Gaussian; Structural otherwise | 15 | [DRK-164](https://draken.info/posts/the-sleepless-section/) |
| Lindeman transfer, biomagnification | Global sections of scaled path sheaves | Exact as identity given the declared scaling; the ~10% rule itself is an empirical regularity [S] | 16 | [DRK-136](https://draken.info/posts/the-komodoburger-franchise/) |
| Trophic level, HTL | Leontief solution of the diet matrix | Exact (Prop. 16.4) | 16 | [DRK-136](https://draken.info/posts/the-komodoburger-franchise/) |
| Idempotent monads, sheafification | Projection $P$ as limit of repair | Exact (Prop. 16.5) | 16 | [DRK-140](https://draken.info/posts/the-productile-monad/), [DRK-163](https://draken.info/posts/the-two-optics/) |
| Knowledge distillation | Divergence-valued edges; Fisher geometry | Structural (second order) | 16 | [DRK-163](https://draken.info/posts/the-two-optics/) |
| Rayleigh monotonicity, compliance | Anchored dual of excision | Exact (Prop. 19.6) | 19 | [DRK-161](https://draken.info/posts/the-compartmentalized-manifold/) |
| Surface genus | $b_1(S^2)=0$, $b_1(T^2)=2$, solid torus 1 | Exact; developmental reading [H] | 9 | [DRK-166](https://draken.info/posts/the-sonder-egg/) |
| Agreement counts σ, T | $\ell^0$ coherence; syndrome complement | Exact bound (Prop. 5.11) | 5 | [DRK-139](https://draken.info/posts/the-welcomed-section/), [DRK-142](https://draken.info/posts/wrestling-with-god/) |
| Sheaf diffusion ↔ linearised Kuramoto | $\dot x=-\kappa Lx$ | Structural | 15 | [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/) |
| Leontief ↔ variational planning | Global section of a production sheaf | Analogy | 16 | [DRK-118](https://draken.info/posts/countries-as-collective-minds/) |
| Renormalisation as debt discharge | Counterterm ↔ $P_K$ | Analogy | 14 | [DRK-149](https://draken.info/posts/the-continuous-dimension/) |
| Conformal bootstrap | $b_0=1$ uniqueness | Analogy | 14 | [DRK-185](https://draken.info/posts/bootstrap-inception/) |
| AdS/CFT as the 18-layer stack | — | Excluded | 14 | [DRK-185](https://draken.info/posts/bootstrap-inception/) |
| Born rule by preimage counting | — | Excluded | 14 | [DRK-141](https://draken.info/posts/the-finite-sheaf/) |
| Consciousness integral Φ | — | Excluded | 14 | [DRK-153](https://draken.info/posts/no-trace-no-section/) |
| Magic-state curvature of geometry | — | Excluded | 14 | [DRK-156](https://draken.info/posts/the-magical-substrate/) |

### 10.2 Synchronisation is a connection

In a stationary spacetime, an observer can synchronise a clock with a neighbouring clock. The correction to be applied is
$$\Delta t=-\frac{g_{0i}}{g_{00}}\,dx^i .$$
Synchronisation around a closed contour is in general impossible, because the corrections do not sum to zero (Landau & Lifshitz 1975, §84) **[E]**.

Define the synchronisation 1-form $\omega_{\text{sync}}=-(g_{0i}/g_{00})\,dx^i$; sign conventions vary and do not affect exactness. A global synchronisation is a function $t_0$ with $dt_0=\omega_{\text{sync}}$. It exists if and only if $\omega_{\text{sync}}$ is exact. This is the integration problem of Principle 2.7 **[E]**.

**Discretisation.** A network of clocks is a 1-complex:

- vertices are clocks;
- edges are links on which the offset $\omega_e$ is measured by two-way exchange;
- the stalks are $\mathbb R$.

A global time assignment exists if and only if $\omega\in\operatorname{im}\delta^0$. The irreducible residual is $E_{\text{obs}}$ (Proposition 3.2) **[E]**.

**Prior engineering work.** Integrating relative clock offsets over a network and attributing what cannot be integrated to cycles is standard in distributed clock synchronisation (Giridhar & Kumar 2006). Freris, Graham & Kumar (2011) show that when link delays are unknown, clock offsets cannot be uniquely determined from timestamp exchanges, and they characterise what can be. Estimating node values from noisy relative measurements has error variance governed by effective resistance in the measurement graph (Barooah & Hespanha 2008). The Draken contribution here is the reading, and the link to the rest of the spine, not the mathematics **[E/D]**.

**Conventionality as gauge.** Reichenbach's ε-conventionality of distant simultaneity is the freedom to choose the one-way split of a two-way light time (Reichenbach 1928). That freedom adds a gradient $\delta^0g$ to ω. By Proposition 3.3 it changes neither the curvature nor ϰ. The physical content of synchronisation is the gauge-invariant part, which is the reading of [The One-Way Gauge](https://draken.info/posts/the-one-way-gauge/) (DRK-168) **[E/D]**.

**Sagnac.** In a frame rotating with angular velocity Ω, the desynchronisation accumulated around a loop enclosing area $A$ is $2\Omega A/c^2$ to first order. The interferometric Sagnac delay between counter-propagating beams is twice this, $4\Omega A/c^2$ (Post 1967) **[E]**.

**Correction to the corpus.** The rotating disc is simply connected. Its synchronisation obstruction is therefore *curvature* (curl), $\nabla\times(g_{0i}/g_{00})\ne0$, not a topological class. It appears as a harmonic class only when the interior of the loop is excluded from the measured base, as for a ring of clocks around an unmeasured centre (Proposition 3.7). [DRK-168](https://draken.info/posts/the-one-way-gauge/)'s "the obstruction lives in $H^1$" is correct for the ring and incorrect for the disc **[E/D]**.

### 10.3 Frame-dragging

To first order in a weak, stationary field ($G=c=1$),
$$ds^2=-(1+2\Phi_N)\,dt^2+2A_i\,dx^i\,dt+(1-2\Phi_N)\,\delta_{ij}\,dx^idx^j .$$
A rotating mass of angular momentum $\mathbf J$ produces the gravitomagnetic potential $\mathbf A\propto\mathbf J\times\mathbf r/r^3$ (Lense & Thirring 1918). Normalisation conventions for gravitomagnetism differ by constant factors **[E]**.

Then $\omega_{\text{sync}}\approx\pm A_i\,dx^i$. By Stokes, the desynchronisation around a loop is the flux of $\mathbf B_g=\nabla\times\mathbf A$ through any surface it bounds. That flux is the curvature of the sync form **[E]**.

For a ring of $N$ clocks with holonomy $\Phi$ and no measured interior, the irreducible residual is $\Phi^2/N$ (Proposition 4.1). This is the inequality of [The Dragged Frame](https://draken.info/posts/the-dragged-frame/) (DRK-171), §2, in its exact discrete form **[E/D]**.

[DRK-171](https://draken.info/posts/the-dragged-frame/)'s further readings, of the horizon as a convergence obstruction and of the information paradox as debt, are analogies **[H]**. They are not used in v5.0.

## 11 Gauge, Berry and Holonomy

### 11.1 Berry's phase as a U(1) sheaf

A quantum eigenstate $|n(\mathbf R)\rangle$ transported adiabatically around a closed loop $\mathcal C$ in parameter space acquires the geometric phase
$$\gamma_n(\mathcal C)=\oint_{\mathcal C}\mathbf A_n\cdot d\mathbf R=\iint_S\boldsymbol\Omega_n\cdot d\mathbf S,\qquad \mathbf A_n=i\langle n|\nabla_{\mathbf R}n\rangle$$
(Berry 1984; Simon 1983) **[E]**.

Its discrete, gauge-invariant form for states $|u_1\rangle,\dots,|u_N\rangle=|u_1\rangle$ sampled along the loop is
$$\gamma=-\operatorname{Im}\ln\prod_k\langle u_k|u_{k+1}\rangle$$
(Resta 2000) **[E]**.

**Proposition 11.1 (Discrete Berry phase is sheaf holonomy).** Build a sheaf on the sampled loop as follows:

- stalks $\mathbb C$;
- the edge $k\to k+1$ transports by the unit phase of $\langle u_k|u_{k+1}\rangle$.

This is a U(1) sheaf whose holonomy is $e^{-i\gamma}$. It has a nonzero global section if and only if $\gamma\in2\pi\mathbb Z$. Its connection-Laplacian spectrum is that of Proposition 4.2 with $\phi=-\gamma$ (for uniform transport) **[E]**.

*Proof.* The product of transports around the loop is $\prod_k\langle u_k|u_{k+1}\rangle/|\cdot|=e^{-i\gamma}$. Apply Proposition 4.2 after a gauge transformation that makes the transports uniform. ∎ **[E]**

The Aharonov–Bohm effect is the special case of an external flux through the ring (Aharonov & Bohm 1959) **[E]**.

**Holonomic robustness.** The phase depends on the loop's geometry, not on the speed at which it is traversed. Holonomic quantum computation exploits this robustness (Zanardi & Rasetti 1999) **[E]**. [Picking Berries](https://draken.info/posts/picking-berries/) (DRK-172) reads archetypes as transported eigenstates. That reading is an analogy **[M]**, and only the mathematics enters v5.0.

### 11.2 Non-abelian holonomy

For a degenerate eigenspace of dimension $n$, transport is by the path-ordered exponential of a $\mathfrak u(n)$-valued connection. The holonomy is a unitary matrix (Wilczek & Zee 1984) **[E]**.

As a sheaf, the stalks are $\mathbb C^n$ and the transports are unitary. $H^0$ is the subspace fixed by every holonomy. Its dimension is the number of independent states that return to themselves around every loop **[E]**.

### 11.3 Frustration and the coherence ceiling

For any connection sheaf (orthogonal or unitary transports), there is a ceiling on attainable coherence:
$$\max_x\Gamma_R(x)=1-\lambda_{\min}/\lambda_{\max} .$$

- If the holonomy is trivial, $\lambda_{\min}=0$ and the ceiling is 1.
- Otherwise $\lambda_{\min}>0$, and no assignment of local states achieves full coherence.

Bandeira, Singer & Spielman (2013) bound $\lambda_{\min}$ of the graph connection Laplacian above and below by a combinatorial frustration constant, a Cheeger-type inequality. Singer & Wu (2012) developed the connection Laplacian for data on manifolds **[E]**.

Reading: in a system whose relations carry transports (translations, conversions, sign conventions), the topology of those transports sets a hard ceiling on achievable coherence. No amount of local effort can exceed it. The only remedies are to change the transports or the base **[E/D]**.

### 11.4 What is not degree one

| Invariant | Degree | Draken relation |
|---|---|---|
| Berry curvature integrated over a closed surface (Chern number, TKNN; Thouless et al. 1982) | $H^2$ | Quantised integrated curvature on a closed 2-complex. Not ϰ |
| Jones polynomial, Chern–Simons expectation values (Witten 1989) | Not a cohomology class of the sheaf | Analogy only ([DRK-143](https://draken.info/posts/the-braided-substrate/), [DRK-175](https://draken.info/posts/the-invariant/)) |
| Tensor-network contraction as gluing (Vidal 2008; Verstraete & Cirac 2004) | — | Plausible sheaf structure, not formalised here **[H]** |

The corpus's statements that these objects "are" the Draken invariant are restated as analogies **[D]**.

## 12 Codes: Where $H^1$ Is Protected

### 12.1 CSS codes are chain complexes

A chain complex over $\mathbb F_2$, $C_2\xrightarrow{\partial_2}C_1\xrightarrow{\partial_1}C_0$ with $\partial_1\partial_2=0$, defines a CSS code as follows:

- qubits are placed on $C_1$;
- the X-checks are $H_X=\partial_2^\top$ and the Z-checks are $H_Z=\partial_1$;
- the checks commute because $H_XH_Z^\top=(\partial_1\partial_2)^\top=0$;
- the number of logical qubits is
$$k=\dim H_1=n-\operatorname{rank}\partial_1-\operatorname{rank}\partial_2$$

(Calderbank & Shor 1996; Steane 1996; Kitaev 2003) **[E]**.

The toric code on an $L\times L$ torus has $k=2$ and distance $d=L$. This is computed for $L=3,4$ in Example 4.5 **[E]**.

### 12.2 Tanner codes are global sections

A Tanner code places a local code on each vertex. A word is valid when its restriction to every vertex neighbourhood lies in the local code; the code is therefore $H^0$ of a sheaf. Panteleev & Kalachev (2024) define *sheaf codes* in exactly these terms. Quantum Tanner codes (Leverrier & Zémor 2022) and asymptotically good quantum LDPC codes (Panteleev & Kalachev 2022) are built from such structures over expanding complexes **[E]**.

Later constructions reported in [The Warded Class](https://draken.info/posts/the-warded-class/) (DRK-190) are unreviewed preprints **[S]**:

- cubical sheaf complexes with constant soundness (Chen et al. 2026);
- explicit good quantum locally testable codes (Gay & Jeronimo 2026).

**Exactness of the bridge.** Placing qubits in degree 1 of a sheaf cochain complex gives $k=\dim H^1(X;\mathcal F)=b_1$. The coherence genus of a Draken sheaf and the number of logical qubits of a sheaf code are the same functor applied to different sheaves **[E/D]**.

### 12.3 Locality forces fragility

For codes whose checks are geometrically local in two dimensions, $kd^2=O(n)$ (Bravyi, Poulin & Terhal 2010). Many protected differences can each be erased cheaply unless connectivity is non-local **[E]**.

Read through the warded triple, flat locality forces the "fragile plurality" regime. Holding many differences robustly requires expansion: relations that reach beyond the local ([The Warded Class](https://draken.info/posts/the-warded-class/), [DRK-190](https://draken.info/posts/the-warded-class/), §§4–5) **[D]**.

The toric code's soundness tends to zero. A string error of length ℓ has syndrome weight 2 regardless of ℓ, so damage accumulates silently until it crosses $d/2$. This is the coding form of silent debt (Section 7.4) **[E/D]**.

## 13 Oscillators, Beliefs and Signed Relations

### 13.1 Kuramoto

The Kuramoto model is
$$\dot\theta_i=\omega_i+\frac KN\sum_jA_{ij}\sin(\theta_j-\theta_i) .$$
For all-to-all coupling with a symmetric unimodal frequency density $g$, synchrony onsets at $K_c=2/(\pi g(0))$ (Kuramoto 1984; Strogatz 2000; Acebrón et al. 2005) **[E]**.

For identical frequencies the dynamics are the gradient flow of
$$U(\theta)=-\frac{K}{2N}\sum_{ij}A_{ij}\cos(\theta_j-\theta_i) .$$
Linearised about synchrony, they become $\dot\theta=-\tfrac KN L\theta$: sheaf diffusion on the constant sheaf (Chapter 15) **[E]**.

**Carrier and cargo.** The approved KOs separate two quantities ([The Carrier and the Cargo](https://draken.info/posts/the-carrier-and-the-cargo/), [DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/)):

- *coordination* (carrier): temporal alignment;
- *representational alignment* (cargo): holding the same belief vector.

In v5.0 they are two sheaves on the same interaction graph **[E/D]**:

- The **carrier sheaf** has scalar U(1) stalks. Its coherence is $\Gamma_0=r^2$ (Proposition 4.3).
- The **cargo sheaf** has stalks $\mathbb R^d$ and estimated restriction maps. Its coherence is $\Gamma_\tau$ of the belief data.

Because the stalks differ in dimension, a one-dimensional carrier cannot represent content. Phase synchrony is uninformative about what is aligned (Varlet & Grootswagers 2024) **[S/D]**. Phase coupling between brains is measured by the phase-locking value (Lachaux et al. 1999) **[E]**.

**Hypothesis H13.1 (Dissociation).** Carrier coherence and cargo coherence can be driven independently. Hyperscanning studies that measure both will find the four combinations, including high-carrier/low-cargo ("in sync about nothing") and high-carrier/high-cargo/low-anchoring (the synchronised lie of Proposition 5.8) **[H]**.

[DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/) also proposes a swarmalator-type cross-gating between the two layers, in which agreement raises coupling and coupling raises transfer (O'Keeffe, Hong & Strogatz 2017). It is retained as a model to be tested, not a result **[H]**.

### 13.2 Bounded confidence and fragmentation

In bounded-confidence dynamics, agents interact only with those whose beliefs lie within ε of their own (Hegselmann & Krause 2002). The interaction complex is therefore state-dependent. As beliefs separate, edges vanish and $b_0$ rises **[E]**.

Fragmentation is an increase in $b_0$, the number of components that can each be internally coherent. It is detected spectrally by the approach of $\lambda_1^+$ to zero (Fiedler 1973) **[E/D]**.

### 13.3 Signed relations

Antagonistic interactions are modelled by signed restriction maps (Altafini 2013). By Proposition 4.4:

- *bipartite consensus*, two opposed camps, is a global section of a balanced signed sheaf;
- *frustration* is nontrivial $O(1)$ holonomy (Harary 1953).

The three phenomena previously called "polarisation" in the corpus are now distinct **[E/D]**:

| Phenomenon | Signature |
|---|---|
| Opposition | $b_0\ge1$ for the signed sheaf |
| Fragmentation | $b_0$ increasing for the unsigned sheaf |
| Frustration | $\lambda_{\min}>0$ for the signed sheaf |

## 14 Interpretive Bridges and Exclusions

### 14.1 Analogies retained, with their status

**Renormalisation.** In dimensional regularisation a divergent integral is computed in $d=4-\varepsilon$ dimensions, where it has a pole:
$$\operatorname{Gamma}(\varepsilon/2)=\frac{2}{\varepsilon}-\gamma_E+O(\varepsilon)$$ (Euler's Gamma function, written out to avoid collision with Γ).
The pole is removed by a counterterm (’t Hooft & Veltman 1972; Peskin & Schroeder 1995) **[E]**. [The Continuous Dimension](https://draken.info/posts/the-continuous-dimension/) (DRK-149) reads these as follows:

- the pole as an obstruction;
- the counterterm as a discharge $P_K$ of debt (Section 7.2);
- the renormalisation-group flow as recorded history.

The pole is not a cohomology class of any declared sheaf, so the reading is an analogy and carries no evidential weight **[M]**.

**Bootstrap.** In the S-matrix and conformal bootstraps, consistency conditions alone fix a theory. [Bootstrap Inception](https://draken.info/posts/bootstrap-inception/) (DRK-185) reads this as $b_0=1$: a unique global section. The analogy is structurally apt, since uniqueness from consistency is exactly $\dim H^0=1$. It is not a derivation of any bootstrap result **[D]**.

**Wick rotation.** [The Imaginary Dimension](https://draken.info/posts/the-imaginary-dimension/) (DRK-123) reads evolutionary anticipation through the analytic continuation $t\mapsto-i\tau$ **[M]**.

**One propagation operator.** [The Countable Mouth](https://draken.info/posts/the-countable-mouth/) (DRK-181) proposes that every rung from vacuum to vocabulary repeats one operator: *break* a symmetry, *keep* the record, *copy* it. Its components are each established:

- Landauer's bound $E_{\min}=k_BT\ln2$ per erased bit (Landauer 1961; verified by Bérut et al. 2012) **[E]**;
- Eigen's error threshold $L\lesssim\ln\sigma/(1-q)$ for the maximum record length (Eigen 1971) **[E]**.

That one operator spans all rungs is Draken synthesis **[D]**.

### 14.2 Excluded claims

The following corpus claims do not enter v5.0. Each exclusion gives a reason; none is a judgement on the post's other content **[D]**.

1. **AdS/CFT as the formal model of the 18-layer stack** ([DRK-185](https://draken.info/posts/bootstrap-inception/), §VIII). No dictionary between bulk and boundary quantities is given, and none is derivable from the sheaf apparatus.
2. **The Born rule as preimage counting** ([DRK-141](https://draken.info/posts/the-finite-sheaf/), §4.4). Counting fine-grained outcomes weights each equally. It reproduces Born probabilities only if preimage sizes are *assumed* proportional to $|\text{amplitude}|^2$, which is the thing to be derived **[E]**. The finiteness axiom A0 is kept; this derivation is not.
3. **A consciousness integral** $\Phi=\int\|H^1\|^{-1}dV$ ([DRK-153](https://draken.info/posts/no-trace-no-section/)). $H^1$ is a vector space and has no norm. The defensible replacements are $b_1$ or $\|h\|$ for a declared ω, but no claim about consciousness is made with either. The post's main argument, that a world line is a section and so no trace means no section, is retained as an [E/D] remark.
4. **A curvature of geometry sourced by magic-state resources** ([DRK-156](https://draken.info/posts/the-magical-substrate/), $\delta\mathcal L_{\text{gravity}}\sim\mathcal M[\rho_{\text{boundary}}]$, $\Gamma_{\text{threshold}}$). Stabiliser theory and magic monotones are established. The coupling to gravity is not, and is not defined.
5. **The genus scaling factor** $\mathrm{AC}(1)\gtrsim2.78\,\mathrm{AC}(0)$ ([DRK-166](https://draken.info/posts/the-sonder-egg/)). No source or derivation was found. Excluded until one is supplied.
6. **"Polarisation is a nonzero $H^1$ class"** ([DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/), §6 ii). Corrected in Section 13.3.
7. **"Γ → 1 ⟺ $H^1$ → 0"** ([DRK-189](https://draken.info/posts/the-carrier-and-the-cargo/)). Γ is a property of data and $H^1$ a property of the sheaf. Neither implies the other (Principle 2.7).
