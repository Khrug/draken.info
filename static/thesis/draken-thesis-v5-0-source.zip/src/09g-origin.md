## Appendix G — Origin of Numbered Results

Of the 45 numbered results, **23** are standard results reproved or restated in this notation, **13** are elementary consequences stated here for use (short, and plausibly folklore), and **9** are original to this monograph. *Original* means the statement, read as a statement about coherence measurement, was not found in the cited literature. Most original results are mathematically elementary; their contribution is what they forbid or permit, not proof technique **[D]**.

| Result | Name | Origin | Source or basis |
|---|---|---|---|
| Proposition 2.3 | Stalks of a cellular sheaf | Standard | Curry 2014 |
| Lemma 2.5 | $\delta\delta=0$ | Standard | Curry 2014 |
| Theorem 3.1 | Hodge decomposition | Standard | Hansen & Ghrist 2019; Lim 2020 |
| Proposition 3.2 | Energy identity; least squares | Standard | Lim 2020 |
| Proposition 3.3 |  | Standard | Lim 2020 |
| Proposition 3.4 | Curvature determines the curl | Standard | linear algebra |
| Proposition 3.6 | Periods | Standard | Hatcher 2002 |
| Proposition 3.7 | Face filling reclassifies obstruction | Original | reading of Lim 2020 decomposition |
| Theorem 3.10 | Long exact sequence | Standard | Weibel 1994 |
| Proposition 3.11 | Lifting is integration | Original | uses Weibel 1994 |
| Proposition 4.1 | Ring residual | Elementary | — |
| Proposition 4.2 | U(1) ring | Standard | circulant spectra |
| Proposition 4.3 | Order parameter | Elementary | — |
| Proposition 4.4 | Balance | Standard | Harary 1953; Altafini 2013 |
| Proposition 5.2 | Repair-cost form | Standard | Shuman et al. 2013 |
| Proposition 5.3 |  | Elementary | — |
| Proposition 5.4 |  | Elementary | — |
| Proposition 5.5 |  | Elementary | — |
| Proposition 5.6 | Monotonicity in the relations | Standard | Loewner order |
| Proposition 5.7 | Global-section inflation | Elementary | — |
| Proposition 5.8 | Blindness to coherent error | Original | — |
| Proposition 5.9 | Gradient and error propagation | Elementary | — |
| Proposition 5.10 | Noise bias and its correction | Standard | standard |
| Proposition 5.11 | Counting versus energy | Elementary | — |
| Proposition 5.12 | Bayesian and score form | Standard | Rue & Held 2005; Efron 2011 |
| Lemma 6.1 |  | Original | — |
| Proposition 7.2 |  | Elementary | — |
| Proposition 8.3 |  | Elementary | — |
| Proposition 9.1 | Spectral soundness | Original | closes DRK-190 §9 gap |
| Proposition 11.1 | Discrete Berry phase is sheaf holonomy | Standard | Resta 2000 |
| Theorem 15.1 | Convergence | Standard | Hansen & Ghrist 2021 |
| Proposition 15.2 | Forced diffusion | Standard | standard |
| Theorem 15.3 | Irreducible residual | Elementary | — |
| Proposition 15.4 |  | Standard | OU process |
| Proposition 15.5 |  | Standard | OU process; Song et al. 2021 |
| Proposition 16.1 | Circulation moves without accumulating | Standard | Jiang et al. 2011 |
| Proposition 16.3 | Lindeman sheaf | Elementary | — |
| Proposition 16.4 | Trophic level as a Leontief solution | Standard | Levine 1980; Hawkins & Simon 1949 |
| Proposition 16.5 | Repair converges to the idempotent | Elementary | — |
| Proposition 18.1 | Noise floors | Standard | Gaussian projection |
| Proposition 18.2 | Too good to be true | Original | uses Prop. 5.10 |
| Theorem 19.2 | Anti-totalisation | Original | math: Loewner order |
| Corollary 19.5 | Inversion filter, computable | Original | — |
| Proposition 19.6 | Rayleigh monotonicity; compliance | Standard | Doyle & Snell 1984 |
| Corollary 19.7 | Anchored admissibility | Original | — |
