Site rendering of the thesis for draken.info.
static/ mirrors the site repository paths; build-js-thesis-v5.patch updates the /thesis/ page (download buttons, copies static/thesis/).
Regenerate with tools/build_site.py.
