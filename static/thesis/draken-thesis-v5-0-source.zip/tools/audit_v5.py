import re, json, sys, glob
base = sys.argv[1]
files = sorted(glob.glob(f'{base}/src/0*.md'))
text = '\n'.join(open(f, encoding='utf-8').read() for f in files)
body = '\n'.join(open(f, encoding='utf-8').read() for f in files if not re.search(r'09b|09e|10-ref', f))
res = {}
res['numbered_results'] = {k: len(set(re.findall(r'\*\*%s (\d+\.\d+[a-z]?)' % k, body))) for k in
                           ['Theorem', 'Proposition', 'Lemma', 'Corollary', 'Definition', 'Hypothesis', 'Axiom', 'Norm']}
res['results_with_proof_or_citation'] = sum(res['numbered_results'][k] for k in ['Theorem','Proposition','Lemma','Corollary'])
res['proofs'] = body.count('*Proof')
# claim paragraphs
paras = re.split(r'\n\s*\n', body)
TAG = re.compile(r'\*\*\[(E|S|H|D|M)(/[A-Z])?\]\*\*')
claims, tagged, untagged, statements = 0, 0, [], 0
for p in paras:
    s = p.strip()
    if not s or s.startswith(('#', '|', '!', '$$', '<', '---', '>', '*Proof', '```')): continue
    if re.match(r'^(\d+\.|-|\(\w+\)) ', s) and not TAG.search(s): continue  # list items w/o claims
    if len(s.split()) < 25: continue
    if s.rstrip().endswith(':'): continue  # lead-in to a list or display
    if re.match(r'^\*\*(Theorem|Proposition|Lemma|Corollary|Definition|Principle|Axiom|Norm|Normative|Remark|Reporting)', s):
        statements += 1; continue  # result statements: tag carried by the proof / closing line
    claims += 1
    if TAG.search(s): tagged += 1
    else: untagged.append(s[:140].replace('\n', ' '))
res['result_statement_paragraphs'] = statements; res['claim_paragraphs'] = claims; res['claim_paragraphs_tagged'] = tagged
res['tag_share'] = round(tagged / claims, 3) if claims else None
# DRK links
idx = json.load(open(f'{base}/data/drk-index.json'))
slugs = {p['slug']: p['drk'] for p in idx['posts']}
links = re.findall(r'https://draken\.info/posts/([a-z0-9\-]+)/\)\s*\((DRK-\d+)', text)
bad = [(s, d) for s, d in links if slugs.get(s) != d]
res['drk_links'] = len(links); res['drk_links_bad'] = bad
res['distinct_posts_linked_in_body'] = len(json.load(open(f'{base}/data/linkmap.json')))
res['drk134_only_as_reserved'] = all('reserved' in text[max(0,m.start()-200):m.end()+60] for m in re.finditer('DRK-134', text))
res['nonexistent_drk_mentions'] = sorted({m for m in re.findall(r'DRK-\d+', body) if m not in set(slugs.values()) and m != 'DRK-134'})
res['untagged_samples'] = untagged
json.dump(res, sys.stdout, indent=1, ensure_ascii=False)
