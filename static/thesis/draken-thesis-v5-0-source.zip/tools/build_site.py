import re, html, subprocess, sys
subprocess.run(['pandoc','site.md','-f','markdown+tex_math_dollars','-t','html5','--mathjax','--wrap=none','--toc','--toc-depth=2',
                '--template=site_tpl.html','--section-divs','--metadata','title=Draken thesis','-o','thesis_frag.html'],check=True)
s=open('thesis_frag.html',encoding='utf-8').read()
def fix(t): return html.unescape(t).replace('<','\\lt ').replace('&','\\&')
s=re.sub(r'<span class="math inline">\\\((.*?)\\\)</span>',lambda m:'$'+fix(m.group(1))+'$',s,flags=re.S)
s=re.sub(r'<span class="math display">\\\[(.*?)\\\]</span>',lambda m:'$$'+fix(m.group(1))+'$$',s,flags=re.S)
style=open('site_style.css').read()
open('thesis_frag.html','w',encoding='utf-8').write('<style>\n'+style+'</style>\n'+s)
print('remaining spans:', s.count('class="math'), 'display:', s.count('$$')//2, 'bytes:', len(s.encode()))
