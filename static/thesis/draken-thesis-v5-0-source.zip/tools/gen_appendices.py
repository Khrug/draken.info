import json, re, sys
base = sys.argv[1]
ko = json.load(open(f'{base}/ko.json'))
idx = json.load(open(f'{base}/drk-index.json'))
slug = {p['drk']: p['slug'] for p in idx['posts']}
title = {p['drk']: p['title'] for p in idx['posts']}
use = {  # where each KO is used in the v5.0 argument
 'gamma':'Ch. 5','psi':'Ch. 6','kt':'Ch. 7','kappa':'Ch. 3, 9','rho':'Ch. 2','h1':'Ch. 2–3',
 'care':'Ch. 2, 7','theta':'Ch. 7','optimization-axiom':'Ch. 2, 19','manufactured-void':'Ch. 18–19',
 'cavity-ai':'Glossary only (companion volume)','inversion-filter':'Ch. 18–19','abstraction-depth':'Ch. 8',
 'clinch':'Ch. 16, 20','kayfabe':'Ch. 6, 18','survivable-glitch':'Glossary only (companion volume)',
 'source-laundering':'Ch. 18','carrier':'Ch. 13','cargo':'Ch. 13','chaxu-geju':'Glossary only (companion volume)',
 'sheaf-laplacian':'Ch. 3','global-section':'Ch. 2','drk131-protocol':'Ch. 22','keeper-function':'Glossary only (companion volume)',
 'sigma-sync':'Ch. 6','warded-invariant':'Ch. 9','egregore':'Ch. 6','stalk':'Ch. 2','stalking':'Glossary only (companion volume)',
 'earth-engine':'Ch. 16','conviction-gate':'Ch. 17','gate-capture':'Ch. 17–18'}
out = ['## Appendix B — Glossary of Knowledge Objects', '',
 f"All {ko['summary']['total']} Knowledge Objects in the registry (`data/ko.json`, generated {ko['generated'][:10]}) are approved. "
 "Each definition below is quoted verbatim from its defining post, in the post's language. Where a definition ends in a colon, the defining formula follows in the source. "
 "The last field gives where the KO is used in this monograph. "
 "Registry gap: *anti-totalisation* appears in 37 posts but has no KO. Chapter 19 supplies its formal content, and a defining post is needed before it can be registered.", '']
for o in ko['kos']:
    d = o['defined_in']; drk = d['drk']
    link = f"[{title.get(drk, drk)}](https://draken.info/posts/{slug.get(drk, d.get('slug',''))}/)"
    al = ', '.join('`'+a+'`' if '\\' in a else a for a in o.get('aliases', [])[:6])
    deff = ' '.join(o['definition'].split()).replace('= $ ', '=$ ')
    out.append(f"**{o['name']}**" + (f" — *aliases:* {al}" if al else ''))
    out.append('')
    out.append(f"> {deff}")
    out.append('')
    out.append(f"*Defined in* {link} ({drk}, {d.get('section') or 'opening'}). *Status:* {o['status']}. *Used in v5.0:* {use.get(o['id'],'—')}.")
    out.append('')
open(f'{base}/../src/09b-glossary.md', 'w').write('\n'.join(out) + '\n')

# Appendix E -- corpus disposition
core = {101:'21',105:'5–6',108:'8, 16',110:'18',117:'2, 18',118:'16',119:'18',121:'7',123:'14',125:'9, 19',130:'7, 16',
 131:'5',132:'21',133:'6, 18',136:'7',141:'2, 7, 14, 18',143:'11, 22',144:'5',145:'2–3',146:'20',149:'14',153:'14',
 156:'14',157:'5, 17',158:'19',162:'2, 7',165:'18',166:'14 (excluded claim)',167:'20',168:'10',169:'17',170:'5, 17',
 171:'4, 10',172:'11',175:'3, 9',176:'3, 6–7, 9',177:'6',181:'7, 14',185:'5, 14',186:'16',187:'3',188:'16',189:'4–5, 13, 20',
 190:'9, 12',191:'6',192:'2',193:'7, 15–16',194:'17',195:'17–18'}
gloss = {138:'Glossary (survivable glitch)',150:'Glossary (keeper-function)',120:'Glossary (cavity resonator)',110:'Glossary (manufactured void)'}
rows = []
linkmap = json.load(open(f'{base}/linkmap.json'))
counts = {'Argument':0,'Glossary':0,'Companion volume':0}
for p in idx['posts']:
    n = int(p['drk'][4:])
    if p['drk'] in linkmap: disp, where = 'Argument', 'Ch. ' + ', '.join(c for c in linkmap[p['drk']] if c!='Front') ; counts['Argument']+=1
    elif n in gloss: disp, where = 'Glossary', gloss[n]; counts['Glossary']+=1
    else: disp, where = 'Companion volume', '—'; counts['Companion volume']+=1
    t = p['title'].replace('|','/')
    rows.append(f"| {p['drk']} | [{t}](https://draken.info/posts/{p['slug']}/) | {disp} | {where} |")
out = ['## Appendix E — Corpus Disposition', '',
 f"All {len(idx['posts'])} published posts (`data/drk-index.json`, generated {idx['generated'][:10]}; next free {idx['next_free']}; DRK-134 reserved). "
 f"Disposition: **{counts['Argument']}** enter the argument, **{counts['Glossary']}** enter through the glossary only, and **{counts['Companion volume']}** are assigned to the companion volume *Draken Essays*. "
 "Assignment to the companion volume is a judgement of load-bearing role in a mathematical monograph, not of quality. No post is removed from the corpus (§19.6).", '',
 '| DRK | Title | Disposition | Where |', '|---|---|---|---|'] + rows
open(f'{base}/../src/09e-corpus.md', 'w').write('\n'.join(out) + '\n')
print(counts)
