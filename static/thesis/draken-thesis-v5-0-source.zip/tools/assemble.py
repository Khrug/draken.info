import re
ap=open('src/09-appendices.md',encoding='utf-8').read()
secs=re.split(r'(?=^## Appendix )',ap,flags=re.M)
head=secs[0]; d={re.match(r'## Appendix (\w)',s).group(1):s for s in secs[1:]}
B=open('src/09b-glossary.md',encoding='utf-8').read(); E=open('src/09e-corpus.md',encoding='utf-8').read(); G=open('src/09g-origin.md',encoding='utf-8').read()
files=['00-front','01-part1a','02-part1b','03-part2a','04-part2b','05-part3','06-part4','07-part5','08-part6']
body='\n\n'.join(open(f'src/{f}.md',encoding='utf-8').read() for f in files)
full=body+'\n\n'+'\n\n'.join([head,d['A'],B,d['C'],d['D'],E,d['F'],G])+'\n\n'+open('src/10-references.md',encoding='utf-8').read()
open('draken-thesis-v5-0.md','w',encoding='utf-8').write(full)
open('build.md','w',encoding='utf-8').write(full.replace('\\varinjlim','\\operatorname{colim}'))
lt=re.sub(r'([\u3000-\u9fff]+)',r'`\\cjk{\1}`{=latex}',full).replace('∎','$\\blacksquare$').replace('ℓ','$\\ell$').replace('✓','`{\\fontspec{DejaVu Sans}✓}`{=latex}').replace('𝔚','$\\mathfrak W$')
open('latex.md','w',encoding='utf-8').write(lt)
