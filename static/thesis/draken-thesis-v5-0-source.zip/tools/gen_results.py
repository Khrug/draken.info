import re
full=open('draken-thesis-v5-0.md',encoding='utf-8').read()
items=sorted(set(re.findall(r'\*\*((Theorem|Proposition|Lemma|Corollary) (\d+)\.(\d+)[a-z]?)( \(([^*]*?)\))?\.?\*\*',full)),key=lambda t:(int(t[2]),int(t[3])))
O={'3.7','3.11','5.8','6.1','9.1','18.2','19.2','19.5','19.7'}
E={'4.1','4.3','5.3','5.4','5.5','5.7','5.9','5.11','7.2','8.3','15.3','16.3','16.5'}
src={'2.3':'Curry 2014','2.5':'Curry 2014','3.1':'Hansen & Ghrist 2019; Lim 2020','3.2':'Lim 2020','3.3':'Lim 2020','3.4':'linear algebra','3.6':'Hatcher 2002','3.10':'Weibel 1994','4.2':'circulant spectra','4.4':'Harary 1953; Altafini 2013','5.2':'Shuman et al. 2013','5.6':'Loewner order','5.10':'standard','5.12':'Rue & Held 2005; Efron 2011','11.1':'Resta 2000','15.1':'Hansen & Ghrist 2021','15.2':'standard','15.4':'OU process','15.5':'OU process; Song et al. 2021','16.1':'Jiang et al. 2011','16.4':'Levine 1980; Hawkins & Simon 1949','18.1':'Gaussian projection','19.6':'Doyle & Snell 1984',
     '3.7':'reading of Lim 2020 decomposition','3.11':'uses Weibel 1994','5.8':'—','6.1':'—','9.1':'closes DRK-190 §9 gap','18.2':'uses Prop. 5.10','19.2':'math: Loewner order','19.5':'—','19.7':'—'}
rows=[]; cnt={'Original':0,'Elementary':0,'Standard':0}
for t in items:
    n=f"{t[2]}.{t[3]}"; kind='Original' if n in O else 'Elementary' if n in E else 'Standard'
    cnt[kind]+=1
    rows.append(f"| {t[1]} {n} | {t[5] or ''} | {kind} | {src.get(n,'—' if kind!='Standard' else 'standard')} |")
out=["## Appendix G — Origin of Numbered Results","",
f"Of the {len(items)} numbered results, **{cnt['Standard']}** are standard results reproved or restated in this notation, **{cnt['Elementary']}** are elementary consequences stated here for use (short, and plausibly folklore), and **{cnt['Original']}** are original to this monograph. *Original* means the statement, read as a statement about coherence measurement, was not found in the cited literature. Most original results are mathematically elementary; their contribution is what they forbid or permit, not proof technique **[D]**.","",
"| Result | Name | Origin | Source or basis |","|---|---|---|---|"]+rows
open('src/09g-origin.md','w',encoding='utf-8').write('\n'.join(out)+'\n')
print(cnt)
