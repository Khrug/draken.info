#!/usr/bin/env python3
"""
Draken Thesis v5.0 -- reproducibility script.

Recomputes every number in the worked examples (Ch. 4), the estimator
propositions (Ch. 5) and the figures. Deterministic (fixed seeds).
Requires: numpy, scipy, matplotlib.   Run:  python3 draken_v5_examples.py
CC BY-SA 4.0 -- Khrug Engineering / draken.info
"""
import json, sys, os
import numpy as np
from numpy.linalg import norm, eigvalsh, pinv, matrix_rank
from scipy.linalg import null_space

OUT = {}
TOL = 1e-10

# ---------------------------------------------------------------------------
# 1. Cellular sheaves on a 2-complex (finite, real or complex stalks)
# ---------------------------------------------------------------------------
class CellSheaf:
    """Cellular sheaf on a finite 2-complex.
    vertices: list of names; edges: list of (tail, head); faces: list of
    lists of (edge_index, sign) giving the oriented boundary of each face.
    dv, de, df: stalk dimensions.  Restriction maps:
      Fve[(v, e)] : de x dv matrix ;  Fef[(e, f)] : df x de matrix.
    Default restriction maps: identity (constant sheaf)."""
    def __init__(self, vertices, edges, faces=(), d=1, Fve=None, Fef=None,
                 dtype=float):
        self.V, self.E, self.Fc = list(vertices), list(edges), list(faces)
        self.d = d
        self.vi = {v: i for i, v in enumerate(self.V)}
        self.Fve = Fve or {}
        self.Fef = Fef or {}
        self.dtype = dtype

    def _I(self):
        return np.eye(self.d, dtype=self.dtype)

    def delta0(self):
        d, nV, nE = self.d, len(self.V), len(self.E)
        D = np.zeros((nE * d, nV * d), dtype=self.dtype)
        for k, (u, v) in enumerate(self.E):
            iu, iv = self.vi[u], self.vi[v]
            D[k*d:(k+1)*d, iv*d:(iv+1)*d] += self.Fve.get((v, k), self._I())
            D[k*d:(k+1)*d, iu*d:(iu+1)*d] -= self.Fve.get((u, k), self._I())
        return D

    def delta1(self):
        d, nE, nF = self.d, len(self.E), len(self.Fc)
        D = np.zeros((nF * d, nE * d), dtype=self.dtype)
        for f, bnd in enumerate(self.Fc):
            for (k, s) in bnd:
                D[f*d:(f+1)*d, k*d:(k+1)*d] += s * self.Fef.get((k, f), self._I())
        return D

    def laplacian0(self):
        D0 = self.delta0()
        return D0.conj().T @ D0

def proj_onto_range(A):
    """Orthogonal projector onto range(A)."""
    if A.size == 0:
        return None
    return A @ pinv(A)

def hodge_decompose(sheaf, omega):
    """omega in C^1. Returns (gradient part, harmonic part, curl part, x*)."""
    D0, D1 = sheaf.delta0(), sheaf.delta1()
    xstar = pinv(D0) @ omega
    grad = D0 @ xstar
    if D1.shape[0] > 0:
        curl = D1.conj().T @ (pinv(D1.conj().T) @ omega)
    else:
        curl = np.zeros_like(omega)
    harm = omega - grad - curl
    return grad, harm, curl, xstar

def cohomology_dims(sheaf):
    D0, D1 = sheaf.delta0(), sheaf.delta1()
    n0, n1 = D0.shape[1], D0.shape[0]
    r0 = matrix_rank(D0, tol=1e-9)
    r1 = matrix_rank(D1, tol=1e-9) if D1.shape[0] else 0
    # check delta1 delta0 = 0
    if D1.shape[0]:
        assert norm(D1 @ D0) < 1e-9, "delta1 delta0 != 0"
    return n0 - r0, (n1 - r1) - r0   # dim H0, dim H1

# ---------------------------------------------------------------------------
# 2. Coherence measures (Ch. 5)
# ---------------------------------------------------------------------------
def measures(L, x, tau=None):
    x = np.asarray(x, dtype=float)
    n = len(x)
    lam = eigvalsh(L)
    lam_max = lam[-1]
    pos = lam[lam > 1e-9]
    lam1p = pos[0] if len(pos) else np.nan
    if tau is None:
        tau = n / np.trace(L)          # tau* = 1 / mean eigenvalue
    E = float(x @ L @ x)
    nx2 = float(x @ x)
    R = E / nx2
    K = null_space(L, rcond=1e-9)
    P = K @ K.T if K.size else np.zeros((n, n))
    G0 = float(x @ P @ x) / nx2
    Gt = float(x @ np.linalg.solve(np.eye(n) + tau * L, x)) / nx2
    return dict(E=E, norm2=nx2, R=R, lam_max=lam_max, lam1p=lam1p,
                tau=tau, Gamma_v44=1 - R, Gamma_R=1 - R / lam_max,
                Gamma_0=G0, Gamma_tau=Gt,
                lower_jensen=1 / (1 + tau * R),
                upper=G0 + (1 - G0) / (1 + tau * lam1p))

def rnd(d, k=4):
    return {a: (round(float(b), k) if isinstance(b, (float, np.floating)) else b)
            for a, b in d.items()}

# ---------------------------------------------------------------------------
# Example 4.1  Institutional sheaf (v4.4 data, corrected)
# ---------------------------------------------------------------------------
def example_institutional():
    V = ['F', 'E', 'H', 'X', 'C']
    Ed = [('X', 'F'), ('X', 'E'), ('X', 'H'), ('E', 'C'), ('F', 'H')]
    S = CellSheaf(V, Ed, d=2)
    x = np.array([0.8, 0.3, 0.4, 0.7, 0.2, 0.2, 0.9, 0.8, 0.3, 0.4])
    L = S.laplacian0()
    m = measures(L, x)
    D0 = S.delta0()
    per_edge = [(f"{u}-{v}", round(float(norm((D0 @ x)[2*k:2*k+2])**2), 4))
                for k, (u, v) in enumerate(Ed)]
    h0, h1 = cohomology_dims(S)
    m.update(per_edge=per_edge, dimH0=h0, dimH1=h1,
             spectrum=[round(float(l), 4) for l in eigvalsh(L)],
             relax_time=round(1 / m['lam1p'], 3))
    # sensitivity: gradient of Gamma_tau wrt x (Prop 5.9)
    n = len(x); tau = m['tau']
    M = np.linalg.inv(np.eye(n) + tau * L)
    g = 2 * (M @ x - m['Gamma_tau'] * x) / (x @ x)
    node_sens = {V[i]: round(float(norm(g[2*i:2*i+2])), 4) for i in range(5)}
    m['node_sensitivity'] = node_sens
    OUT['ex41_institutional'] = rnd(m)
    # same data measured against the declared reference x_ref = 0.5 (scale midpoint)
    mc = measures(L, x - 0.5, tau=m['tau'])
    OUT['ex41_institutional_centred'] = rnd(mc)
    return S, x

# ---------------------------------------------------------------------------
# Example 4.2  Trophic chain (v4.4 data, corrected normalisation)
# ---------------------------------------------------------------------------
def example_trophic():
    V = ['W', 'E', 'P', 'R']
    Ed = [('W', 'E'), ('E', 'P'), ('P', 'R')]
    S = CellSheaf(V, Ed, d=2)
    L = S.laplacian0()
    states = {
        'pre_1920':      [0.8, 0.7, 0.5, 0.6, 0.7, 0.8, 0.8, 0.9],
        'post_1990':     [0.0, 0.0, 0.9, 0.2, 0.1, 0.1, 0.3, 0.2],
        'restored_2020': [0.6, 0.7, 0.5, 0.5, 0.5, 0.6, 0.6, 0.7],
    }
    res = {}
    tau = 8 / np.trace(L)
    for k, x in states.items():
        res[k] = rnd(measures(L, np.array(x), tau=tau))
    OUT['ex42_trophic'] = res
    return S, L, states

# ---------------------------------------------------------------------------
# Example 4.3  Clock ring: holonomy, residual Phi^2/N, magnetic Laplacian
# ---------------------------------------------------------------------------
def example_clock_ring(N=6, Phi=0.6, seed=1):
    rng = np.random.default_rng(seed)
    V = list(range(N))
    Ed = [(i, (i + 1) % N) for i in range(N)]
    S = CellSheaf(V, Ed, d=1)
    D0 = S.delta0()
    t_true = rng.normal(size=N)                  # true clock offsets
    omega = D0 @ t_true + Phi / N                # measured offsets + holonomy
    grad, harm, curl, xs = hodge_decompose(S, omega)
    hol = float(np.sum(omega))                   # oriented sum around ring
    E_res = float(norm(harm)**2 + norm(curl)**2)
    # same ring with the face filled
    Sf = CellSheaf(V, Ed, faces=[[(k, +1) for k in range(N)]], d=1)
    g2, h2, c2, _ = hodge_decompose(Sf, omega)
    # magnetic (U(1)) Laplacian on the ring: transport e^{i phi/N} per edge
    def mag_eigs(phi):
        Lm = np.zeros((N, N), dtype=complex)
        for i in range(N):
            j = (i + 1) % N
            Lm[i, i] += 1; Lm[j, j] += 1
            Lm[j, i] -= np.exp(1j * phi / N); Lm[i, j] -= np.exp(-1j * phi / N)
        return np.sort(np.linalg.eigvalsh(Lm))
    phi = 1.0
    ev = mag_eigs(phi)
    closed = sorted(2 - 2*np.cos((2*np.pi*k + phi) / N) for k in range(N))
    OUT['ex43_clock_ring'] = dict(
        N=N, Phi=Phi, holonomy=round(hol, 6),
        E_grad=round(float(norm(grad)**2), 6),
        E_harm_unfilled=round(float(norm(harm)**2), 6),
        E_curl_unfilled=round(float(norm(curl)**2), 6),
        Phi2_over_N=round(Phi**2 / N, 6),
        filled_E_harm=round(float(norm(h2)**2), 6),
        filled_E_curl=round(float(norm(c2)**2), 6),
        magnetic_phi=phi,
        magnetic_eigs=[round(float(e), 6) for e in ev],
        magnetic_closed_form=[round(float(e), 6) for e in closed],
        Gamma_R_max=round(float(1 - ev[0] / ev[-1]), 6),
        dimH0_U1=int(np.sum(ev < 1e-9)))
    return mag_eigs

# ---------------------------------------------------------------------------
# Example 4.4  Exchange-rate complex: gradient / harmonic / curl
# ---------------------------------------------------------------------------
def example_exchange():
    V = ['A', 'B', 'C', 'D']
    Ed = [('A', 'B'), ('B', 'C'), ('C', 'A'), ('C', 'D'), ('D', 'A')]
    face_ABC = [(0, +1), (1, +1), (2, +1)]
    S = CellSheaf(V, Ed, faces=[face_ABC], d=1)
    D0 = S.delta0()
    p = np.array([0.0, 0.10, -0.05, 0.20])          # log 'true' prices
    omega = D0 @ p
    omega = omega + np.array([0.03, 0, 0, 0, 0])         # arbitrage on A->B
    omega = omega + np.array([0, 0, 0, 0.015, 0.015])    # drift on loop A->C->D->A
    grad, harm, curl, xs = hodge_decompose(S, omega)
    h0, h1 = cohomology_dims(S)
    F = S.delta1() @ omega
    OUT['ex44_exchange'] = dict(
        omega=[round(float(w), 4) for w in omega],
        grad=[round(float(w), 4) for w in grad],
        harm=[round(float(w), 4) for w in harm],
        curl=[round(float(w), 4) for w in curl],
        curvature_ABC=round(float(F[0]), 4),
        holonomy_ACD=round(float(-omega[2] + omega[3] + omega[4]), 4),
        E_total=round(float(norm(omega)**2), 6),
        E_grad=round(float(norm(grad)**2), 6),
        E_harm=round(float(norm(harm)**2), 6),
        E_curl=round(float(norm(curl)**2), 6),
        E_curl_formula=round(float(F @ pinv(S.delta1() @ S.delta1().T) @ F), 6),
        Gamma1=round(float(norm(grad)**2 / norm(omega)**2), 4),
        dimH0=h0, dimH1=h1)
    return S, omega, grad, harm, curl

# ---------------------------------------------------------------------------
# Example 4.5  Toric code over F2
# ---------------------------------------------------------------------------
def gf2_rank(M):
    M = M.copy() % 2
    r = 0
    rows, cols = M.shape
    for c in range(cols):
        piv = None
        for i in range(r, rows):
            if M[i, c]:
                piv = i; break
        if piv is None:
            continue
        M[[r, piv]] = M[[piv, r]]
        for i in range(rows):
            if i != r and M[i, c]:
                M[i] ^= M[r]
        r += 1
        if r == rows:
            break
    return r

def example_toric(L=3):
    def v(i, j): return (i % L) * L + (j % L)
    nV, nE, nF = L*L, 2*L*L, L*L
    def eh(i, j): return (i % L) * L + (j % L)            # (i,j)->(i,j+1)
    def ev_(i, j): return L*L + (i % L) * L + (j % L)      # (i,j)->(i+1,j)
    d1 = np.zeros((nV, nE), dtype=np.uint8)   # boundary edges -> vertices
    for i in range(L):
        for j in range(L):
            d1[v(i, j), eh(i, j)] ^= 1; d1[v(i, j+1), eh(i, j)] ^= 1
            d1[v(i, j), ev_(i, j)] ^= 1; d1[v(i+1, j), ev_(i, j)] ^= 1
    d2 = np.zeros((nE, nF), dtype=np.uint8)   # boundary faces -> edges
    for i in range(L):
        for j in range(L):
            f = i * L + j
            for e in (eh(i, j), eh(i+1, j), ev_(i, j), ev_(i, j+1)):
                d2[e, f] ^= 1
    assert not ((d1.astype(int) @ d2.astype(int)) % 2).any()
    r1, r2 = gf2_rank(d1), gf2_rank(d2)
    k = nE - r1 - r2
    OUT[f'ex45_toric_L{L}'] = dict(L=L, n=nE, rank_d1=r1, rank_d2=r2, k=k,
                             euler=nV - nE + nF, distance_formula=L)
    return k

# ---------------------------------------------------------------------------
# Example 4.6  Kuramoto: Gamma_infinity = r^2 (Prop 4.6)
# ---------------------------------------------------------------------------
def example_kuramoto(N=40, K=1.5, T=30.0, dt=0.01, seed=3, ring=False):
    rng = np.random.default_rng(seed)
    w = rng.standard_cauchy(N) * 0.3
    th = rng.uniform(0, 2*np.pi, N)
    if ring:
        A = np.zeros((N, N))
        for i in range(N):
            for s in (1, 2):
                A[i, (i+s) % N] = A[(i+s) % N, i] = 1
    else:
        A = np.ones((N, N)) - np.eye(N)
    Lg = np.diag(A.sum(1)) - A
    rs, g0s, gts = [], [], []
    steps = int(T / dt)
    lam = eigvalsh(Lg)
    tau = N / np.trace(Lg)
    Minv = np.linalg.inv(np.eye(N) + tau * Lg)
    for s in range(steps):
        diff = th[None, :] - th[:, None]
        th = th + dt * (w + (K / N) * (A * np.sin(diff)).sum(1))
        if s % 10 == 0:
            z = np.exp(1j * th)
            r = abs(z.mean())
            P = np.ones((N, N)) / N
            g0 = float(np.real(z.conj() @ P @ z) / N)
            gt = float(np.real(z.conj() @ Minv @ z) / N)
            rs.append(r); g0s.append(g0); gts.append(gt)
    rs, g0s, gts = map(np.array, (rs, g0s, gts))
    OUT['ex46_kuramoto' + ('_ring' if ring else '')] = dict(
        N=N, K=K, max_abs_r2_minus_Gamma0=float(np.max(abs(rs**2 - g0s))),
        final_r=round(float(rs[-1]), 4), final_Gamma_tau=round(float(gts[-1]), 4),
        lam_max=round(float(lam[-1]), 4))
    return rs, g0s, gts

# ---------------------------------------------------------------------------
# Example 4.7  Signed triangle: structural balance as holonomy
# ---------------------------------------------------------------------------
def example_signed():
    out = {}
    for name, signs in (('balanced(+,-,-)', (1, -1, -1)),
                        ('unbalanced(+,+,-)', (1, 1, -1))):
        V = [0, 1, 2]; Ed = [(0, 1), (1, 2), (2, 0)]
        Fve = {}
        for k, (u, vv) in enumerate(Ed):
            Fve[(vv, k)] = np.array([[signs[k]]], float)   # transport sign
        S = CellSheaf(V, Ed, d=1, Fve=Fve)
        L = S.laplacian0()
        ev = eigvalsh(L)
        out[name] = dict(sign_product=int(np.prod(signs)),
                         eigs=[round(float(e), 4) for e in ev],
                         dimH0=int(np.sum(ev < 1e-9)))
    OUT['ex47_signed'] = out

# ---------------------------------------------------------------------------
# Prop 5.10  Measurement noise bias of the Laplacian energy
# ---------------------------------------------------------------------------
def noise_bias(S, x, sigmas=(0.0, 0.05, 0.1, 0.2), reps=20000, seed=7):
    rng = np.random.default_rng(seed)
    L = S.laplacian0(); n = len(x)
    tau = n / np.trace(L)
    Minv = np.linalg.inv(np.eye(n) + tau * L)
    true_Gt = float(x @ Minv @ x / (x @ x))
    rows = []
    for s in sigmas:
        Y = x[None, :] + s * rng.normal(size=(reps, n))
        Es = np.einsum('ij,jk,ik->i', Y, L, Y)
        naive = np.einsum('ij,jk,ik->i', Y, Minv, Y) / np.einsum('ij,ij->i', Y, Y)
        num = np.einsum('ij,jk,ik->i', Y, Minv, Y) - s**2 * np.trace(Minv)
        den = np.einsum('ij,ij->i', Y, Y) - s**2 * n
        deb = num / den
        rows.append(dict(sigma=s,
                         mean_E=round(float(Es.mean()), 4),
                         predicted_E=round(float(x @ L @ x + s**2 * np.trace(L)), 4),
                         naive_Gamma_tau=round(float(naive.mean()), 4),
                         debiased_Gamma_tau=round(float(deb.mean()), 4),
                         true_Gamma_tau=round(true_Gt, 4)))
    OUT['prop_noise_bias'] = rows
    return rows

# ---------------------------------------------------------------------------
# Prop 19.2  Excision monotonicity (censorship raises Gamma_tau)
# ---------------------------------------------------------------------------
def excision_demo(S, x):
    order = [2, 4, 0, 1, 3]   # delete X-H, F-H, X-F, X-E, E-C
    n = len(x); tau = n / np.trace(S.laplacian0())
    seq = []
    E = list(S.E)
    for m in range(len(order) + 1):
        keep = [E[k] for k in range(len(E)) if k not in order[:m]]
        Sm = CellSheaf(S.V, keep, d=S.d)
        L = Sm.laplacian0() if keep else np.zeros((n, n))
        Gt = float(x @ np.linalg.solve(np.eye(n) + tau * L, x) / (x @ x))
        b0 = int(n - matrix_rank(L, tol=1e-9)) if keep else n
        b1 = len(keep) * S.d - (n - b0)          # graph: dim C1 - rank delta0
        f = np.zeros(n); f[2*S.vi['H']] = 1; f[2*S.vi['C']] = -1
        cpl = float(f @ np.linalg.solve(L + 1e-9 * np.eye(n), f))
        seq.append(dict(edges_deleted=m, Gamma_tau=round(Gt, 4), dimH0=b0, dimH1=b1,
                        compliance=(round(cpl, 4) if cpl < 1e6 else None)))
    OUT['prop_excision'] = seq
    return seq


# ---------------------------------------------------------------------------
# Example 4.8  Extension obstruction on the ring (Prop 3.10)
# ---------------------------------------------------------------------------
def example_extension(N=6, a=(0.10, 0.05, 0.0, 0.08, 0.02, 0.05)):
    """E = R^2 stalks; edge maps [[1,a_e],[0,1]] (head), I (tail).
    K = first coordinate (constant sheaf), Q = second coordinate (constant)."""
    V = list(range(N)); Ed = [(i, (i + 1) % N) for i in range(N)]
    Fve = {((i + 1) % N, i): np.array([[1.0, a[i]], [0.0, 1.0]]) for i in range(N)}
    S = CellSheaf(V, Ed, d=2, Fve=Fve)
    D0 = S.delta0()
    e = np.tile([0.0, 1.0], N)                 # stalkwise lift of the Q-section q = 1
    w = D0 @ e                                 # lies in i(C^1(K)): second coords zero
    assert np.allclose(w[1::2], 0)
    omega_q = w[0::2]
    K = CellSheaf(V, Ed, d=1)
    g, h, c, _ = hodge_decompose(K, omega_q)
    # best approximate lift: minimise ||delta_E (e - i k)||
    Ki = np.zeros((2 * N, N)); Ki[0::2, :] = np.eye(N)
    k = np.linalg.lstsq(D0 @ Ki, w, rcond=None)[0]
    resid = float(norm(D0 @ (e - Ki @ k)) ** 2)
    hol = float(np.sum(a))
    OUT['ex48_extension'] = dict(N=N, holonomy_sum_a=round(hol, 6),
        E_harm=round(float(norm(h) ** 2), 6), E_curl=round(float(norm(c) ** 2), 6),
        best_lift_residual=round(resid, 6), hol2_over_N=round(hol ** 2 / N, 6),
        dimH0_E=cohomology_dims(S)[0])

# ---------------------------------------------------------------------------
# Example 16.A  Lindeman sheaf and trophic levels (Prop 16.4)
# ---------------------------------------------------------------------------
def example_trophic_structure(eta=0.1):
    V = [1, 2, 3, 4]; Ed = [(1, 2), (2, 3), (3, 4)]
    Fve = {(u, k): np.array([[eta]]) for k, (u, v) in enumerate(Ed)}   # tail scaled by eta
    S = CellSheaf(V, Ed, d=1, Fve=Fve)
    L = S.laplacian0()
    K0 = null_space(L)
    prof = (K0[:, 0] / K0[0, 0])
    x = np.array([1000.0, 95.0, 11.0, 0.9])       # measured energy per level (arb. units)
    eff = [round(float(x[i+1] / x[i]), 4) for i in range(3)]
    z = x / eta ** np.arange(4)                    # declared geometry: Lindeman-normalised stalks
    Lc = CellSheaf(V, Ed, d=1).laplacian0()
    mz = measures(Lc, z / norm(z))
    mzc = measures(Lc, (z - z[0]) / norm(z - z[0]))
    # trophic levels: TL = 1 + D TL on consumers
    # species: 0 grass, 1 algae (producers); 2 grazer; 3 fish; 4 predator
    Dm = np.array([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0],
                   [0.7, 0.3, 0, 0, 0],
                   [0.2, 0.3, 0.5, 0, 0],
                   [0, 0, 0.4, 0.6, 0]])
    TL = np.linalg.solve(np.eye(5) - Dm, np.ones(5))
    sr = max(abs(np.linalg.eigvals(Dm)))
    OUT['ex16_trophic_structure'] = dict(eta=eta,
        H0_profile=[round(float(p), 6) for p in prof],
        observed_efficiencies=eff, normalised=[round(float(v), 1) for v in z],
        Gamma_tau_vs_reference=round(mzc['Gamma_tau'], 4), E_rel=round(mzc['E'], 4),
        trophic_levels=[round(float(t), 4) for t in TL], spectral_radius_D=round(float(sr), 4))

# ---------------------------------------------------------------------------
# Prop 19.6  Anchored dual: compliance / effective resistance rises under excision
# ---------------------------------------------------------------------------
def compliance_demo(S, eps=1e-9):
    order = [2, 4, 0, 1]
    n = len(S.V) * S.d  # load between H and C
    f = np.zeros(n); f[2*S.vi['H']:2*S.vi['H']+2] = [1, 0]; f[2*S.vi['C']:2*S.vi['C']+2] = [-1, 0]
    seq = []
    E = list(S.E)
    for m in range(len(order) + 1):
        keep = [E[k] for k in range(len(E)) if k not in order[:m]]
        Sm = CellSheaf(S.V, keep, d=S.d)
        L = Sm.laplacian0() if keep else np.zeros((n, n))
        cpl = float(f @ np.linalg.solve(L + eps * np.eye(n), f))
        seq.append(dict(edges_deleted=m, compliance=(round(cpl, 4) if cpl < 1e6 else 'inf (disconnected)')))
    OUT['prop_compliance'] = seq

# ---------------------------------------------------------------------------
# Prop 5.12  Gamma_tau repair map = posterior mean / Tweedie denoiser
# ---------------------------------------------------------------------------
def tweedie_check(S, x, tau=0.5):
    L = S.laplacian0(); n = len(x)
    R = np.linalg.solve(np.eye(n) + tau * L, x)
    w, U = np.linalg.eigh(L)
    # marginal covariance of observation on non-global modes: 1 + 1/(tau*lam)
    score = np.zeros(n)
    for k in range(n):
        if w[k] > 1e-9:
            score += -(U[:, k] @ x) / (1 + 1 / (tau * w[k])) * U[:, k]
    tw = x + score
    OUT['prop_tweedie'] = dict(max_abs_diff=float(np.max(abs(tw - R))))

# ---------------------------------------------------------------------------
# Prop 5.11  Agreement fraction bound
# ---------------------------------------------------------------------------
def agreement_bound(S, x, eps=0.8):
    D0 = S.delta0(); d = S.d
    per = np.array([norm((D0 @ x)[d*k:d*(k+1)]) for k in range(len(S.E))])
    sigma_eps = float(np.mean(per <= eps))
    bound = 1 - float(x @ S.laplacian0() @ x) / (len(S.E) * eps ** 2)
    OUT['prop_agreement'] = dict(eps=eps, sigma_eps=round(sigma_eps, 4), markov_lower_bound=round(bound, 4))

# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------
def figures(S_inst, x_inst, troph, mag_eigs, kur, kur_ring, noise, excis,
            exch, outdir):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family': 'DejaVu Serif', 'font.size': 10,
                         'axes.spines.top': False, 'axes.spines.right': False})
    os.makedirs(outdir, exist_ok=True)
    INK, ACC, ACC2, GREY = '#1f2a36', '#b5382f', '#2f6db5', '#8a8f96'

    # Fig 1: Hodge decomposition on the exchange complex
    S, omega, grad, harm, curl = exch
    pos = {'A': (0, 0), 'B': (1, 1.3), 'C': (2, 0), 'D': (1, -1.3)}
    fig, axs = plt.subplots(1, 4, figsize=(11, 3.1))
    for ax, vec, title in zip(axs, (omega, grad, harm, curl),
                              (r'$\omega$ (data)', r'$\delta^0 x^\star$ (gradient)',
                               r'$h$ (harmonic, $\varkappa$)',
                               r'$\delta^{1\top}y$ (curl)')):
        ax.fill([0, 1, 2], [0, 1.3, 0], color='#e9e4d8', zorder=0)
        for k, (u, v) in enumerate(S.E):
            (x0, y0), (x1, y1) = pos[u], pos[v]
            val = vec[k]
            col = ACC if val > 1e-6 else (ACC2 if val < -1e-6 else GREY)
            ax.annotate('', xy=(x1, y1), xytext=(x0, y0),
                        arrowprops=dict(arrowstyle='-|>', color=col,
                                        lw=0.8 + 3.5 * abs(val) / (max(abs(vec)) + 1e-12), shrinkA=8, shrinkB=8))
            ax.text((x0 + x1) / 2, (y0 + y1) / 2, f'{val:+.3f}', fontsize=7.5,
                    ha='center', va='center',
                    bbox=dict(fc='white', ec='none', pad=0.6))
        for n_, (px, py) in pos.items():
            ax.plot(px, py, 'o', ms=13, color=INK)
            ax.text(px, py, n_, color='white', ha='center', va='center',
                    fontsize=8, weight='bold')
        ax.set_title(title, fontsize=9.5); ax.axis('off')
        ax.set_xlim(-0.3, 2.3); ax.set_ylim(-1.6, 1.6)
    fig.suptitle('Hodge decomposition of relational data on a 2-complex '
                 '(face ABC filled, loop ACD open)', fontsize=10)
    fig.tight_layout(); fig.savefig(f'{outdir}/fig1_hodge.png', dpi=200); plt.close()

    # Fig 2: Gamma_tau vs tau for trophic states
    S_t, L_t, states = troph
    taus = np.logspace(-2, 3, 200)
    fig, ax = plt.subplots(figsize=(6.2, 3.6))
    for (k, x), c in zip(states.items(), (INK, ACC, ACC2)):
        x = np.array(x); n = len(x)
        g = [x @ np.linalg.solve(np.eye(n) + t * L_t, x) / (x @ x) for t in taus]
        ax.semilogx(taus, g, color=c, label=k.replace('_', ' '))
        m = measures(L_t, x)
        ax.axhline(m['Gamma_0'], color=c, ls=':', lw=0.8)
    ax.axvline(8 / np.trace(L_t), color=GREY, ls='--', lw=0.8)
    ax.text(8 / np.trace(L_t) * 1.1, 0.03, r'$\tau^\ast$', color=GREY)
    ax.set_xlabel(r'stiffness $\tau$'); ax.set_ylabel(r'$\Gamma_\tau(x)$')
    ax.set_ylim(0, 1.02); ax.legend(frameon=False, fontsize=8)
    ax.set_title(r'Resolvent coherence $\Gamma_\tau$; dotted: limit $\Gamma_0$',
                 fontsize=9.5)
    fig.tight_layout(); fig.savefig(f'{outdir}/fig2_gamma_tau.png', dpi=200); plt.close()

    # Fig 3: ring -- residual energy and magnetic spectrum
    N = 6
    fig, axs = plt.subplots(1, 2, figsize=(9, 3.4))
    Ph = np.linspace(-np.pi, np.pi, 300)
    axs[0].plot(Ph, Ph**2 / N, color=ACC)
    axs[0].set_xlabel(r'holonomy $\Phi$'); axs[0].set_ylabel(r'$\min_x\|\omega-\delta^0x\|^2$')
    axs[0].set_title(r'(a) irreducible residual $=\Phi^2/N$ (scalar ring, $N=6$)', fontsize=9)
    phis = np.linspace(0, 2*np.pi, 300)
    E = np.array([mag_eigs(p) for p in phis])
    for j in range(N):
        axs[1].plot(phis, E[:, j], color=INK if j else ACC, lw=1.4 if j == 0 else 0.8)
    axs[1].set_xlabel(r'flux $\phi$'); axs[1].set_ylabel('eigenvalues')
    axs[1].set_title(r'(b) U(1) ring: $\lambda_{\min}=2-2\cos(\phi/N)$', fontsize=9)
    fig.suptitle('Holonomy as irreducible incoherence', fontsize=10)
    fig.tight_layout(); fig.savefig(f'{outdir}/fig3_ring.png', dpi=200); plt.close()

    # Fig 4: Kuramoto r^2 = Gamma_0
    rs, g0s, gts = kur
    rr, rg0, rgt = kur_ring
    t = np.arange(len(rs)) * 0.1
    fig, ax = plt.subplots(figsize=(6.2, 3.4))
    ax.plot(t, rs**2, color=INK, lw=2.2, label=r'$r^2$ (complete graph)')
    ax.plot(t, g0s, color=ACC, ls='--', lw=1.2, label=r'$\Gamma_0$ (complete graph)')
    ax.plot(t, gts, color=ACC2, lw=1, label=r'$\Gamma_{\tau^\ast}$ (complete graph)')
    ax.plot(t, rr**2, color=GREY, lw=1, label=r'$r^2=\Gamma_0$ (ring, $k=2$)')
    ax.set_xlabel('time'); ax.set_ylim(0, 1.02)
    ax.legend(frameon=False, fontsize=8)
    ax.set_title(r'Kuramoto order parameter: $r^2\equiv\Gamma_0$ on any connected graph',
                 fontsize=9.5)
    fig.tight_layout(); fig.savefig(f'{outdir}/fig4_kuramoto.png', dpi=200); plt.close()

    # Fig 5: noise bias
    s = [r['sigma'] for r in noise]
    fig, ax = plt.subplots(figsize=(6.2, 3.3))
    ax.plot(s, [r['naive_Gamma_tau'] for r in noise], 'o-', color=ACC, label='naive')
    ax.plot(s, [r['debiased_Gamma_tau'] for r in noise], 's-', color=ACC2, label='debiased (Prop. 5.10)')
    ax.axhline(noise[0]['true_Gamma_tau'], color=INK, ls=':', label='true')
    ax.set_xlabel(r'measurement noise $\sigma$'); ax.set_ylabel(r'mean estimate of $\Gamma_{\tau^\ast}$')
    ax.legend(frameon=False, fontsize=8)
    ax.set_title('Noise biases coherence downward; the correction removes it',
                 fontsize=9.5)
    fig.tight_layout(); fig.savefig(f'{outdir}/fig5_noise.png', dpi=200); plt.close()

    # Fig 6: excision -- coherence, Betti numbers and compliance together
    fig, ax = plt.subplots(figsize=(7.4, 3.9))
    k = [r['edges_deleted'] for r in excis]
    ax.step(k, [r['Gamma_tau'] for r in excis], where='post', color=ACC, lw=1.6)
    ax.plot(k, [r['Gamma_tau'] for r in excis], 'o', color=ACC, label=r'$\Gamma_{\tau}$ (unanchored coherence)')
    ax.set_xlabel('relations deleted (data fixed: X–H, F–H, X–F, X–E, E–C)')
    ax.set_ylabel(r'$\Gamma_{\tau}$', color=ACC); ax.set_ylim(0.8, 1.01)
    for r in excis:
        ax.annotate(f"$b_0$={r['dimH0']}  $b_1$={r['dimH1']}", (r['edges_deleted'], r['Gamma_tau']),
                    textcoords='offset points', xytext=(-8, -16), fontsize=7.5, color=INK)
    ax2 = ax.twinx(); ax2.spines['right'].set_visible(True)
    cv = [r['compliance'] for r in excis]
    kk = [i for i, c in zip(k, cv) if c is not None]; cc = [c for c in cv if c is not None]
    ax2.plot(kk, cc, 's--', color=ACC2, label='compliance, load H→C (anchored)')
    first_inf = next(i for i, c in zip(k, cv) if c is None)
    ax2.annotate('∞ (load disconnected)', (first_inf, max(cc) * 1.05), color=ACC2, fontsize=8, ha='center')
    ax2.set_ylabel('compliance', color=ACC2); ax2.set_ylim(0, max(cc) * 1.3)
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, fontsize=8, loc='upper left')
    fig.tight_layout(); fig.savefig(f'{outdir}/fig6_excision.png', dpi=200); plt.close()


if __name__ == '__main__':
    outdir = sys.argv[1] if len(sys.argv) > 1 else 'figures'
    S_inst, x_inst = example_institutional()
    troph = example_trophic()
    mag = example_clock_ring()
    exch = example_exchange()
    example_toric(3); example_toric(4)
    kur = example_kuramoto()
    kur_ring = example_kuramoto(ring=True)
    example_signed()
    example_extension(); example_trophic_structure()
    compliance_demo(S_inst); tweedie_check(S_inst, x_inst); agreement_bound(S_inst, x_inst)
    noise = noise_bias(S_inst, x_inst)
    excis = excision_demo(S_inst, x_inst)
    figures(S_inst, x_inst, troph, mag, kur, kur_ring, noise, excis, exch, outdir)
    print(json.dumps(OUT, indent=1, default=float))
